package com.guirec;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.repository.PackRepository;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v1.0.42: whatever is changed while a recording runs (video settings, FOV, GUI scale, keybinds, resource packs...) is put back the moment the
 * recording stops: the game settings are exactly what they were when the recording started.
 * Start: options.txt is saved and copied in memory. Stop: if options.txt is different now, the copy is written back, loaded into the running
 * game, and the resource packs are reloaded when the pack list changed. On game exit only the file is restored.
 */
public final class SettingsGuard {
    private SettingsGuard() {}

    private static byte[] snap;          // options.txt at recording start
    private static boolean valid;

    private static Path file(Minecraft mc) { return mc.gameDirectory.toPath().resolve("options.txt"); }

    /** Recording starts: remember the settings. */
    public static synchronized void snapshot() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.options == null) { valid = false; return; }
            if (mc.isSameThread()) { try { mc.options.save(); } catch (Throwable ignored) {} }   // make the file equal to what the game has now
            Path f = file(mc);
            snap = Files.exists(f) ? Files.readAllBytes(f) : null;
            valid = snap != null;
        } catch (Throwable t) { valid = false; System.err.println("[guirec] settings snapshot failed: " + t); }
    }

    /** Recording stopped: put the settings back. closing = the game is shutting down (only the file is restored). */
    public static void restore(boolean closing) {
        final byte[] data;
        synchronized (SettingsGuard.class) {
            if (!valid) return;
            valid = false;
            data = snap;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || data == null) return;
            if (closing) { Files.write(file(mc), data); return; }
            if (mc.isSameThread()) apply(mc, data); else mc.execute(() -> apply(mc, data));
        } catch (Throwable t) { System.err.println("[guirec] settings restore failed: " + t); }
    }

    private static void apply(Minecraft mc, byte[] data) {
        try {
            Path f = file(mc);
            try { mc.options.save(); } catch (Throwable ignored) {}
            byte[] now = Files.exists(f) ? Files.readAllBytes(f) : null;
            if (Arrays.equals(now, data)) return;                       // nothing was changed during the recording
            PackRepository repo = mc.getResourcePackRepository();
            List<String> before = new ArrayList<>(repo.getSelectedIds());
            Files.write(f, data);
            mc.options.load();                                           // every option goes back (video, sound, controls, FOV, GUI scale...)
            KeyMapping.resetMapping();
            mc.options.loadSelectedResourcePacks(repo);                  // resource packs back
            List<String> after = new ArrayList<>(repo.getSelectedIds());
            if (!before.equals(after)) mc.reloadResourcePacks();
            System.out.println("[guirec] settings put back to the state from before the recording");
        } catch (Throwable t) { System.err.println("[guirec] settings restore failed: " + t); }
    }
}
