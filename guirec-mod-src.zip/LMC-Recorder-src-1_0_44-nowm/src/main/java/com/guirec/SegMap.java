package com.guirec;

/**
 * v1.0.44: one recording can hold SEVERAL connections ("Start rec full": server A, leave, server B, ...). Each connection starts with its own
 * configuration packets, so it is a SEGMENT (the file has a type-10 marker before its first packet). This class works out, from plain numbers
 * (no Minecraft classes), which segments are real worlds, and how the timeline looks without the long pauses between them.
 *
 *  - a segment with no camera state at all never became a world (failed join): it is dropped
 *  - the time between the last frame of one world and the first packet of the next is cut down to KEEP ms (the menus in between are not replayed)
 *  - packets of a world that arrive after its last frame are squeezed in front of the next world
 */
public final class SegMap {
    public static final int KEEP = 1200;

    public final boolean multi;
    public final int n;                // live segments
    public final int[] pktSeg;         // per packet (file order): live segment, -1 = dropped
    private final int[] rs, re, sh;    // raw start (first packet), raw end (last camera state), cumulative cut length

    private SegMap(boolean multi, int n, int[] pktSeg, int[] rs, int[] re, int[] sh) {
        this.multi = multi; this.n = n; this.pktSeg = pktSeg; this.rs = rs; this.re = re; this.sh = sh;
    }

    /** pktMs / stateMs sorted by file order (non-decreasing); marks = ms of the type-10 markers. */
    public static SegMap build(int[] pktMs, int[] marks, int[] stateMs) {
        int np = pktMs.length;
        int[] one = new int[np];
        if (marks.length == 0 || np == 0) return new SegMap(false, 1, one, new int[]{0}, new int[]{0}, new int[]{0});
        int[] starts = new int[marks.length + 1];
        int ns = 1;
        int p = 0;
        for (int mk : marks) {
            while (p < np && pktMs[p] < mk) p++;
            if (p > starts[ns - 1] && p < np) starts[ns++] = p;
        }
        if (ns == 1) return new SegMap(false, 1, one, new int[]{0}, new int[]{0}, new int[]{0});
        int[] aStart = new int[ns];
        for (int j = 0; j < ns; j++) aStart[j] = pktMs[starts[j]];
        boolean[] has = new boolean[ns];
        int[] last = new int[ns];
        int j = 0;
        for (int s : stateMs) {
            if (s < aStart[0]) continue;
            while (j + 1 < ns && aStart[j + 1] <= s) j++;
            has[j] = true; last[j] = s;
        }
        int live = 0;
        for (int k = 0; k < ns; k++) if (has[k]) live++;
        if (live == 0) return new SegMap(false, 1, one, new int[]{0}, new int[]{0}, new int[]{0});
        int[] liveOf = new int[ns];
        int[] lrs = new int[live], lre = new int[live], lsh = new int[live];
        int t = 0;
        for (int k = 0; k < ns; k++) {
            if (!has[k]) { liveOf[k] = -1; continue; }
            liveOf[k] = t; lrs[t] = aStart[k]; lre[t] = last[k];
            if (t > 0) lsh[t] = lsh[t - 1] + Math.max(0, lrs[t] - lre[t - 1] - KEEP);
            t++;
        }
        int[] ps = new int[np];
        int seg = 0;
        for (int i = 0; i < np; i++) {
            while (seg + 1 < ns && starts[seg + 1] <= i) seg++;
            ps[i] = liveOf[seg];
        }
        return new SegMap(true, live, ps, lrs, lre, lsh);
    }

    /** live segment that raw time x falls into (-1 = before the first world). */
    public int segOfRaw(int x) {
        int t = -1;
        for (int k = 0; k < n; k++) { if (rs[k] <= x) t = k; else break; }
        return t;
    }

    /** True if x is in the pause between two worlds (menus, connecting): such records are dropped. */
    public boolean inGap(int x) {
        if (!multi) return false;
        int t = segOfRaw(x);
        return t >= 0 && t + 1 < n && x > re[t] && x < rs[t + 1];
    }

    /** Raw time -> time on the shortened timeline (everything but packets). */
    public int map(int x) {
        if (!multi) return x;
        int t = segOfRaw(x);
        return t < 0 ? x : Math.max(0, x - sh[t]);
    }

    /** Packet of live segment t. */
    public int mapPkt(int x, int t) {
        if (!multi) return x;
        int v = x - sh[t];
        if (t + 1 < n) v = Math.min(v, re[t] - sh[t] + KEEP - 1);
        return Math.max(0, v);
    }
}
