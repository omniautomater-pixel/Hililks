package com.guirec.mixin;

import com.guirec.ReplayExport;
import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * While a replay is exported to video the game timer runs on a fixed step per rendered frame (1/fps), not on real time.
 * v1.0.40: the step is now EXACT (fractional ms). Before, the clock was rounded to whole ms, so at 240 fps the frames got 4,4,4,4,4,5 ms and the
 * partial tick (= how far entities / the character are between two game ticks) advanced unevenly: movement looked like it stops and goes.
 */
@Mixin(DeltaTracker.Timer.class)
public class DeltaTrackerMixin {
    @Shadow private float deltaTicks;
    @Shadow private float deltaTickResidual;
    @Shadow private float realtimeDeltaTicks;
    @Shadow private long lastMs;
    @Shadow private long lastUiMs;
    @Shadow @Final private float msPerTick;
    @Shadow @Final private FloatUnaryOperator targetMsptProvider;

    @Unique private double guirec$g = -1;
    @Unique private double guirec$u = -1;

    @Inject(method = "advanceGameTime(J)I", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$exactGame(long ms, CallbackInfoReturnable<Integer> cir) {
        if (!ReplayExport.active) {
            if (guirec$g >= 0) { guirec$g = -1; this.lastMs = ms; this.deltaTickResidual = 0f; }   // export over: back to the real clock without a jump
            return;
        }
        double t = ReplayExport.exportMs();
        if (guirec$g < 0) { guirec$g = t; this.lastMs = (long) t; this.deltaTicks = 0f; cir.setReturnValue(0); return; }
        float mspt = this.targetMsptProvider.apply(this.msPerTick);
        this.deltaTicks = (float) ((t - guirec$g) / mspt);
        guirec$g = t; this.lastMs = (long) t;
        this.deltaTickResidual += this.deltaTicks;
        int n = (int) this.deltaTickResidual;
        this.deltaTickResidual -= n;
        cir.setReturnValue(n);
    }

    @Inject(method = "advanceRealTime(J)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$exactReal(long ms, CallbackInfo ci) {
        if (!ReplayExport.active) {
            if (guirec$u >= 0) { guirec$u = -1; this.lastUiMs = ms; }
            return;
        }
        double t = ReplayExport.exportMs();
        if (guirec$u < 0) { guirec$u = t; this.lastUiMs = (long) t; this.realtimeDeltaTicks = 0f; ci.cancel(); return; }
        this.realtimeDeltaTicks = (float) ((t - guirec$u) / this.msPerTick);
        guirec$u = t; this.lastUiMs = (long) t;
        ci.cancel();
    }
}
