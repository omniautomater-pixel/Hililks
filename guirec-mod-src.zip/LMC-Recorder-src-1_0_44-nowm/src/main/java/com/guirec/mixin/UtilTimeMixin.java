package com.guirec.mixin;

import com.guirec.ReplayExport;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * v1.0.40: the game reads the REAL clock (Util.getNanos / getMillis) for the enchant glint scroll, the chat / sign cursor blink, boss bars, toasts,
 * the world border, subtitles, the loading overlay... A video export renders far slower than real time, so all of that ran many times too fast.
 * While exporting, this clock advances exactly 1/fps per rendered frame, like the game timer (see DeltaTrackerMixin).
 */
@Mixin(Util.class)
public class UtilTimeMixin {
    @Inject(method = "getNanos()J", at = @At("RETURN"), cancellable = true, require = 0)
    private static void guirec$fakeNanos(CallbackInfoReturnable<Long> cir) {
        if (ReplayExport.active) cir.setReturnValue(ReplayExport.utilNs());
    }
}
