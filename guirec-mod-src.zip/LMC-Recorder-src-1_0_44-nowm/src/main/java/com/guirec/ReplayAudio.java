package com.guirec;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Audio for the video export. Every sound the replay plays (recorded server / game sounds, and sounds the game made itself) is
 * NOT played but noted here: when it starts, which sound file, how loud on the left / right ear (distance + direction to the camera)
 * and the pitch. After the video is encoded the sound files are decoded with ffmpeg and mixed into one stereo wav, which is then
 * muxed into the mp4 (AAC). Looping sounds and music are not recorded by the mod, so they are not in the video either.
 */
public final class ReplayAudio {
    private static final int RATE = 44100;
    private record Ev(long ms, String res, float gl, float gr, float pitch) {}

    private static final List<Ev> events = new ArrayList<>();
    private static final Map<String, byte[]> ogg = new HashMap<>();
    private static volatile String err = "";
    private static int missed;

    private ReplayAudio() {}

    public static synchronized void reset() { events.clear(); ogg.clear(); err = ""; missed = 0; }
    public static synchronized int count() { return events.size(); }
    public static String error() { return err; }

    /** Called (main thread) for every sound the replay would play. */
    public static synchronized void capture(Minecraft mc, SoundInstance s, int delayTicks) {
        try {
            s.getOrResolve(mc.getSoundManager());
            Sound snd = s.getSound();
            if (snd == null || snd == SoundManager.EMPTY_SOUND || snd == SoundManager.INTENTIONALLY_EMPTY_SOUND) return;
            var rnd = SoundInstance.createUnseededRandom();
            float vol = s.getVolume() * snd.getVolume().sample(rnd);
            float pitch = Math.max(0.5f, Math.min(2.0f, s.getPitch() * snd.getPitch().sample(rnd)));
            float gain = Math.max(0f, Math.min(1f, vol));
            float gl = gain, gr = gain;
            var p = mc.player;
            boolean spatial = !s.isRelative() && s.getAttenuation() == SoundInstance.Attenuation.LINEAR && p != null;
            if (spatial) {
                double dx = s.getX() - p.getX(), dy = s.getY() - p.getEyeY(), dz = s.getZ() - p.getZ();
                double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                double range = Math.max(vol, 1.0f) * snd.getAttenuationDistance();
                double fall = Math.max(0.0, 1.0 - d / range);
                double g = gain * fall;
                double pan = 0;
                double hd = Math.sqrt(dx * dx + dz * dz);
                if (hd > 0.01) {
                    double yaw = Math.toRadians(p.getYRot());
                    pan = (dx / hd) * (-Math.cos(yaw)) + (dz / hd) * (-Math.sin(yaw));   // +1 = right ear
                    pan *= Math.min(1.0, hd / 2.0);                                         // sounds right next to you are centered
                }
                double a = (pan + 1.0) * Math.PI / 4.0;
                gl = (float) (g * Math.cos(a) * 1.4142);
                gr = (float) (g * Math.sin(a) * 1.4142);
            }
            if (gl < 0.002f && gr < 0.002f) return;
            String key = snd.getPath().toString();
            if (!ogg.containsKey(key)) {
                var opt = mc.getResourceManager().getResource(snd.getPath());
                if (opt.isEmpty()) { missed++; err = "sound file not found: " + key; return; }
                try (InputStream in = opt.get().open()) { ogg.put(key, in.readAllBytes()); }
            }
            events.add(new Ev(ReplayPlayer.timeMs() + (long) delayTicks * 50L, key, gl, gr, pitch));
        } catch (Throwable t) { err = String.valueOf(t); }
    }

    /** Decodes + mixes all noted sounds into a stereo 16 bit wav. t0 = replay time (ms) of the first video frame. */
    /** v1.0.44: replay time ranges that were NOT captured into the video (loading the next world, jumps): {from, to} pairs. Set by ReplayExport. */
    public static volatile long[][] holes = new long[0][];

    /** Replay time -> time in the video (ms): the holes are cut out. */
    private static double vt(long ms, long t0) {
        double v = ms - t0;
        for (long[] h : holes) { if (ms >= h[1]) v -= h[1] - h[0]; else if (ms > h[0]) v -= ms - h[0]; }
        return v;
    }

    public static boolean build(List<String> ff, long t0, double seconds, Path tmpDir, Path wav, Consumer<String> log) {
        List<Ev> evs; Map<String, byte[]> files;
        synchronized (ReplayAudio.class) { evs = new ArrayList<>(events); files = new HashMap<>(ogg); }
        try {
            Files.createDirectories(tmpDir);
            Map<String, float[]> pcm = new HashMap<>();
            int n = 0;
            for (var e : files.entrySet()) {
                float[] d = decode(ff, e.getValue(), tmpDir, n++, log);
                if (d != null && d.length > 0) pcm.put(e.getKey(), d);
            }
            log.accept("audio: " + evs.size() + " sounds, " + pcm.size() + "/" + files.size() + " files decoded");
            if (pcm.isEmpty()) return false;
            evs.removeIf(e -> e.ms < t0 || !pcm.containsKey(e.res));
            evs.sort(Comparator.comparingLong(Ev::ms));
            long total = (long) Math.ceil(seconds * RATE);
            final int CH = RATE * 20;
            try (RandomAccessFile raf = new RandomAccessFile(wav.toFile(), "rw")) {
                raf.setLength(0);
                raf.write(new byte[44]);
                for (long cs = 0; cs < total; cs += CH) {
                    int len = (int) Math.min(CH, total - cs);
                    float[] L = new float[len], R = new float[len];
                    long ce = cs + len;
                    for (Ev e : evs) {
                        long start = (long) (vt(e.ms, t0) * (RATE / 1000.0));
                        if (start >= ce) break;
                        float[] d = pcm.get(e.res);
                        long slen = (long) (d.length / (double) e.pitch);
                        if (start + slen <= cs) continue;
                        long a = Math.max(start, cs), b = Math.min(start + slen, ce);
                        for (long k = a; k < b; k++) {
                            double pos = (k - start) * (double) e.pitch;
                            int i = (int) pos;
                            if (i >= d.length) break;
                            float fr = (float) (pos - i);
                            float v = d[i] * (1 - fr) + d[Math.min(i + 1, d.length - 1)] * fr;
                            int o = (int) (k - cs);
                            L[o] += v * e.gl; R[o] += v * e.gr;
                        }
                    }
                    ByteBuffer bb = ByteBuffer.allocate(len * 4).order(ByteOrder.LITTLE_ENDIAN);
                    for (int i = 0; i < len; i++) {
                        bb.putShort(clip(L[i])); bb.putShort(clip(R[i]));
                    }
                    raf.write(bb.array());
                }
                long dataLen = raf.length() - 44;
                ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
                h.put("RIFF".getBytes()).putInt((int) (36 + dataLen)).put("WAVE".getBytes()).put("fmt ".getBytes())
                        .putInt(16).putShort((short) 1).putShort((short) 2).putInt(RATE).putInt(RATE * 4).putShort((short) 4).putShort((short) 16)
                        .put("data".getBytes()).putInt((int) dataLen);
                raf.seek(0); raf.write(h.array());
            }
            return true;
        } catch (Throwable t) { log.accept("audio mix failed: " + t); err = String.valueOf(t); return false; }
    }

    private static short clip(float x) {
        if (x > 1f) x = 1f; else if (x < -1f) x = -1f;
        return (short) (x * 32767f);
    }

    /** ogg bytes -> mono float samples @44100 (decoded by ffmpeg). */
    private static float[] decode(List<String> ff, byte[] data, Path dir, int n, Consumer<String> log) {
        try {
            Path in = dir.resolve("s" + n + ".ogg"), out = dir.resolve("s" + n + ".raw");
            Files.write(in, data);
            List<String> c = new ArrayList<>(ff);
            c.addAll(List.of("-y", "-hide_banner", "-loglevel", "error", "-i", in.toString(), "-f", "f32le", "-ac", "1", "-ar", String.valueOf(RATE), out.toString()));
            ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true);
            FFmpegBin.applyEnv(pb, FFmpegBin.libDir());
            Process p = pb.start();
            p.getOutputStream().close();
            byte[] txt = p.getInputStream().readAllBytes();
            if (!p.waitFor(30, TimeUnit.SECONDS)) { p.destroyForcibly(); return null; }
            if (p.exitValue() != 0) { log.accept("decode failed: " + new String(txt)); return null; }
            byte[] raw = Files.readAllBytes(out);
            float[] f = new float[raw.length / 4];
            ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(f);
            Files.deleteIfExists(in); Files.deleteIfExists(out);
            return f;
        } catch (Throwable t) { log.accept("decode: " + t); return null; }
    }
}
