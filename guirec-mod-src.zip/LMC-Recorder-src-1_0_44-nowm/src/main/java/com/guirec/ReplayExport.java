package com.guirec;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import com.mojang.blaze3d.platform.NativeImage;

import java.io.*;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Replay -> .mp4. The replay is played with a FIXED clock: every rendered frame is exactly 1/fps of replay time (replay clock and
 * game clock, see DeltaTrackerMixin / ReplayPlayer.onFrame), so the video is smooth even if the phone renders slower than real time.
 * Each finished frame is read back from the main render target and piped (raw RGBA) into ffmpeg, which encodes H.264.
 * No audio (the recording keeps sounds as events, they are not mixed into the video).
 * Output: .minecraft/guirec/exports/<replay name>.mp4   Log: .minecraft/guirec/export_debug.log
 */
public final class ReplayExport {
    public static volatile boolean active;
    public static int fps = 30;               // 1..240 (ExportScreen slider)
    public static int height = 1080;          // output height in pixels (width follows the aspect ratio); 0 = same as the game window
    public static int renderDist = 0;         // render distance (chunks) used DURING the export, 0 = leave the game's setting
    private static int oldRd = -1;            // the player's own render distance, put back when the export ends
    public static volatile int frame;              // rendered frames since the export started (drives the fixed clocks)

    private static final byte[] END = new byte[0];
    private static long base = -1;                 // ns: the real clock when the export clock started (all fake clocks = base + frame / fps)
    private static volatile long lastNsOut, lastMsOut;   // last values handed out by the game-clock hook (UtilTimeMixin)
    private static boolean finishing, stopPending;
    private static Path gameDir, out, videoTmp;
    private static volatile long t0 = -1;          // replay time (ms) of the first captured frame
    private static int lastCapMs = -1;             // v1.0.44: replay time of the last captured frame (a big jump = a hole in the video)
    private static final java.util.List<long[]> holes = new java.util.ArrayList<>();
    private static List<String> cmd;
    private static Process proc;
    private static BlockingQueue<byte[]> q;
    private static volatile boolean ended, failed;
    private static final AtomicInteger inflight = new AtomicInteger();
    private static int w, h;
    private static volatile long captured, dropped;
    private static PrintWriter dbg;
    private static long lastLog;
    // v1.0.40: big-export robustness
    private static final ConcurrentLinkedQueue<byte[]> free = new ConcurrentLinkedQueue<>();   // frame buffers are reused (no 16-30 MB garbage per frame)
    private static volatile boolean writerDead;
    private static volatile String failReason = "";
    private static long finishingSince;

    private ReplayExport() {}

    // ---------------------------------------------------------------- shader clock (IrisTimeMixin)
    private static boolean stInit;
    private static long stT0, stN0, stF0;
    private static double stUnit = -1;      // clock units per nanosecond (Iris gives ns or ms: measured, rounded to a power of ten)

    /** The clock a shader mod reads (any unit): while exporting it advances 1/fps per rendered frame instead of real time. */
    public static long shaderTime(long t) {
        if (!active) { stInit = false; stUnit = -1; return t; }
        // v1.0.40: if the shader mod reads the GAME clock (Util.getMillis / getNanos) it already gets the fixed export clock: leave it alone
        if (frame > 10 && lastNsOut != 0 && (Math.abs(t - lastMsOut) <= 2 || Math.abs(t - lastNsOut) <= 2_000_000L)) return t;
        long now = System.nanoTime();
        if (!stInit) { stInit = true; stT0 = t; stN0 = now; stF0 = frame; stUnit = -1; return t; }
        if (stUnit < 0) {
            if (now - stN0 < 300_000_000L) return stT0;               // too early to know the unit: hold still
            double r = Math.abs((double) (t - stT0)) / (now - stN0);   // units per ns
            if (r <= 0) return stT0;
            stUnit = Math.pow(10, Math.round(Math.log10(r)));
            if (stUnit > 1e3) stUnit = 1; else if (stUnit < 1e-9) stUnit = 1e-6;
            log("shader clock unit: " + stUnit + " per ns (measured " + r + ")");
        }
        return stT0 + (long) ((frame - stF0) * (1e9 / fps) * stUnit);
    }

    public static double stepMs() { return 1000.0 / fps; }

    /** The ONE export clock, in ns: advances exactly 1/fps per rendered frame (no rounding to whole ms: at 240 fps 4.1667 ms became 4,4,4,4,4,5 = judder). */
    private static long exportNs() {
        if (base < 0) base = System.nanoTime();
        return base + (long) frame * 1_000_000_000L / fps;
    }

    /** Exact export clock in ms (with fraction), used by DeltaTrackerMixin for the game timer (smooth partial ticks at any fps). */
    public static double exportMs() { return exportNs() / 1_000_000.0; }

    /** Old whole-ms clock (kept for callers that need a long). */
    public static long fakeMs(long real) {
        if (!active) return real;
        return exportNs() / 1_000_000L;
    }

    /** Util.getNanos() hook (UtilTimeMixin): everything in the game that animates by the real clock (enchant glint, chat cursor blink, boss bars,
     *  toasts, world border, subtitles, loading overlay...) sees export time instead, so it runs at normal speed in the video at any fps. */
    public static long utilNs() {
        long n = exportNs();
        lastNsOut = n; lastMsOut = n / 1_000_000L;
        return n;
    }

    private static synchronized void log(String s) {
        try {
            if (dbg == null && gameDir != null) {
                Path p = gameDir.resolve("guirec").resolve("export_debug.log");
                Files.createDirectories(p.getParent());
                dbg = new PrintWriter(Files.newBufferedWriter(p), true);
            }
            if (dbg != null) dbg.println(s);
        } catch (Throwable ignored) {}
    }

    /** Debug helper: write a line + stack trace into export_debug.log (only while an export runs). */
    public static void noteEx(String where, Throwable t) {
        if (!active) return;
        java.io.StringWriter sw = new java.io.StringWriter();
        t.printStackTrace(new java.io.PrintWriter(sw));
        log(where + ": " + sw);
    }

    // ---------------------------------------------------------------- start
    public static void start(Minecraft mc, Path replay) {
        if (active || ReplayPlayer.isPlaying()) return;
        try {
            gameDir = mc.gameDirectory.toPath();
            try { if (dbg != null) dbg.close(); } catch (Throwable ignored) {} dbg = null;
            ReplayPlayer.status = "Preparing ffmpeg...";
            cmd = FFmpegBin.command(gameDir);
            log(FFmpegBin.log());
            if (cmd == null) { ReplayPlayer.status = "Export: " + FFmpegBin.error(); return; }
            String name = replay.getFileName().toString().replace(".guirec", "");
            Path dir = gameDir.resolve("guirec").resolve("exports");
            Files.createDirectories(dir);
            out = dir.resolve(name + "_" + (height > 0 ? height + "p_" : "") + fps + "fps.mp4");
            videoTmp = dir.resolve(name + ".noaudio.tmp.mp4"); t0 = -1; lastCapMs = -1; holes.clear(); ReplayAudio.holes = new long[0][]; ReplayAudio.reset();
            frame = 0; base = -1; finishing = false; stopPending = false; ended = false; failed = false;
            w = h = 0; captured = 0; dropped = 0; inflight.set(0); proc = null; q = new ArrayBlockingQueue<>(3); lastLog = 0;
            free.clear(); writerDead = false; failReason = ""; finishingSince = 0;
            log("free disk: " + freeMb() + " MB, heap max: " + (Runtime.getRuntime().maxMemory() >> 20) + " MB");
            active = true;
            if (renderDist > 0) {
                try { oldRd = mc.options.renderDistance().get(); mc.options.renderDistance().set(renderDist); log("render distance " + oldRd + " -> " + renderDist); }
                catch (Throwable t) { oldRd = -1; log("render distance: " + t); }
            }
            ReplayPlayer.play(mc, replay);
            if (!ReplayPlayer.isPlaying()) { active = false; restoreRd(); return; }
            ReplayPlayer.status = "Exporting...";
            log("export start " + replay + " -> " + out + " @" + fps + " fps");
        } catch (Throwable t) {
            active = false;
            ReplayPlayer.status = "Export error: " + t;
            log("start failed: " + t);
        }
    }

    // ---------------------------------------------------------------- every rendered frame (GameRenderer.render TAIL)
    public static void afterFrame(Minecraft mc) {
        if (!active) return;
        frame++;
        try {
            if (finishing) {
                if (finishingSince == 0) finishingSince = System.nanoTime();
                // v1.0.40: a screenshot that never comes back must not hang the end of the export for ever
                if (inflight.get() == 0 || System.nanoTime() - finishingSince > 30_000_000_000L) {
                    if (inflight.get() > 0) log("finish: " + inflight.get() + " frame(s) never came back, going on without them");
                    finish(); stopPending = true;
                }
                return;
            }
            // replay stopped by itself (error inside the replay): finish now so the part exported so far is kept, instead of hanging
            if (!ReplayPlayer.isPlaying() && ReplayPlayer.worldReady()) { log("replay stopped by itself: " + ReplayPlayer.status); finishing = true; return; }
            if (!ReplayPlayer.isPlaying()) return;
            if (ReplayPlayer.switching()) return;           // v1.0.44: loading the next world of a full recording: not part of the video
            if (!ReplayPlayer.hasMenu() && (!ReplayPlayer.worldReady() || mc.level == null || mc.player == null)) return;   // v1.0.35: menus are part of the video
            if (failed) { finishing = true; return; }
            if (ReplayPlayer.timeMs() >= ReplayPlayer.totalMs() + 300) { finishing = true; return; }
            long now = System.nanoTime();
            if (now - lastLog > 1_000_000_000L) {
                lastLog = now;
                int pct = (int) (100L * ReplayPlayer.timeMs() / Math.max(1, ReplayPlayer.totalMs()));
                ReplayPlayer.status = "Exporting " + pct + "%  (" + captured + " frames)";
                log("t=" + ReplayPlayer.timeMs() + "/" + ReplayPlayer.totalMs() + " frames=" + captured + " dropped=" + dropped);
                long fm = freeMb();
                if (fm < 200) { fail("disk almost full (" + fm + " MB left)"); finishing = true; return; }   // keep what is exported so far
            }
            if (t0 < 0) t0 = ReplayPlayer.timeMs();
            { int tm = ReplayPlayer.timeMs(); if (lastCapMs >= 0 && tm - lastCapMs > 250 + 3 * (int) Math.ceil(stepMs())) holes.add(new long[]{lastCapMs, tm}); lastCapMs = tm; }
            inflight.incrementAndGet();
            Screenshot.takeScreenshot(mc.gameRenderer.mainRenderTarget(), img -> {
                try { onImage(img); }
                catch (Throwable t) { if (t instanceof OutOfMemoryError) free.clear(); fail("frame error: " + t); }
                finally { try { img.close(); } catch (Throwable ignored) {} inflight.decrementAndGet(); }
            });
        } catch (Throwable t) {
            fail("afterFrame: " + t); finishing = true;
        }
    }

    /** Called from the client tick: leave the replay after the export is finished. */
    public static void onTick(Minecraft mc) {
        if (stopPending) { stopPending = false; ReplayPlayer.stop(mc); }
    }

    // ---------------------------------------------------------------- one finished frame
    private static void onImage(NativeImage img) throws Exception {
        if (ended) return;
        int iw = img.getWidth(), ih = img.getHeight();
        if (proc == null) { w = iw; h = ih; startProcess(); }
        if (iw != w || ih != h) { dropped++; return; }            // window was resized during the export
        byte[] rgba = pixels(img, iw, ih);
        if (rgba == null) { fail("cannot read the frame pixels"); return; }
        Watermark.draw(rgba, iw, ih);                         // "LMC Recorder", 30 % opacity, bottom-right
        if (!putFrame(rgba)) { fail("ffmpeg stopped while exporting"); return; }
        captured++;
    }

    /** v1.0.40: a slow encoder (phone) is waited for as long as ffmpeg is alive; before, 60 s of waiting killed the whole export. */
    private static boolean putFrame(byte[] b) throws InterruptedException {
        long t = System.nanoTime(), lastNote = t;
        while (!q.offer(b, 2, TimeUnit.SECONDS)) {
            Process p = proc;
            if (writerDead || p == null || !p.isAlive()) return false;
            long n = System.nanoTime();
            if (n - lastNote > 30_000_000_000L) { lastNote = n; log("encoder is slow, waiting (" + (n - t) / 1_000_000_000L + " s so far)"); }
        }
        return true;
    }

    private static void fail(String why) {
        if (!failed) { failed = true; failReason = why; }
        log("FAIL: " + why);
    }

    private static long freeMb() {
        try { return Files.getFileStore(out != null ? out.getParent() : gameDir).getUsableSpace() >> 20; } catch (Throwable t) { return Long.MAX_VALUE >> 21; }
    }

    private static byte[] obtain(int len) {
        byte[] b;
        while ((b = free.poll()) != null) if (b.length == len) return b;
        return new byte[len];
    }
    private static void recycle(byte[] b) { if (free.size() < 3) free.offer(b); }

    private static void startProcess() throws Exception {
        List<String> c = new ArrayList<>(cmd);
        c.addAll(List.of("-y", "-hide_banner", "-loglevel", "warning",
                "-f", "rawvideo", "-pix_fmt", "rgba", "-s", w + "x" + h, "-framerate", String.valueOf(fps), "-i", "-",
                "-vf", height > 0 ? "scale=-2:" + height + ":flags=lanczos" : "scale=trunc(iw/2)*2:trunc(ih/2)*2"));
        if (FFmpegBin.hasX264()) c.addAll(List.of("-c:v", "libx264", "-preset", "superfast", "-crf", "20"));
        else c.addAll(List.of("-c:v", "mpeg4", "-q:v", "3"));
        // v1.0.40: fragmented mp4 while encoding. If ffmpeg is killed / the phone runs out of memory or space, everything written so far still plays.
        // At the end it is copied (no re-encode) into a normal faststart mp4.
        c.addAll(List.of("-g", String.valueOf(Math.max(1, fps * 2)), "-pix_fmt", "yuv420p",
                "-movflags", "+frag_keyframe+empty_moov+default_base_moof", videoTmp.toString()));
        log("ffmpeg: " + String.join(" ", c));
        ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true);
        FFmpegBin.applyEnv(pb, FFmpegBin.libDir());
        proc = pb.start();
        final Process p = proc;
        final BlockingQueue<byte[]> queue = q;
        // ffmpeg output -> log
        Thread t1 = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l; while ((l = r.readLine()) != null) log("[ffmpeg] " + l);
            } catch (Throwable ignored) {}
        }, "guirec-ffmpeg-log");
        t1.setDaemon(true); t1.start();
        // frames -> ffmpeg stdin
        Thread wr = new Thread(() -> {
            try (OutputStream os = new BufferedOutputStream(p.getOutputStream(), 1 << 20)) {
                while (true) {
                    byte[] b = queue.take();
                    if (b == END) break;
                    os.write(b);
                    recycle(b);
                }
            } catch (Throwable t) { writerDead = true; fail("writer: " + t); queue.clear(); }
            try {
                int code = waitProcess(p, videoTmp, 15 * 60_000L);     // no time limit while the file keeps growing
                long size = Files.exists(videoTmp) ? Files.size(videoTmp) : 0;
                log("ffmpeg video done exit=" + code + " size=" + size);
                if (size <= 0) { ReplayPlayer.status = "Export failed (ffmpeg exit " + code + ") - see guirec/export_debug.log"; return; }
                boolean partial = code != 0 || failed;
                if (code != 0 && failReason.isEmpty()) failReason = "ffmpeg exit " + code;
                finishOutput(partial);
            } catch (Throwable t) { ReplayPlayer.status = "Export failed: " + t; log("post: " + t); }
        }, "guirec-ffmpeg-writer");
        wr.setDaemon(true); wr.start();
    }

    private static void restoreRd() {
        if (oldRd <= 0) return;
        try { Minecraft.getInstance().options.renderDistance().set(oldRd); log("render distance back to " + oldRd); } catch (Throwable t) { log("render distance restore: " + t); }
        oldRd = -1;
    }

    /** Waits for a process. No fixed time limit: it is only killed when the watched file stops growing for stallMs. */
    private static int waitProcess(Process p, Path watch, long stallMs) throws InterruptedException {
        long last = -1, lastChange = System.currentTimeMillis();
        while (!p.waitFor(5, TimeUnit.SECONDS)) {
            long sz = 0;
            try { if (watch != null && Files.exists(watch)) sz = Files.size(watch); } catch (IOException ignored) {}
            long now = System.currentTimeMillis();
            if (sz != last) { last = sz; lastChange = now; }
            else if (now - lastChange > stallMs) {
                log("ffmpeg made no progress for " + stallMs / 60000 + " min: killed");
                p.destroyForcibly(); p.waitFor(10, TimeUnit.SECONDS);
                return -999;
            }
        }
        return p.exitValue();
    }

    /** Runs a short ffmpeg job (mux / remux). Its output goes to a file, so a full pipe can never block it. */
    private static boolean runFf(List<String> c, String what) {
        try {
            Path lg = out.getParent().resolve("ffmpeg_" + what + ".log");
            ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true).redirectOutput(lg.toFile());
            FFmpegBin.applyEnv(pb, FFmpegBin.libDir());
            Process m = pb.start(); m.getOutputStream().close();
            int code = waitProcess(m, out, 10 * 60_000L);
            String txt = "";
            try { txt = Files.readString(lg); } catch (Throwable ignored) {}
            try { Files.deleteIfExists(lg); } catch (Throwable ignored) {}
            if (txt.length() > 3000) txt = txt.substring(txt.length() - 3000);
            boolean ok = code == 0 && Files.exists(out) && Files.size(out) > 0;
            log(what + " ok=" + ok + " exit=" + code + " " + txt);
            return ok;
        } catch (Throwable t) { log(what + " failed: " + t); return false; }
    }

    /** Video is ready: add the audio (if the replay had sounds) and write the final mp4. */
    private static void finishOutput(boolean partial) throws Exception {
        long size = Files.size(videoTmp);
        boolean room = freeMb() * 1048576L > size + 100L * 1048576L;    // the final file needs about as much space as the video again
        boolean audio = false, remuxed = false;
        if (ReplayAudio.count() > 0 && t0 >= 0 && room) {
            ReplayPlayer.status = "Export: mixing audio (" + ReplayAudio.count() + " sounds)...";
            Path tmp = out.getParent().resolve("tmp_audio");
            Path wav = out.getParent().resolve("audio.tmp.wav");
            ReplayAudio.holes = holes.toArray(new long[0][]);
            if (!holes.isEmpty()) log("video holes (replay ms): " + holes.size());
            if (ReplayAudio.build(cmd, t0, captured / (double) fps, tmp, wav, ReplayExport::log)) {
                ReplayPlayer.status = "Export: writing the final mp4...";
                List<String> c = new ArrayList<>(cmd);
                c.addAll(List.of("-y", "-hide_banner", "-loglevel", "warning", "-i", videoTmp.toString(), "-i", wav.toString(),
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out.toString()));
                audio = runFf(c, "mux");
            }
            try { Files.deleteIfExists(wav); } catch (Throwable ignored) {}
            try { try (var st = Files.list(tmp)) { st.forEach(x -> x.toFile().delete()); } Files.deleteIfExists(tmp); } catch (Throwable ignored) {}
        } else if (!room) log("not enough free disk space for audio / final copy: keeping the video as it is");
        if (!audio && room) {
            ReplayPlayer.status = "Export: writing the final mp4...";
            List<String> c = new ArrayList<>(cmd);
            c.addAll(List.of("-y", "-hide_banner", "-loglevel", "warning", "-i", videoTmp.toString(), "-c", "copy", "-movflags", "+faststart", out.toString()));
            remuxed = runFf(c, "remux");
        }
        if (audio || remuxed) Files.deleteIfExists(videoTmp);
        else {
            log("final copy not made: the fragmented mp4 is kept as the result");
            Files.move(videoTmp, out, StandardCopyOption.REPLACE_EXISTING);
        }
        size = Files.size(out);
        ReplayPlayer.status = "Export saved: guirec/exports/" + out.getFileName() + String.format(" (%.1f MB%s)", size / 1048576.0, audio ? ", with sound" : ", no sound")
                + (partial ? " - STOPPED EARLY (" + failReason + "), see guirec/export_debug.log" : "");
        log("saved " + out + " audio=" + audio + " partial=" + partial + " err=" + ReplayAudio.error());
    }

    /** Sound hook (SoundManagerMixin): during an export sounds are noted for the audio track, not played. */
    public static boolean captureSound(net.minecraft.client.resources.sounds.SoundInstance s, int delayTicks) {
        if (!active) return false;
        ReplayAudio.capture(Minecraft.getInstance(), s, delayTicks);
        return true;
    }

    // ---------------------------------------------------------------- pixels (NativeImage -> raw RGBA bytes)
    private static Method mInts;
    private static boolean mPerPixel, probed;
    private static Method mPixel;

    private static byte[] pixels(NativeImage img, int iw, int ih) throws Exception {
        if (!probed) {
            probed = true;
            for (String n : new String[]{"getPixelsABGR", "getPixelsRGBA"}) {
                try { Method m = NativeImage.class.getMethod(n); if (m.getReturnType() == int[].class) { mInts = m; break; } } catch (NoSuchMethodException ignored) {}
            }
            if (mInts == null) {
                for (String n : new String[]{"getPixelABGR", "getPixel", "getPixelRGBA"}) {
                    try { mPixel = NativeImage.class.getMethod(n, int.class, int.class); mPerPixel = true; break; } catch (NoSuchMethodException ignored) {}
                }
            }
            if (mInts == null && mPixel == null) {
                StringBuilder sb = new StringBuilder("NativeImage methods:");
                for (Method m : NativeImage.class.getMethods()) sb.append(' ').append(m.getName());
                log(sb.toString());
            } else log("pixel read: " + (mInts != null ? mInts.getName() : mPixel.getName()));
        }
        byte[] b = obtain(iw * ih * 4);
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);   // ABGR int -> bytes R,G,B,A
        if (mInts != null) {
            int[] px = (int[]) mInts.invoke(img);
            bb.asIntBuffer().put(px, 0, Math.min(px.length, iw * ih));
            return b;
        }
        if (mPerPixel) {
            for (int y = 0; y < ih; y++) for (int x = 0; x < iw; x++) bb.putInt((Integer) mPixel.invoke(img, x, y));
            return b;
        }
        log("no way to read pixels from NativeImage");
        return null;
    }

    // ---------------------------------------------------------------- end (also when the replay is left early: partial video is kept)
    public static synchronized void finish() {
        if (!active) return;
        active = false; base = -1; finishing = false; finishingSince = 0;
        restoreRd();
        log("finish: frames=" + captured);
        if (proc == null) {
            if (ReplayPlayer.status.startsWith("Exporting")) ReplayPlayer.status = "Export: nothing recorded";
            return;
        }
        ended = true;
        final BlockingQueue<byte[]> queue = q;
        Thread t = new Thread(() -> {
            try { while (!queue.offer(END, 2, TimeUnit.SECONDS)) { if (writerDead) break; } } catch (InterruptedException ignored) {}   // v1.0.40: no 60 s limit
        }, "guirec-export-end");
        t.setDaemon(true); t.start();
    }
}
