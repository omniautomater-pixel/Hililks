

NO DOUBLE CURSOR IN YOUR OWN MENUS (v1.0.34)
The mod draws its own arrow only to show the RECORDED cursor while a replay plays. It is no longer drawn (so no second cursor behind yours) in the
menus you open yourself: F8 menu while recording, F8 menu you open during a replay, cursor editor, item search, skins, export. A menu that the
replay opens by itself (the recorded F8) still shows the recorded cursor, because that is what was recorded.

RECORD THE MENUS TOO (v1.0.35)
Menu (Watch out on the title screen / F8) -> left column: "Record menus: ON/OFF" (default ON, saved in guirec/far.properties).
With it ON a recording starts as soon as the SINGLEPLAYER world list or the MULTIPLAYER server list opens (not only when the world loads):
every frame of the menu screens, your mouse, clicks and typing (server address...) are saved, then the join / loading, then the world.
If you go back to the title screen without joining, that half recording is deleted by itself.
Play / Export replay the menus first (the recorded clicks run on the real menus; the click on "Join Server" / "Play Selected World" does NOT
really connect or load a world, the replay brings its own). Edit (timeline editor) starts at the world and skips the menus.
Recordings made with menus have the file header GUIREC04 (older versions of the mod cannot open them).

v1.0.36: with "Record menus" ON the recording now starts on the TITLE screen (the one with the Singleplayer / Multiplayer buttons), not only in the world /
server list. Idle on the title screen for 8 s = it starts over, so the replay begins shortly before your first click. Opening the "Watch out" menu cancels it.
Careful: the recorded clicks run on the real menus in the replay, so do not change options / delete worlds / edit servers while a menu recording runs.

v1.0.37: "Start rec" / "Stop rec" button in the top right corner of the TITLE screen, the singleplayer world list and the multiplayer server list:
tap it and the recording starts RIGHT NOW (menus, joining, the world), even with Auto-record OFF. It is never thrown away by itself; press "Stop rec"
to end it (a recording that never joined anything is deleted).

v1.0.38: the title screen button is now "Start rec full" (top LEFT). Tap it, then go anywhere from the title screen (Options, Video settings, Singleplayer,
Multiplayer ...), join a world / server, play, leave: all of it is one recording. It ends when you leave the world (or press "Stop rec"). One world per
recording: to record another join, press "Start rec full" again. Do not open "Watch out" / "Skins" while it runs (opening "Watch out" ends the recording).

v1.0.39 (this replaces the earlier notes about "Record menus"):
- ONLY the "Start rec full" button (title screen, top left) records the menus. Without it nothing changes: the recording starts when you join a world
  (Auto-record, Start rec in Watch out), exactly like before.
- "Watch out" can be opened while a full recording runs (it does not stop it). Replays cannot be played / edited / exported meanwhile.
- In a replay, whatever you did inside the mod's own menus (Watch out, Skins, cursor editor) is not replayed.

v1.0.40: EXPORT FIX for big exports (long replays / high resolution / slow phone).
- A slow encoder is waited for as long as ffmpeg is alive (before: 60 s of waiting = "export failed"; the 10 min limit at the end is gone too).
- The video is written as fragmented mp4 while encoding, then copied (no re-encode) into a normal mp4. If ffmpeg is killed or space runs out,
  the part exported so far is kept and playable (status says STOPPED EARLY + reason) instead of everything being lost.
- Frame buffers are reused (much less memory / garbage per frame, 4K and long exports no longer run out of heap).
- Disk space is checked: below 200 MB the export stops cleanly and keeps the partial video. Final copy is skipped if there is no room for it.
- Mux / remux ffmpeg output goes to a file (cannot block), a screenshot that never returns cannot hang the end of the export.

v1.0.41: EXPORT TIMING FIX (120 / 240 fps).
- Game timer is now exact (fractional ms). Before, the export clock was rounded to whole ms: at 240 fps the frames got 4,4,4,4,4,5 ms, so the character /
  entities moved unevenly (stops and goes). 120 fps (8,8,9) hid it better. Now every frame is exactly 1/fps.
- Everything the game animates by the REAL clock now runs on the export clock: enchant glint on armor / items (was ~40x too fast), chat and sign
  cursor blink "_", boss bars, toasts, subtitles, world border, loading overlay, hearts. (new UtilTimeMixin: Util.getNanos / getMillis)
- Iris shader clock: if the shader mod reads the game clock it is left alone, otherwise the old measured fix still applies.
- During an export packets / movement are never throttled by a real-time budget any more: everything due in a frame is applied in THAT frame.
