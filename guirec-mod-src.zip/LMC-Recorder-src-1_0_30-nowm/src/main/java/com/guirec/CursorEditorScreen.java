package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.List;
import java.util.function.IntConsumer;

/**
 * v1.0.27 pixel editor for the replay's mouse cursor (16x16, like making a texture).
 * Tools: Pen, Erase, Fill, Pick (eyedropper), Hot (hot spot = the pixel that points at what you click).
 * Colour: 32 palette swatches + R / G / B sliders. Left mouse = draw with the tool, right mouse = erase.
 * Load: start from the arrow / a sword / a pickaxe / one of YOUR saved cursors, then change it.
 * v1.0.30: type a name under the picture and press "Save & use": the cursor is saved for good under that name (same name = overwrite,
 * so you can load it again later, change it and save it). "Delete" removes the saved cursor that is shown in "Load:".
 * Hot spot = the red box = the pixel that points at what you click. Move it with the Hot tool, or with the MIDDLE mouse button.
 * While a replay plays the replay is paused and your real mouse works (before, the replay took the mouse away: nothing could be drawn).
 */
public class CursorEditorScreen extends Screen {
    private static final int N = CursorStyle.N;
    private static final int[] PALETTE = {
            // dyes
            0xFFF9FFFE, 0xFF9D9D97, 0xFF474F52, 0xFF1D1D21, 0xFF835432, 0xFFB02E26, 0xFFF9801D, 0xFFFED83D,
            0xFF80C71F, 0xFF5E7C16, 0xFF169C9C, 0xFF3AB3DA, 0xFF3C44AA, 0xFF8932B8, 0xFFC74EBD, 0xFFF38BAA,
            // materials: diamond, netherite, iron, gold, wood, dark
            0xFF9BFAEF, 0xFF2FD0C0, 0xFF1B8A95, 0xFF6B626E, 0xFF4A424D, 0xFF2E2831, 0xFFF0F0F0, 0xFFBEBEBE,
            0xFF7E7E7E, 0xFFFFF38A, 0xFFF2C62F, 0xFFB8821B, 0xFFC69A5A, 0xFF9A6E3B, 0xFF5E4124, 0xFF120E16
    };
    private static final String[] TOOLS = { "Pen", "Erase", "Fill", "Pick", "Hot" };   // Hot = move the click point (red box)

    private final Screen parent;
    private int[] px;
    private int hx, hy;
    private int color = 0xFF2FD0C0;
    private int tool = 0;
    private int tpl = 0;
    private boolean stroking;
    private final ArrayDeque<int[]> undo = new ArrayDeque<>();
    private String msg = "";
    private String nameText = "";          // text of the name box (kept over rebuildWidgets)
    private boolean delArmed;              // "Delete" was pressed once: press again to really delete
    private EditBox nameBox;

    // layout (set in init)
    private int gx, gy, cell;
    private int toolY, toolW, toolH;
    private final int[] toolX = new int[TOOLS.length];
    private int palX, palY, palSw;
    private int sideX, sideW, swatchX, swatchY;

    public CursorEditorScreen(Screen parent) {
        super(Component.literal("Cursor editor"));
        this.parent = parent;
        this.px = CursorStyle.pixelsOf(CursorStyle.selected);
        this.hx = CursorStyle.hotXOf(CursorStyle.selected);
        this.hy = CursorStyle.hotYOf(CursorStyle.selected);
        List<String> ids = CursorStyle.templateIds();
        int i = ids.indexOf(CursorStyle.selected);
        this.tpl = i < 0 ? 0 : i;
        this.nameText = CursorStyle.isSaved(CursorStyle.selected) ? CursorStyle.nameOf(CursorStyle.selected) : freeName();
    }

    private List<String> templates() { return CursorStyle.templateIds(); }

    @Override
    protected void init() {
        int bh = this.height >= 215 ? 20 : 16;
        int gap = 2;
        cell = Math.max(4, Math.min(14, (this.height - 50) / 16));   // v1.0.30: room under the picture for the name box
        gx = 8; gy = 16;
        sideX = gx + N * cell + 10;
        sideW = Math.max(120, Math.min(190, this.width - sideX - 6));
        int y = 14;

        // name of the cursor (saved under this name)
        nameBox = new EditBox(this.font, gx, gy + N * cell + 14, Math.max(70, N * cell), 16, Component.literal("Name"));
        nameBox.setMaxLength(24);
        nameBox.setHint(Component.literal("Cursor name"));
        nameBox.setValue(nameText);
        nameBox.setResponder(t -> { nameText = t; delArmed = false; });
        addRenderableWidget(nameBox);

        // tools
        toolW = (sideW - (TOOLS.length - 1) * gap) / TOOLS.length; toolH = bh; toolY = y;
        for (int i = 0; i < TOOLS.length; i++) {
            final int ti = i;
            toolX[i] = sideX + i * (toolW + gap);
            addRenderableWidget(Button.builder(Component.literal(TOOLS[i]), b -> { tool = ti; delArmed = false; }).bounds(toolX[i], y, toolW, bh).build());
        }
        y += bh + gap + 2;

        // palette (drawn + clicked by hand)
        palX = sideX; palY = y; palSw = Math.max(6, Math.min(10, sideW / 16));
        y += 2 * (palSw + 1) + 3;

        // colour sliders + swatch / preview on their right
        int sh = bh == 20 ? 14 : 12;
        int sw = sideW - 40;
        addRenderableWidget(new ChanSlider(sideX, y, sw, sh, "R", (color >> 16) & 255, v -> color = (color & 0xFF00FFFF) | (v << 16) | 0xFF000000));
        addRenderableWidget(new ChanSlider(sideX, y + sh + 2, sw, sh, "G", (color >> 8) & 255, v -> color = (color & 0xFFFF00FF) | (v << 8) | 0xFF000000));
        addRenderableWidget(new ChanSlider(sideX, y + 2 * (sh + 2), sw, sh, "B", color & 255, v -> color = (color & 0xFFFFFF00) | v | 0xFF000000));
        swatchX = sideX + sw + 6; swatchY = y;
        y += 3 * (sh + 2) + 2;

        // template row:  <  Load: name  >
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { tpl = (tpl + templates().size() - 1) % templates().size(); delArmed = false; rebuildWidgets(); })
                .bounds(sideX, y, 18, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Load: " + CursorStyle.label(templates().get(tpl))), b -> loadTemplate())
                .bounds(sideX + 20, y, sideW - 40, bh).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { tpl = (tpl + 1) % templates().size(); delArmed = false; rebuildWidgets(); })
                .bounds(sideX + sideW - 18, y, 18, bh).build());
        y += bh + gap;

        // edit row
        int w4 = (sideW - 3 * gap) / 4;
        addRenderableWidget(Button.builder(Component.literal("Undo"), b -> undo()).bounds(sideX, y, w4, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Clear"), b -> { push(); px = new int[N * N]; msg = "Cleared"; }).bounds(sideX + (w4 + gap), y, w4, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Flip H"), b -> flip(true)).bounds(sideX + 2 * (w4 + gap), y, w4, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Flip V"), b -> flip(false)).bounds(sideX + 3 * (w4 + gap), y, w4, bh).build());
        y += bh + gap;

        // finish row: Save & use | Delete | Cancel
        int wa = (sideW - 2 * gap) * 2 / 5, wb = (sideW - 2 * gap - wa) / 2;
        addRenderableWidget(Button.builder(Component.literal("Save & use"), b -> {
            String n = CursorStyle.saveNamed(nameText, px, hx, hy);
            msg = "Saved: " + n;
            onClose();
        }).bounds(sideX, y, wa, bh).build());
        String loadedId = templates().get(tpl);
        Button del = addRenderableWidget(Button.builder(Component.literal(delArmed ? "Sure?" : "Delete"), b -> {
            String id = templates().get(tpl);
            if (!CursorStyle.isSaved(id)) return;
            if (!delArmed) { delArmed = true; msg = "Press again: delete " + CursorStyle.nameOf(id); rebuildWidgets(); return; }
            CursorStyle.deleteNamed(CursorStyle.nameOf(id));
            delArmed = false;
            tpl = Math.max(0, Math.min(tpl, templates().size() - 1));
            msg = "Deleted " + CursorStyle.nameOf(id);
            rebuildWidgets();
        }).bounds(sideX + wa + gap, y, wb, bh).build());
        del.active = CursorStyle.isSaved(loadedId);      // only a saved cursor can be deleted (arrow / swords / pickaxes are built in)
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(sideX + wa + wb + 2 * gap, y, wb, bh).build());
    }

    // ---------------------------------------------------------------- editing
    private void push() {
        undo.push(px.clone());
        while (undo.size() > 64) undo.removeLast();
    }

    private void undo() {
        if (undo.isEmpty()) { msg = "Nothing to undo"; return; }
        px = undo.pop();
        msg = "Undone";
    }

    private void loadTemplate() {
        push();
        String id = templates().get(tpl);
        px = CursorStyle.pixelsOf(id);
        hx = CursorStyle.hotXOf(id);
        hy = CursorStyle.hotYOf(id);
        delArmed = false;
        if (CursorStyle.isSaved(id)) nameText = CursorStyle.nameOf(id);      // a saved cursor: Save overwrites it (= you are editing it)
        else if (nameText.isEmpty() || CursorStyle.isSaved(CursorStyle.MY + nameText)) nameText = freeName();   // never overwrite another saved cursor by accident
        msg = "Loaded " + CursorStyle.label(id);
        rebuildWidgets();
    }

    /** "My cursor", "My cursor 2", ... the first name that is not a saved cursor yet. */
    private static String freeName() {
        String n = "My cursor";
        for (int k = 2; CursorStyle.isSaved(CursorStyle.MY + n); k++) n = "My cursor " + k;
        return n;
    }

    private void flip(boolean horizontal) {
        push();
        int[] o = new int[N * N];
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++)
            o[(horizontal ? r : N - 1 - r) * N + (horizontal ? N - 1 - c : c)] = px[r * N + c];
        px = o;
        if (horizontal) hx = N - 1 - hx; else hy = N - 1 - hy;
    }

    private void floodFill(int start, int repl) {
        int target = px[start];
        if (target == repl) return;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        q.add(start);
        px[start] = repl;
        while (!q.isEmpty()) {
            int i = q.poll();
            int r = i / N, c = i % N;
            int[] nb = { r > 0 ? i - N : -1, r < N - 1 ? i + N : -1, c > 0 ? i - 1 : -1, c < N - 1 ? i + 1 : -1 };
            for (int j : nb) if (j >= 0 && px[j] == target) { px[j] = repl; q.add(j); }
        }
    }

    private int cellAt(double x, double y) {
        int c = (int) Math.floor((x - gx) / cell), r = (int) Math.floor((y - gy) / cell);
        return (c < 0 || r < 0 || c >= N || r >= N) ? -1 : r * N + c;
    }

    private int paletteAt(double x, double y) {
        int c = (int) Math.floor((x - palX) / (double) (palSw + 1)), r = (int) Math.floor((y - palY) / (double) (palSw + 1));
        return (c < 0 || c >= 16 || r < 0 || r >= 2) ? -1 : r * 16 + c;
    }

    private void apply(int idx, boolean right, boolean fresh) {
        switch (tool) {
            case 0: px[idx] = right ? 0 : color; break;
            case 1: px[idx] = 0; break;
            case 2: if (fresh) floodFill(idx, right ? 0 : color); break;
            case 3:
                if ((px[idx] >>> 24) != 0) { color = px[idx] | 0xFF000000; msg = String.format("Picked #%06X", color & 0xFFFFFF); rebuildWidgets(); }
                break;
            case 4: hx = idx % N; hy = idx / N; msg = "Hot spot: " + hx + ", " + hy; break;
            default: break;
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        int b = ev.button();
        if (cellAt(ev.x(), ev.y()) >= 0 || paletteAt(ev.x(), ev.y()) >= 0) this.setFocused(null);   // leave the name box when you click the picture
        if (b == 0) {
            int p = paletteAt(ev.x(), ev.y());
            if (p >= 0) { color = PALETTE[p]; rebuildWidgets(); return true; }
        }
        int idx = cellAt(ev.x(), ev.y());
        if (idx >= 0 && b == 2) { hx = idx % N; hy = idx / N; msg = "Click point (red box): " + hx + ", " + hy; return true; }   // middle mouse = move the click point
        if (idx >= 0 && (b == 0 || b == 1)) {
            if (tool <= 2) push();
            stroking = true;
            apply(idx, b == 1, true);
            return true;
        }
        return super.mouseClicked(ev, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent ev, double dx, double dy) {
        if (stroking) {
            int idx = cellAt(ev.x(), ev.y());
            if (idx >= 0 && (tool == 0 || tool == 1 || tool == 4)) apply(idx, ev.button() == 1, false);
            return true;
        }
        return super.mouseDragged(ev, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent ev) {
        if (stroking) { stroking = false; return true; }
        return super.mouseReleased(ev);
    }

    // ---------------------------------------------------------------- drawing
    private void box(GuiGraphicsExtractor g, int x, int y, int w, int h, int col) {
        g.fill(x, y, x + w, y + 1, col);
        g.fill(x, y + h - 1, x + w, y + h, col);
        g.fill(x, y, x + 1, y + h, col);
        g.fill(x + w - 1, y, x + w, y + h, col);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        g.text(this.font, "Cursor editor  (left = draw, right = erase)", gx, 4, 0xFFFFFFFF);

        // canvas
        g.fill(gx - 1, gy - 1, gx + N * cell + 1, gy + N * cell + 1, 0xFF000000);
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            int x = gx + c * cell, y = gy + r * cell;
            g.fill(x, y, x + cell - 1, y + cell - 1, ((r + c) & 1) == 0 ? 0xFF8A8A8A : 0xFF6E6E6E);
            int p = px[r * N + c];
            if ((p >>> 24) != 0) g.fill(x, y, x + cell - 1, y + cell - 1, p);
        }
        box(g, gx + hx * cell, gy + hy * cell, cell - 1, cell - 1, 0xFFFF2222);   // hot spot = the click point
        if (cell >= 8) box(g, gx + hx * cell + 1, gy + hy * cell + 1, cell - 3, cell - 3, 0xFFFF2222);

        // active tool
        box(g, toolX[tool] - 1, toolY - 1, toolW + 2, toolH + 2, 0xFFFFFF55);

        // palette
        for (int i = 0; i < PALETTE.length; i++) {
            int x = palX + (i % 16) * (palSw + 1), y = palY + (i / 16) * (palSw + 1);
            g.fill(x, y, x + palSw, y + palSw, PALETTE[i]);
            if (PALETTE[i] == color) box(g, x - 1, y - 1, palSw + 2, palSw + 2, 0xFFFFFFFF);
        }

        // current colour + 2x preview
        int pw = sideX + sideW - swatchX;
        g.fill(swatchX - 1, swatchY - 1, swatchX + pw + 1, swatchY + 13, 0xFF000000);
        g.fill(swatchX, swatchY, swatchX + pw, swatchY + 12, color);
        int py = swatchY + 16;
        g.fill(swatchX - 1, py - 1, swatchX + 2 * N + 1, py + 2 * N + 1, 0xFF000000);
        g.fill(swatchX, py, swatchX + 2 * N, py + 2 * N, 0xFF7A7A7A);
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            int p = px[r * N + c];
            if ((p >>> 24) != 0) g.fill(swatchX + c * 2, py + r * 2, swatchX + c * 2 + 2, py + r * 2 + 2, p);
        }

        if (!msg.isEmpty()) g.text(this.font, msg, gx, gy + N * cell + 3, 0xFFFFDD66);
        else g.text(this.font, "Red box = click point " + hx + "," + hy + "  (Hot tool)", gx, gy + N * cell + 3, 0xFFFF7777);
    }

    @Override
    public void onClose() { this.minecraft.gui.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }

    /** 0..255 slider for one colour channel. */
    private static final class ChanSlider extends AbstractSliderButton {
        private final String name;
        private final IntConsumer set;
        ChanSlider(int x, int y, int w, int h, String name, int cur, IntConsumer set) {
            super(x, y, w, h, Component.empty(), Math.max(0, Math.min(255, cur)) / 255.0);
            this.name = name; this.set = set;
            updateMessage();
        }
        private int val() { return (int) Math.round(this.value * 255); }
        @Override protected void updateMessage() { if (name != null) setMessage(Component.literal(name + ": " + val())); }
        @Override protected void applyValue() { set.accept(val()); }
    }
}
