package com.guirec;

import net.minecraft.client.Minecraft;
import io.netty.buffer.Unpooled;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;


import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/**
 * STAGE 1: records every clientbound network packet (config + play, raw bytes, with timestamps)
 * plus a per-frame "view state" (camera, screen, mouse cursor) into one small .guirec file.
 * No video, no PNGs, so the game does not lag. Recording starts automatically when you join a world.
 *
 * File = Deflate stream of:  "GUIREC01" then records
 *   1 PACKET : int ms, byte phase(0=config,1=play), int len, bytes
 *   2 STATE  : int ms, double x,y,z, float yaw,pitch, byte hotbarSlot, short screenId, float mouseX, mouseY, short winW, winH,
 *              byte flags (1=swinging arm, 2=offhand), UTF chatText   (v2+)
 *              v3 adds: byte pose, byte flags2 (1 sprint,2 sneak,4 using item,8 offhand), short useTicks, long breakingPos (MIN=none), byte breakStage
 *   4 INV    : int ms, byte n, n x (byte slot(100 = cursor item), int len, bytes of ItemStack)  items the client changed itself (creative!)
 *   5 CINV   : int ms, int containerId, short n, n x (short slot, int len, bytes)   item moves inside the open chest/crafting/... menu
 *   6 INPUT  : int ms, byte kind(0 key,1 char,2 mouse button,3 mouse move,4 scroll), payload   <- raw player input; the real game logic re-runs on it
 *   7 SOUND  : int ms, UTF id, byte source, float vol, float pitch, double x,y,z, byte attenuation, byte relative   (every sound the game plays)
 *   8 CRACK  : int ms, long blockPos, byte stage   (block-break crack set by the client for the local player)
 *   3 SCREEN : short id, UTF className       (dictionary for screenId; 0 = no screen)
 *   0 END
 */
public final class ReplayRecorder {
    public static volatile boolean autoRecord = true;
    /** v1.0.24: "Start rec" button (Auto OFF): the NEXT connection is recorded once. A recording can only begin at the start of a
     *  connection (the config packets are needed to rebuild the world), so a world that is already open has to be re-joined. */
    public static volatile boolean armed = false;
    private static final Object LOCK = new Object();
    private static volatile boolean active = false;
    private static boolean sawPlay = false;
    private static long t0;
    private static int noLevelTicks = 0;
    private static LinkedBlockingQueue<byte[]> queue;
    private static Thread writer;
    private static volatile Path file;
    public static volatile long packets, states;
    private static final Map<String, Integer> screenIds = new HashMap<>();
    private static int lastScreenId = -1;
    private static final byte[] POISON = new byte[0];
    private static final ItemStack[] lastInv = new ItemStack[46];
    private static ItemStack lastCarried = ItemStack.EMPTY;
    private static int lastMenuId = -1;
    private static ItemStack[] lastMenu = null;

    static { Runtime.getRuntime().addShutdownHook(new Thread(ReplayRecorder::stop)); }

    public static boolean isActive() { return active; }
    public static Path file() { return file; }
    public static long fileSize() { try { return file == null ? 0 : Files.size(file); } catch (Exception e) { return 0; } }

    private static int ms() { return (int) ((System.nanoTime() - t0) / 1_000_000L); }

    // start of the current frame (set by MinecraftMixin at the top of runTick): the camera we record belongs to THIS moment
    private static volatile long frameNs;
    public static void frameStart() { frameNs = System.nanoTime(); }
    private static int frameMs() {
        long f = frameNs;
        if (f == 0) return ms();
        return (int) Math.max(0L, (f - t0) / 1_000_000L);
    }

    /** True if a packet of this phase would be recorded right now (lets the decoder skip the copy when not recording). */
    public static boolean wants(boolean config) {
        if (ReplayPlayer.isPlaying()) return false;
        return active || ((autoRecord || armed) && config);
    }

    /**
     * Called from the network thread for every raw clientbound packet frame.
     * rec = 10 spare header bytes + the raw packet bytes (ONE copy, made by the decoder mixin).
     * Record layout: 1 PACKET : byte 1, int ms, byte phase, int len, bytes.
     * The lock is held only for the tiny bookkeeping, never while copying or compressing, so the render thread never waits on a big packet.
     */
    public static void onPacketRec(boolean play, byte[] rec) {
        if (ReplayPlayer.isPlaying()) return;
        int ms;
        LinkedBlockingQueue<byte[]> q;
        synchronized (LOCK) {
            if (!active) {
                if ((!autoRecord && !armed) || play) return;   // can only start cleanly at the start of a connection (config phase)
                start();
                if (!active) return;
                armed = false;
            }
            if (play) sawPlay = true;
            ms = ms();
            packets++;
            q = queue;
        }
        int len = rec.length - 10;
        rec[0] = 1;
        rec[1] = (byte) (ms >>> 24); rec[2] = (byte) (ms >>> 16); rec[3] = (byte) (ms >>> 8); rec[4] = (byte) ms;
        rec[5] = (byte) (play ? 1 : 0);
        rec[6] = (byte) (len >>> 24); rec[7] = (byte) (len >>> 16); rec[8] = (byte) (len >>> 8); rec[9] = (byte) len;
        q.add(rec);
    }

    /** Kept for compatibility: older callers hand over a plain packet copy. */
    public static void onPacket(String protocol, byte[] raw) {
        boolean config = protocol.equals("CONFIGURATION");
        boolean play = protocol.equals("PLAY");
        if (!config && !play) return;
        byte[] rec = new byte[10 + raw.length];
        System.arraycopy(raw, 0, rec, 10, raw.length);
        onPacketRec(play, rec);
    }

    // ---- raw input (keyboard / mouse / touch-emulated): the replay feeds these back into the real game logic
    private static void inputRec(int kind, java.util.function.Consumer<DataOutputStream> w) {
        if (!active || ReplayPlayer.isPlaying()) return;
        synchronized (LOCK) {
            if (!active) return;
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(32);
                DataOutputStream d = new DataOutputStream(bo);
                d.writeByte(6); d.writeInt(ms()); d.writeByte(kind);
                w.accept(d);
                queue.add(bo.toByteArray());
            } catch (IOException ignored) {}
        }
    }
    private static void u(DataOutputStream d, IOCall c) { try { c.run(d); } catch (IOException e) { throw new UncheckedIOException(e); } }
    private interface IOCall { void run(DataOutputStream d) throws IOException; }

    public static void inputKey(int action, int key, int scancode, int mods) {
        try { inputRec(0, d -> u(d, x -> { x.writeByte(action); x.writeInt(key); x.writeInt(scancode); x.writeInt(mods); })); } catch (RuntimeException ignored) {}
    }
    public static void inputChar(int cp) {
        try { inputRec(1, d -> u(d, x -> x.writeInt(cp))); } catch (RuntimeException ignored) {}
    }
    public static void inputButton(int button, int mods, int action) {
        try { inputRec(2, d -> u(d, x -> { x.writeInt(button); x.writeInt(mods); x.writeByte(action); })); } catch (RuntimeException ignored) {}
    }
    public static void inputMove(double px, double py) {
        try { inputRec(3, d -> u(d, x -> { x.writeDouble(px); x.writeDouble(py); })); } catch (RuntimeException ignored) {}
    }
    public static void inputScroll(double dx, double dy) {
        try { inputRec(4, d -> u(d, x -> { x.writeDouble(dx); x.writeDouble(dy); })); } catch (RuntimeException ignored) {}
    }

    /** How many sounds were saved in this recording (shown in the menu) and the last problem, if any. */
    public static volatile int soundsRec;
    public static volatile String soundErr = "";

    public static void sound(net.minecraft.client.resources.sounds.SoundInstance si) {
        if (!active || ReplayPlayer.isPlaying()) return;
        try {
            if (si.isLooping() || si.getSource() == net.minecraft.sounds.SoundSource.MUSIC) return;
            String id = String.valueOf(si.getIdentifier());
            synchronized (LOCK) {
                if (!active) return;
                ByteArrayOutputStream bo = new ByteArrayOutputStream(64);
                DataOutputStream d = new DataOutputStream(bo);
                d.writeByte(7); d.writeInt(ms()); d.writeUTF(id);
                d.writeByte(si.getSource().ordinal()); d.writeFloat(si.getVolume()); d.writeFloat(si.getPitch());
                d.writeDouble(si.getX()); d.writeDouble(si.getY()); d.writeDouble(si.getZ());
                d.writeByte(si.getAttenuation().ordinal()); d.writeByte(si.isRelative() ? 1 : 0);
                queue.add(bo.toByteArray());
                soundsRec++;
            }
        } catch (Throwable t) { soundErr = String.valueOf(t); }
    }

    public static void crack(long pos, int stage) {
        if (!active || ReplayPlayer.isPlaying()) return;
        synchronized (LOCK) {
            if (!active) return;
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(16);
                DataOutputStream d = new DataOutputStream(bo);
                d.writeByte(8); d.writeInt(ms()); d.writeLong(pos); d.writeByte(stage);
                queue.add(bo.toByteArray());
            } catch (IOException ignored) {}
        }
    }

    /** Called once per rendered frame (render thread). */
    public static void onFrame(Minecraft mc) {
        if (!active || ReplayPlayer.isPlaying()) return;
        synchronized (LOCK) {
            if (!active) return;
            if (mc.level == null || mc.player == null) {
                if (sawPlay && ++noLevelTicks > 120) stopLocked();
                return;
            }
            noLevelTicks = 0;
            try {
                int sid = 0;
                if (mc.gui.screen() != null) {
                    String n = mc.gui.screen().getClass().getName();
                    Integer id = screenIds.get(n);
                    if (id == null) {
                        id = screenIds.size() + 1; screenIds.put(n, id);
                        ByteArrayOutputStream b = new ByteArrayOutputStream();
                        DataOutputStream dd = new DataOutputStream(b);
                        dd.writeByte(3); dd.writeShort(id); dd.writeUTF(n);
                        queue.add(b.toByteArray());
                    }
                    sid = id;
                }
                ByteArrayOutputStream bo = new ByteArrayOutputStream(64);
                DataOutputStream d = new DataOutputStream(bo);
                var p = mc.player;
                d.writeByte(2); d.writeInt(frameMs());
                float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
                d.writeDouble(p.xo + (p.getX() - p.xo) * pt);
                d.writeDouble(p.yo + (p.getY() - p.yo) * pt);
                d.writeDouble(p.zo + (p.getZ() - p.zo) * pt);
                d.writeFloat(p.yRotO + (p.getYRot() - p.yRotO) * pt);
                d.writeFloat(p.xRotO + (p.getXRot() - p.xRotO) * pt);
                d.writeByte(p.getInventory().getSelectedSlot());
                d.writeShort(sid);
                d.writeFloat((float) mc.mouseHandler.xpos()); d.writeFloat((float) mc.mouseHandler.ypos());
                d.writeShort(mc.getWindow().getWidth()); d.writeShort(mc.getWindow().getHeight());
                boolean swingNow = p.isSwinging();
                var swingDesc = swingNow ? p.getCurrentSwing() : null;
                // swing progress 0..1 is stored as 0..7 (the tick counter is private since the swing rework)
                int swingProg = swingNow ? Math.round(Math.max(0f, Math.min(1f, p.getSwingAnimation(0f))) * 7f) : 0;
                int flags = (swingNow ? 1 : 0) | (swingDesc != null && swingDesc.hand() == InteractionHand.OFF_HAND ? 2 : 0)
                        | (swingProg << 2);
                Object sc = mc.gui.screen();
                String extra = "";
                if (sc instanceof ChatScreen && sc instanceof com.guirec.ChatAccess a) extra = a.guirec$getText();
                else if (sc instanceof CreativeModeInventoryScreen && sc instanceof CreativeAccess c)
                    extra = c.guirec$getTab() + ";" + c.guirec$getScroll() + ";" + c.guirec$getSearch();
                d.writeByte(flags); d.writeUTF(extra);
                d.writeByte(p.getPose().ordinal());
                d.writeByte((p.isSprinting() ? 1 : 0) | (p.isShiftKeyDown() ? 2 : 0) | (p.isUsingItem() ? 4 : 0)
                        | (p.getUsedItemHand() == InteractionHand.OFF_HAND ? 8 : 0) | (p.onGround() ? 16 : 0));
                d.writeShort(Math.min(32767, p.getTicksUsingItem()));
                var gm = mc.gameMode;
                boolean brk = gm != null && gm.isDestroying() && gm instanceof DestroyAccess da && da.guirec$destroyPos() != null;
                d.writeLong(brk ? ((DestroyAccess) gm).guirec$destroyPos().asLong() : Long.MIN_VALUE);
                d.writeByte(brk ? gm.getDestroyStage() : -1);
                queue.add(bo.toByteArray());
                states++;
                writeInv(mc, p);
            } catch (IOException ignored) {}
        }
    }

    /** Items the client changed on its own (creative inventory, cursor item) never come from the server, so save them. */
    private static void writeInv(Minecraft mc, net.minecraft.client.player.LocalPlayer p) throws IOException {
        var menu = p.inventoryMenu;
        int n = Math.min(46, menu.slots.size());
        java.util.List<Integer> idx = new java.util.ArrayList<>();
        java.util.List<ItemStack> val = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            ItemStack st = menu.getSlot(i).getItem();
            if (!ItemStack.matches(st, lastInv[i])) { lastInv[i] = st.copy(); idx.add(i); val.add(lastInv[i]); }
        }
        ItemStack car = p.containerMenu.getCarried();
        if (!ItemStack.matches(car, lastCarried)) { lastCarried = car.copy(); idx.add(100); val.add(lastCarried); }
        writeMenu(mc, p);
        if (idx.isEmpty()) return;
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        DataOutputStream d = new DataOutputStream(bo);
        d.writeByte(4); d.writeInt(ms()); d.writeByte(idx.size());
        for (int k = 0; k < idx.size(); k++) {
            RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), mc.level.registryAccess());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, val.get(k));
            byte[] b = new byte[buf.readableBytes()]; buf.readBytes(b); buf.release();
            d.writeByte(idx.get(k)); d.writeInt(b.length); d.write(b);
        }
        queue.add(bo.toByteArray());
    }

    /** Moves the player makes inside an open chest / crafting table / etc. are predicted by the client and not echoed by the server. */
    private static void writeMenu(Minecraft mc, net.minecraft.client.player.LocalPlayer p) throws IOException {
        var cm = p.containerMenu;
        if (cm == p.inventoryMenu) { lastMenuId = -1; lastMenu = null; return; }
        int n = cm.slots.size();
        if (cm.containerId != lastMenuId || lastMenu == null || lastMenu.length != n) {
            lastMenuId = cm.containerId; lastMenu = new ItemStack[n];
            for (int i = 0; i < n; i++) lastMenu[i] = cm.getSlot(i).getItem().copy();
            return;
        }
        java.util.List<Integer> idx = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            ItemStack st = cm.getSlot(i).getItem();
            if (!ItemStack.matches(st, lastMenu[i])) { lastMenu[i] = st.copy(); idx.add(i); }
        }
        if (idx.isEmpty()) return;
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        DataOutputStream d = new DataOutputStream(bo);
        d.writeByte(5); d.writeInt(ms()); d.writeInt(cm.containerId); d.writeShort(idx.size());
        for (int i : idx) {
            RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), mc.level.registryAccess());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, lastMenu[i]);
            byte[] b = new byte[buf.readableBytes()]; buf.readBytes(b); buf.release();
            d.writeShort(i); d.writeInt(b.length); d.write(b);
        }
        queue.add(bo.toByteArray());
    }

    private static void start() {
        try {
            Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("replays");
            Files.createDirectories(dir);
            file = dir.resolve("replay_" + System.currentTimeMillis() + ".guirec");
            final Path f = file;
            queue = new LinkedBlockingQueue<>();
            soundsRec = 0; soundErr = "";
            packets = 0; states = 0; sawPlay = false; noLevelTicks = 0; screenIds.clear();
            java.util.Arrays.fill(lastInv, ItemStack.EMPTY); lastCarried = ItemStack.EMPTY; lastMenuId = -1; lastMenu = null;
            t0 = System.nanoTime();
            final LinkedBlockingQueue<byte[]> q = queue;
            writer = new Thread(() -> {
                try (DataOutputStream out = new DataOutputStream(new DeflaterOutputStream(
                        new BufferedOutputStream(new FileOutputStream(f.toFile()), 1 << 16),
                        new Deflater(1), 1 << 15, true))) {
                    out.writeBytes("GUIREC03");
                    while (true) {
                        byte[] r = q.take();
                        if (r == POISON) break;
                        out.write(r);
                    }
                    out.writeByte(0);
                } catch (Exception e) { e.printStackTrace(); }
            }, "guirec-writer");
            writer.setDaemon(false);
            writer.setPriority(Thread.MIN_PRIORITY);   // compressing must never steal CPU from the game (chunk loading!)
            writer.start();
            active = true;
        } catch (Exception e) { e.printStackTrace(); active = false; }
    }

    public static void stop() { synchronized (LOCK) { stopLocked(); } }

    private static void stopLocked() {
        if (!active) return;
        active = false;
        queue.add(POISON);
        try { writer.join(5000); } catch (InterruptedException ignored) {}
    }
}
