package com.guirec;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class GuiRecMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeyMapping menu = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.guirec.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8, KeyMapping.Category.MISC));
        KeyMapping leave = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.guirec.leave", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F7, KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ReplayPlayer.onTick(mc);
            while (menu.consumeClick()) mc.setScreen(new RecorderScreen(mc.screen));
            while (leave.consumeClick()) ReplayPlayer.stop(mc);
        });
    }
}
