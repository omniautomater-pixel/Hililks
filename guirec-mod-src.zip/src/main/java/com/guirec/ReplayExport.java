package com.guirec;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import com.mojang.blaze3d.platform.NativeImage;

import java.io.*;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Replay -> .mp4. The replay is played with a FIXED clock: every rendered frame is exactly 1/fps of replay time (replay clock and
 * game clock, see DeltaTrackerMixin / ReplayPlayer.onFrame), so the video is smooth even if the phone renders slower than real time.
 * Each finished frame is read back from the main render target and piped (raw RGBA) into ffmpeg, which encodes H.264.
 * No audio (the recording keeps sounds as events, they are not mixed into the video).
 * Output: .minecraft/guirec/exports/<replay name>.mp4   Log: .minecraft/guirec/export_debug.log
 */
public final class ReplayExport {
    public static volatile boolean active;
    public static int fps = 30;
    public static volatile int frame;              // rendered frames since the export started (drives the fixed clocks)

    private static final byte[] END = new byte[0];
    private static long base = -1;
    private static boolean finishing, stopPending;
    private static Path gameDir, out;
    private static List<String> cmd;
    private static Process proc;
    private static BlockingQueue<byte[]> q;
    private static volatile boolean ended, failed;
    private static final AtomicInteger inflight = new AtomicInteger();
    private static int w, h;
    private static volatile long captured, dropped;
    private static PrintWriter dbg;
    private static long lastLog;

    private ReplayExport() {}

    public static double stepMs() { return 1000.0 / fps; }

    /** Used by DeltaTrackerMixin: the game timer sees a clock that advances fps-steps per rendered frame. */
    public static long fakeMs(long real) {
        if (!active) return real;
        if (base < 0) base = real;
        return base + (long) frame * 1000L / fps;
    }

    private static synchronized void log(String s) {
        try {
            if (dbg == null && gameDir != null) {
                Path p = gameDir.resolve("guirec").resolve("export_debug.log");
                Files.createDirectories(p.getParent());
                dbg = new PrintWriter(Files.newBufferedWriter(p), true);
            }
            if (dbg != null) dbg.println(s);
        } catch (Throwable ignored) {}
    }

    // ---------------------------------------------------------------- start
    public static void start(Minecraft mc, Path replay) {
        if (active || ReplayPlayer.isPlaying()) return;
        try {
            gameDir = mc.gameDirectory.toPath();
            try { if (dbg != null) dbg.close(); } catch (Throwable ignored) {} dbg = null;
            ReplayPlayer.status = "Preparing ffmpeg...";
            cmd = FFmpegBin.command(gameDir);
            log(FFmpegBin.log());
            if (cmd == null) { ReplayPlayer.status = "Export: " + FFmpegBin.error(); return; }
            String name = replay.getFileName().toString().replace(".guirec", "");
            Path dir = gameDir.resolve("guirec").resolve("exports");
            Files.createDirectories(dir);
            out = dir.resolve(name + "_" + fps + "fps.mp4");
            frame = 0; base = -1; finishing = false; stopPending = false; ended = false; failed = false;
            w = h = 0; captured = 0; dropped = 0; inflight.set(0); proc = null; q = new ArrayBlockingQueue<>(3); lastLog = 0;
            active = true;
            ReplayPlayer.play(mc, replay);
            if (!ReplayPlayer.isPlaying()) { active = false; return; }
            ReplayPlayer.status = "Exporting...";
            log("export start " + replay + " -> " + out + " @" + fps + " fps");
        } catch (Throwable t) {
            active = false;
            ReplayPlayer.status = "Export error: " + t;
            log("start failed: " + t);
        }
    }

    // ---------------------------------------------------------------- every rendered frame (GameRenderer.render TAIL)
    public static void afterFrame(Minecraft mc) {
        if (!active) return;
        frame++;
        try {
            if (finishing) {
                if (inflight.get() == 0) { finish(); stopPending = true; }
                return;
            }
            if (!ReplayPlayer.isPlaying() || !ReplayPlayer.worldReady() || mc.level == null || mc.player == null) return;
            if (failed) { finishing = true; return; }
            if (ReplayPlayer.timeMs() >= ReplayPlayer.totalMs() + 300) { finishing = true; return; }
            long now = System.nanoTime();
            if (now - lastLog > 1_000_000_000L) {
                lastLog = now;
                int pct = (int) (100L * ReplayPlayer.timeMs() / Math.max(1, ReplayPlayer.totalMs()));
                ReplayPlayer.status = "Exporting " + pct + "%  (" + captured + " frames)";
                log("t=" + ReplayPlayer.timeMs() + "/" + ReplayPlayer.totalMs() + " frames=" + captured + " dropped=" + dropped);
            }
            inflight.incrementAndGet();
            Screenshot.takeScreenshot(mc.getMainRenderTarget(), img -> {
                try { onImage(img); }
                catch (Throwable t) { failed = true; log("frame error: " + t); }
                finally { try { img.close(); } catch (Throwable ignored) {} inflight.decrementAndGet(); }
            });
        } catch (Throwable t) {
            failed = true; finishing = true;
            log("afterFrame: " + t);
        }
    }

    /** Called from the client tick: leave the replay after the export is finished. */
    public static void onTick(Minecraft mc) {
        if (stopPending) { stopPending = false; ReplayPlayer.stop(mc); }
    }

    // ---------------------------------------------------------------- one finished frame
    private static void onImage(NativeImage img) throws Exception {
        if (ended) return;
        int iw = img.getWidth(), ih = img.getHeight();
        if (proc == null) { w = iw; h = ih; startProcess(); }
        if (iw != w || ih != h) { dropped++; return; }            // window was resized during the export
        byte[] rgba = pixels(img, iw, ih);
        if (rgba == null) { failed = true; return; }
        if (!q.offer(rgba, 60, TimeUnit.SECONDS)) { failed = true; log("encoder too slow / stuck"); return; }
        captured++;
    }

    private static void startProcess() throws Exception {
        List<String> c = new ArrayList<>(cmd);
        c.addAll(List.of("-y", "-hide_banner", "-loglevel", "warning",
                "-f", "rawvideo", "-pix_fmt", "rgba", "-s", w + "x" + h, "-framerate", String.valueOf(fps), "-i", "-",
                "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"));
        if (FFmpegBin.hasX264()) c.addAll(List.of("-c:v", "libx264", "-preset", "superfast", "-crf", "20"));
        else c.addAll(List.of("-c:v", "mpeg4", "-q:v", "3"));
        c.addAll(List.of("-pix_fmt", "yuv420p", "-movflags", "+faststart", out.toString()));
        log("ffmpeg: " + String.join(" ", c));
        ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true);
        FFmpegBin.applyEnv(pb, FFmpegBin.libDir());
        proc = pb.start();
        final Process p = proc;
        final BlockingQueue<byte[]> queue = q;
        // ffmpeg output -> log
        Thread t1 = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l; while ((l = r.readLine()) != null) log("[ffmpeg] " + l);
            } catch (Throwable ignored) {}
        }, "guirec-ffmpeg-log");
        t1.setDaemon(true); t1.start();
        // frames -> ffmpeg stdin
        Thread wr = new Thread(() -> {
            try (OutputStream os = new BufferedOutputStream(p.getOutputStream(), 1 << 20)) {
                while (true) {
                    byte[] b = queue.take();
                    if (b == END) break;
                    os.write(b);
                }
            } catch (Throwable t) { failed = true; log("writer: " + t); }
            try {
                boolean ok = p.waitFor(10, TimeUnit.MINUTES) && p.exitValue() == 0;
                long size = Files.exists(out) ? Files.size(out) : 0;
                if (ok && size > 0) ReplayPlayer.status = "Export saved: guirec/exports/" + out.getFileName() + String.format(" (%.1f MB)", size / 1048576.0);
                else ReplayPlayer.status = "Export failed - see guirec/export_debug.log";
                log("ffmpeg done ok=" + ok + " size=" + size);
            } catch (Throwable t) { ReplayPlayer.status = "Export failed: " + t; }
        }, "guirec-ffmpeg-writer");
        wr.setDaemon(true); wr.start();
    }

    // ---------------------------------------------------------------- pixels (NativeImage -> raw RGBA bytes)
    private static Method mInts;
    private static boolean mPerPixel, probed;
    private static Method mPixel;

    private static byte[] pixels(NativeImage img, int iw, int ih) throws Exception {
        if (!probed) {
            probed = true;
            for (String n : new String[]{"getPixelsABGR", "getPixelsRGBA"}) {
                try { Method m = NativeImage.class.getMethod(n); if (m.getReturnType() == int[].class) { mInts = m; break; } } catch (NoSuchMethodException ignored) {}
            }
            if (mInts == null) {
                for (String n : new String[]{"getPixelABGR", "getPixel", "getPixelRGBA"}) {
                    try { mPixel = NativeImage.class.getMethod(n, int.class, int.class); mPerPixel = true; break; } catch (NoSuchMethodException ignored) {}
                }
            }
            if (mInts == null && mPixel == null) {
                StringBuilder sb = new StringBuilder("NativeImage methods:");
                for (Method m : NativeImage.class.getMethods()) sb.append(' ').append(m.getName());
                log(sb.toString());
            } else log("pixel read: " + (mInts != null ? mInts.getName() : mPixel.getName()));
        }
        byte[] b = new byte[iw * ih * 4];
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);   // ABGR int -> bytes R,G,B,A
        if (mInts != null) {
            int[] px = (int[]) mInts.invoke(img);
            bb.asIntBuffer().put(px, 0, Math.min(px.length, iw * ih));
            return b;
        }
        if (mPerPixel) {
            for (int y = 0; y < ih; y++) for (int x = 0; x < iw; x++) bb.putInt((Integer) mPixel.invoke(img, x, y));
            return b;
        }
        log("no way to read pixels from NativeImage");
        return null;
    }

    // ---------------------------------------------------------------- end (also when the replay is left early: partial video is kept)
    public static synchronized void finish() {
        if (!active) return;
        active = false; base = -1; finishing = false;
        log("finish: frames=" + captured);
        if (proc == null) {
            if (ReplayPlayer.status.startsWith("Exporting")) ReplayPlayer.status = "Export: nothing recorded";
            return;
        }
        ended = true;
        final BlockingQueue<byte[]> queue = q;
        Thread t = new Thread(() -> { try { queue.offer(END, 60, TimeUnit.SECONDS); } catch (InterruptedException ignored) {} }, "guirec-export-end");
        t.setDaemon(true); t.start();
    }
}
