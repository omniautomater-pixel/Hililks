package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Playback controls (open with F8 during a replay): seek, frame step, pause, speed, smooth-60 preview.
 * The replay keeps running behind it; recorded input is not injected into this screen.
 */
public class ReplayControlsScreen extends Screen {
    private static final double[] SPEEDS = {0.1, 0.25, 0.5, 1.0, 2.0, 4.0};
    private int barX0, barX1, barY0, barY1;
    private Button pauseBtn, speedBtn, smoothBtn;

    public ReplayControlsScreen() { super(Component.literal("Replay controls")); }

    private void add(List<Button> row, String label, Button.OnPress press) {
        row.add(Button.builder(Component.literal(label), press).bounds(0, 0, 10, 20).build());
    }

    private void seekBy(double ms) { ReplayPlayer.seek(ReplayPlayer.clock() + ms); }

    @Override
    protected void init() {
        List<Button> seek = new ArrayList<>(), ctl = new ArrayList<>();
        add(seek, "-30s", b -> seekBy(-30000));
        add(seek, "-10s", b -> seekBy(-10000));
        add(seek, "-5s", b -> seekBy(-5000));
        add(seek, "-1f", b -> { ReplayPlayer.paused = true; seekBy(-1000.0 / 60.0); });
        add(seek, "+1f", b -> { ReplayPlayer.paused = true; seekBy(1000.0 / 60.0); });
        add(seek, "+5s", b -> seekBy(5000));
        add(seek, "+10s", b -> seekBy(10000));
        add(seek, "+30s", b -> seekBy(30000));
        add(ctl, "Pause", b -> { ReplayPlayer.paused = !ReplayPlayer.paused; refresh(); });
        pauseBtn = ctl.get(ctl.size() - 1);
        add(ctl, "Speed", b -> {
            int k = 0;
            for (int i = 0; i < SPEEDS.length; i++) if (Math.abs(SPEEDS[i] - ReplayPlayer.speed) < 1e-6) k = i;
            ReplayPlayer.speed = SPEEDS[(k + 1) % SPEEDS.length]; refresh();
        });
        speedBtn = ctl.get(ctl.size() - 1);
        add(ctl, "Smooth", b -> { ReplayPlayer.smooth = !ReplayPlayer.smooth; refresh(); });
        smoothBtn = ctl.get(ctl.size() - 1);
        add(ctl, "Start", b -> ReplayPlayer.seek(0));
        add(ctl, "Close", b -> onClose());

        int bw = Math.max(34, Math.min(60, (this.width - 16) / 8 - 4)), gap = 4;
        int y = this.height - 28;
        layout(ctl, bw + 14, gap, y);
        layout(seek, bw, gap, y - 24);
        barX0 = 20; barX1 = this.width - 20; barY0 = y - 46; barY1 = y - 36;
        refresh();
    }

    private void layout(List<Button> row, int bw, int gap, int y) {
        int total = row.size() * bw + (row.size() - 1) * gap;
        int x = (this.width - total) / 2;
        for (Button b : row) {
            b.setX(x); b.setY(y); b.setWidth(bw);
            addRenderableWidget(b);
            x += bw + gap;
        }
    }

    private void refresh() {
        if (pauseBtn != null) pauseBtn.setMessage(Component.literal(ReplayPlayer.paused ? "Play" : "Pause"));
        if (speedBtn != null) speedBtn.setMessage(Component.literal("x" + trim(ReplayPlayer.speed)));
        if (smoothBtn != null) smoothBtn.setMessage(Component.literal(ReplayPlayer.smooth ? "60fps:ON" : "60fps:OFF"));
    }

    private static String trim(double v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(v); }

    private static String time(double ms) {
        int t = (int) Math.max(0, ms / 100);
        return String.format("%d:%02d.%d", t / 600, (t / 10) % 60, t % 10);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (e.x() >= barX0 && e.x() <= barX1 && e.y() >= barY0 - 4 && e.y() <= barY1 + 4 && ReplayPlayer.total() > 0) {
            ReplayPlayer.seek((e.x() - barX0) / (double) (barX1 - barX0) * ReplayPlayer.total());
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        double total = Math.max(1, ReplayPlayer.total());
        double frac = Math.max(0, Math.min(1, ReplayPlayer.clock() / total));
        g.fill(barX0, barY0, barX1, barY1, 0xFF303030);
        g.fill(barX0, barY0, barX0 + (int) ((barX1 - barX0) * frac), barY1, 0xFF55AAFF);
        g.text(this.font, time(ReplayPlayer.clock()) + " / " + time(total)
                + (ReplayPlayer.smooth ? "   60fps smooth (slow-mo)" : "") + (ReplayPlayer.paused ? "   PAUSED" : ""),
                barX0, barY0 - 12, 0xFFFFFFFF);
        if (!ReplayPlayer.status.isEmpty()) g.text(this.font, ReplayPlayer.status, barX0, barY0 - 24, 0xFFFFDD66);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
