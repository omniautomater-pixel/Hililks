package com.guirec.mixin;

import com.guirec.ReplayRecorder;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The partial tick the game renders a frame with is computed at the START of runTick. The recorder used to stamp the
 * camera with the time at the END of the frame, so every sample was late by a random amount (the frame's render time).
 * While sprinting that random error is multiplied by a high speed = visible shake. Remember the frame start instead.
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "runTick(Z)V", at = @At("HEAD"))
    private void guirec$frameStart(boolean advance, CallbackInfo ci) {
        ReplayRecorder.frameStart();
    }
}
