package com.guirec.mixin;

import com.guirec.FarChunks;
import net.minecraft.client.Options;
import net.minecraft.server.level.ClientInformation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Far record: tell the server we want FAR_VIEW chunks, whatever the local render distance is. */
@Mixin(Options.class)
public class OptionsMixin {
    @Inject(method = "buildPlayerInformation", at = @At("RETURN"), cancellable = true)
    private void guirec$farView(CallbackInfoReturnable<ClientInformation> cir) {
        if (!FarChunks.wantFar()) return;
        ClientInformation i = cir.getReturnValue();
        if (i.viewDistance() >= FarChunks.FAR_VIEW) return;
        cir.setReturnValue(new ClientInformation(i.language(), FarChunks.FAR_VIEW, i.chatVisibility(), i.chatColors(),
                i.modelCustomisation(), i.mainHand(), i.textFilteringEnabled(), i.allowsListing(), i.particleStatus()));
    }
}
