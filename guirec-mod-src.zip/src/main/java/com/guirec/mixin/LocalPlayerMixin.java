package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Our own arm swing is client-side only (the server just tells OTHER players), so record it and replay it. */
@Mixin(LocalPlayer.class)
public class LocalPlayerMixin {
    @Inject(method = "swing(Lnet/minecraft/world/InteractionHand;)V", at = @At("HEAD"), cancellable = true)
    private void guirec$swing(InteractionHand hand, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) {
            if (ReplayPlayer.blockSwing()) ci.cancel();
        } else {
            ReplayRecorder.recSwing(hand);
        }
    }
}
