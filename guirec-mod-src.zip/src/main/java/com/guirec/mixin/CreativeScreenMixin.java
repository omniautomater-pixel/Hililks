package com.guirec.mixin;

import com.guirec.CreativeAccess;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(CreativeModeInventoryScreen.class)
public abstract class CreativeScreenMixin implements CreativeAccess {
    @Shadow private static CreativeModeTab selectedTab;
    @Shadow private float scrollOffs;
    @Shadow private EditBox searchBox;
    @Shadow protected abstract void selectTab(CreativeModeTab tab);

    @Override public int guirec$getTab() { return CreativeModeTabs.allTabs().indexOf(selectedTab); }

    @Override public void guirec$setTab(int i) {
        var tabs = CreativeModeTabs.allTabs();
        if (i >= 0 && i < tabs.size() && tabs.get(i) != selectedTab) selectTab(tabs.get(i));
    }

    @Override public float guirec$getScroll() { return scrollOffs; }

    @Override public void guirec$setScroll(float f) {
        if (Math.abs(scrollOffs - f) < 1e-4f) return;
        scrollOffs = f;
        var self = (CreativeModeInventoryScreen) (Object) this;
        if (self.getMenu() instanceof CreativeModeInventoryScreen.ItemPickerMenu m) m.scrollTo(f);
    }

    @Override public String guirec$getSearch() { return searchBox == null ? "" : searchBox.getValue(); }

    @Override public void guirec$setSearch(String s) {
        if (searchBox != null && !searchBox.getValue().equals(s)) searchBox.setValue(s);
    }
}
