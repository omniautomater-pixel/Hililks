package com.guirec.mixin;

import com.guirec.DestroyAccess;
import com.guirec.ReplayPlayer;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public class GameModeMixin implements DestroyAccess {
    @Shadow private BlockPos destroyBlockPos;

    @Override public BlockPos guirec$destroyPos() { return destroyBlockPos; }

    /** In a replay no keys are held, so the game would stop the replayed "eating / drawing bow" every tick. */
    @Inject(method = "releaseUsingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$keepUsing(Player player, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) ci.cancel();
    }
}
