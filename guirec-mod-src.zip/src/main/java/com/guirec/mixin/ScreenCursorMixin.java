package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the recorded mouse cursor on top of every screen while a replay plays. */
@Mixin(Screen.class)
public class ScreenCursorMixin {
    @Inject(method = "extractRenderStateWithTooltipAndSubtitles", at = @At("TAIL"), require = 0)
    private void guirec$cursor(GuiGraphicsExtractor g, int mx, int my, float delta, CallbackInfo ci) {
        if (!ReplayPlayer.isPlaying()) return;
        // small arrow (8 px tall in GUI units, was 12) so it does not hide the item you are holding
        for (int r = 0; r < 8; r++) {                        // black arrow outline
            int w = Math.min(r + 2, 6);
            g.fill(mx, my + r, mx + w, my + r + 1, 0xFF000000);
        }
        for (int r = 1; r < 7; r++) {                        // white inside
            int w = Math.min(r + 1, 5);
            g.fill(mx + 1, my + r, mx + w, my + r + 1, 0xFFFFFFFF);
        }
    }
}
