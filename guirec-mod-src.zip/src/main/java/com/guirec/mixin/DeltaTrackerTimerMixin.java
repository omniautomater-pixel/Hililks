package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** 60 fps export: the game's own clock (ticks, partial ticks, animations) follows the fixed export frame counter. */
@Mixin(DeltaTracker.Timer.class)
public class DeltaTrackerTimerMixin {
    @ModifyVariable(method = "advanceGameTime(J)I", at = @At("HEAD"), argsOnly = true)
    private long guirec$game(long ms) { return ReplayPlayer.timerMs(ms); }

    @ModifyVariable(method = "advanceRealTime(J)V", at = @At("HEAD"), argsOnly = true)
    private long guirec$real(long ms) { return ReplayPlayer.timerMs(ms); }
}
