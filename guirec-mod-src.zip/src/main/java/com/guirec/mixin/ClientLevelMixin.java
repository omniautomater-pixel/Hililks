package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Block-break crack texture. The server never sends our own progress back, so it only exists client-side: record it. */
@Mixin(ClientLevel.class)
public class ClientLevelMixin {
    @Inject(method = "destroyBlockProgress(ILnet/minecraft/core/BlockPos;I)V", at = @At("HEAD"), cancellable = true)
    private void guirec$crack(int entityId, BlockPos pos, int progress, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) {
            if (ReplayPlayer.blockCrack(entityId)) ci.cancel();
            return;
        }
        var p = Minecraft.getInstance().player;
        if (p != null && p.getId() == entityId) ReplayRecorder.recCrack(pos.asLong(), progress);
    }
}
