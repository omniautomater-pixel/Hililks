package com.guirec.mixin;

import com.guirec.ChatAccess;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(ChatScreen.class)
public class ChatScreenMixin implements ChatAccess {
    @Shadow protected EditBox input;

    @Override
    public String guirec$getText() { return input == null ? "" : input.getValue(); }

    @Override
    public void guirec$setText(String s) { if (input != null && !input.getValue().equals(s)) input.setValue(s); }
}
