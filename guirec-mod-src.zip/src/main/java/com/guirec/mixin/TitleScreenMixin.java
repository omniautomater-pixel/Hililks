package com.guirec.mixin;

import com.guirec.RecorderScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds a "Replays" button on the title screen (F8 does not work in menus). */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void guirec$button(CallbackInfo ci) {
        this.addRenderableWidget(Button.builder(Component.literal("Replays"),
                b -> this.minecraft.setScreen(new RecorderScreen(this)))
                .bounds(this.width - 90, 6, 84, 20).build());
    }
}
