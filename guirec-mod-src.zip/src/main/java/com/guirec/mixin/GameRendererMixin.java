package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void guirec$frame(DeltaTracker tracker, boolean tick, CallbackInfo ci) {
        ReplayRecorder.onFrame(Minecraft.getInstance());
        ReplayPlayer.onFrame(Minecraft.getInstance());
    }
}
