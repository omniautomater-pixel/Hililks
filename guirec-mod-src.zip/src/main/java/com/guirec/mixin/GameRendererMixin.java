package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void guirec$frame(DeltaTracker tracker, boolean tick, CallbackInfo ci) {
        ReplayRecorder.onFrame(Minecraft.getInstance());
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void guirec$beforeFrame(DeltaTracker tracker, boolean tick, CallbackInfo ci) {
        ReplayPlayer.onFrame(Minecraft.getInstance(), tracker.getGameTimeDeltaPartialTick(false));
    }

    /** View bobbing comes from the replay's own physics (walkDist / bob), not from the recording: it is the random shake while sprinting. */
    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$noBob(net.minecraft.client.renderer.state.level.CameraRenderState state, com.mojang.blaze3d.vertex.PoseStack pose, CallbackInfo ci) {
        if (com.guirec.ReplayPlayer.suppressBob()) ci.cancel();
    }
}
