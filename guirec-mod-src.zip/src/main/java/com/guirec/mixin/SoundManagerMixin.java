package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.client.sounds.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The one place every sound goes through: record it while playing live, replace the game's own with the recorded ones in a replay. */
@Mixin(SoundManager.class)
public class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;",
            at = @At("HEAD"), cancellable = true)
    private void guirec$play(SoundInstance sound, CallbackInfoReturnable<SoundEngine.PlayResult> cir) {
        if (ReplayPlayer.isPlaying()) {
            if (ReplayPlayer.blockSound(sound)) cir.setReturnValue(SoundEngine.PlayResult.NOT_STARTED);
        } else {
            ReplayRecorder.recSound(sound);
        }
    }
}
