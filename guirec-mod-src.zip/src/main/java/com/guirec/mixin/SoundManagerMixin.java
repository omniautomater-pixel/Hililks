package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.client.sounds.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * EVERY sound the game plays (server packets, your own footsteps, block breaking, UI clicks, other mods) goes through here.
 * Recording: save it. Replay: block the game's own sounds and play only the recorded ones.
 */
@Mixin(SoundManager.class)
public class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;",
            at = @At("HEAD"), cancellable = true)
    private void guirec$play(SoundInstance s, CallbackInfoReturnable<SoundEngine.PlayResult> cir) {
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injectingSound) { cir.setReturnValue(SoundEngine.PlayResult.NOT_STARTED); return; }
        ReplayRecorder.sound(s);
    }

    @Inject(method = "playDelayed(Lnet/minecraft/client/resources/sounds/SoundInstance;I)V", at = @At("HEAD"), cancellable = true)
    private void guirec$playDelayed(SoundInstance s, int delay, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injectingSound) { ci.cancel(); return; }
        ReplayRecorder.sound(s);
    }
}
