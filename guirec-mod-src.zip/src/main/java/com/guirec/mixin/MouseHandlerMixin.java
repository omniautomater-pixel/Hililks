package com.guirec.mixin;

import com.guirec.MouseAccess;
import com.guirec.ReplayPlayer;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class MouseHandlerMixin implements MouseAccess {
    @Shadow private double xpos;
    @Shadow private double ypos;

    @Override
    public void guirec$set(double x, double y) { this.xpos = x; this.ypos = y; }

    /** While a replay plays, real mouse movement must not move the replay cursor. */
    @Inject(method = "onMove", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$noMove(long window, double x, double y, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) ci.cancel();
    }
}
