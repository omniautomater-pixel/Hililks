package com.guirec.mixin;

import com.guirec.MouseAccess;
import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin implements MouseAccess {
    @Shadow private double xpos;
    @Shadow private double ypos;
    @Shadow protected abstract void onButton(long window, MouseButtonInfo info, int action);
    @Shadow protected abstract void onMove(long window, double x, double y);
    @Shadow protected abstract void onScroll(long window, double dx, double dy);

    @Override public void guirec$set(double x, double y) { this.xpos = x; this.ypos = y; }
    @Override public void guirec$button(long w, int button, int mods, int action) { onButton(w, new MouseButtonInfo(button, mods), action); }
    @Override public void guirec$move(long w, double x, double y) { onMove(w, x, y); }
    @Override public void guirec$scroll(long w, double dx, double dy) { onScroll(w, dx, dy); }

    @Inject(method = "onMove(JDD)V", at = @At("HEAD"), cancellable = true)
    private void guirec$hookMove(long window, double x, double y, CallbackInfo ci) {
        if (!ReplayPlayer.injecting) ReplayPlayer.lastWindow = window;
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injecting && !ReplayPlayer.controlsOpen()) { ci.cancel(); return; }
        ReplayRecorder.inputMove(x, y);
    }

    @Inject(method = "onButton(JLnet/minecraft/client/input/MouseButtonInfo;I)V", at = @At("HEAD"), cancellable = true)
    private void guirec$hookButton(long window, MouseButtonInfo info, int action, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injecting && !ReplayPlayer.controlsOpen()) { ci.cancel(); return; }
        ReplayRecorder.inputButton(info.button(), info.modifiers(), action);
    }

    @Inject(method = "onScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void guirec$hookScroll(long window, double dx, double dy, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injecting && !ReplayPlayer.controlsOpen()) { ci.cancel(); return; }
        ReplayRecorder.inputScroll(dx, dy);
    }
}
