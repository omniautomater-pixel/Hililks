package com.guirec;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModOrigin;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.*;
import java.util.*;

/**
 * Turn mods off / on for a clean export (fps-boost mods that lower the picture quality).
 * A loaded mod can NOT be unloaded while the game runs, so this renames the jar in the mods folder (x.jar <-> x.jar.disabled):
 * restart the game, export, come back here, "Enable all", restart again. If the system refuses the rename (Windows locks loaded jars)
 * the message says so: then close the game and rename the file by hand.
 */
public class ModsScreen extends Screen {
    private final Screen parent;
    private int page;
    private static final int PER_PAGE = 6;
    private String msg = "";
    private final Path modsDir = FabricLoader.getInstance().getGameDir().resolve("mods");

    private record Entry(Path file, String name, boolean enabled) {}

    public ModsScreen(Screen parent) {
        super(Component.literal("Mods for export"));
        this.parent = parent;
    }

    private List<Entry> entries() {
        Map<Path, String> names = new HashMap<>();
        Set<Path> protectedJars = new HashSet<>();
        try {
            for (ModContainer m : FabricLoader.getInstance().getAllMods()) {
                if (m.getOrigin().getKind() != ModOrigin.Kind.PATH) continue;
                String id = m.getMetadata().getId();
                for (Path p : m.getOrigin().getPaths()) {
                    Path n = p.toAbsolutePath().normalize();
                    names.putIfAbsent(n, m.getMetadata().getName());
                    if (id.equals("guirec") || id.equals("fabric-api") || id.equals("fabricloader")) protectedJars.add(n);
                }
            }
        } catch (Throwable ignored) {}
        List<Entry> out = new ArrayList<>();
        try (var s = Files.list(modsDir)) {
            s.forEach(p -> {
                String f = p.getFileName().toString();
                boolean on = f.endsWith(".jar"), off = f.endsWith(".jar.disabled");
                if (!on && !off) return;
                Path n = p.toAbsolutePath().normalize();
                if (protectedJars.contains(n)) return;
                String nm = names.getOrDefault(n, f.replace(".disabled", ""));
                out.add(new Entry(p, nm, on));
            });
        } catch (Throwable t) { msg = "Cannot read the mods folder: " + t; }
        out.sort(Comparator.comparing((Entry e) -> e.name().toLowerCase(Locale.ROOT)));
        return out;
    }

    private boolean toggle(Entry e) {
        try {
            String f = e.file().getFileName().toString();
            Path to = e.enabled() ? e.file().resolveSibling(f + ".disabled") : e.file().resolveSibling(f.substring(0, f.length() - ".disabled".length()));
            Files.move(e.file(), to);
            msg = "Done. Restart the game for it to apply.";
            return true;
        } catch (Throwable t) {
            msg = "Could not rename (locked by the game?): " + t.getClass().getSimpleName() + " - close the game and rename the jar by hand";
            return false;
        }
    }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = 30;
        List<Entry> all = entries();
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        for (Entry e : all.subList(page * PER_PAGE, Math.min(all.size(), (page + 1) * PER_PAGE))) {
            String label = (e.enabled() ? "ON   " : "OFF  ") + e.name();
            addRenderableWidget(Button.builder(Component.literal(label), b -> { toggle(e); this.rebuildWidgets(); })
                    .bounds(cx, y, 240, 20).build());
            y += 24;
        }
        if (pages > 1) {
            addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> { page--; this.rebuildWidgets(); })
                    .bounds(cx, y, 76, 20).build()).active = page > 0;
            addRenderableWidget(Button.builder(Component.literal("Next >"), b -> { page++; this.rebuildWidgets(); })
                    .bounds(cx + 164, y, 76, 20).build()).active = page < pages - 1;
        }
        addRenderableWidget(Button.builder(Component.literal("Enable all"), b -> {
            for (Entry e : entries()) if (!e.enabled()) toggle(e);
            this.rebuildWidgets();
        }).bounds(cx, this.height - 52, 118, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(cx + 122, this.height - 52, 118, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), 12, 0xFFFFFFFF);
        line(g, "Click a mod to switch it off / on. Applies after a game restart.", this.height - 28, 0xFFAAAAAA);
        if (!msg.isEmpty()) line(g, msg, this.height - 14, 0xFFFFDD66);
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
