package com.guirec;
/** Implemented by MouseHandlerMixin so the replay can place the cursor. */
public interface MouseAccess { void guirec$set(double x, double y); }
