package com.guirec;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundForgetLevelChunkPacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.world.level.ChunkPos;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Consumer;

/**
 * "Far record": while recording, tell the server our view distance is "view" chunks (slider, default 32) so it sends 32 chunks of data
 * (all of it is saved in the .guirec file by the normal packet recorder), but the live game only LOADS the chunks
 * within "near" chunks of the player. The other chunk packets are held in memory (not loaded, not lit, not rendered)
 * and are handed to the game later, the moment the player gets within "near" chunks of them.
 * In the replay everything is played back normally, so all 32 chunks are there.
 * Everything here is OFF by default; when OFF (or when not recording / replaying) the game behaves exactly like before.
 */
public final class FarChunks {
    public static final int MAX_CHUNKS = 64;
    private static volatile int view = 32;   // view distance reported to the server while recording (chunks that get recorded)
    private static volatile int near = 2;    // chunks around the player that are really loaded while recording
    public static int view() { return view; }
    public static int near() { return near; }
    public static void setView(int v) { view = Math.max(1, Math.min(MAX_CHUNKS, v)); }
    public static void setNear(int v) { near = Math.max(1, Math.min(MAX_CHUNKS, v)); }

    private static volatile boolean enabled = false;
    public static boolean isEnabled() { return enabled; }

    private static final class Entry {
        final ClientboundLevelChunkWithLightPacket chunk;
        final List<Consumer<ClientPacketListener>> ops = new ArrayList<>();
        Entry(ClientboundLevelChunkWithLightPacket c) { chunk = c; }
    }

    private static final Map<Long, Entry> held = new HashMap<>();
    private static ClientLevel heldLevel;
    private static boolean releasing;

    // ---- settings (kept in .minecraft/guirec/far.properties)
    private static Path cfg() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("far.properties"); }

    public static void setEnabled(boolean v) { enabled = v; save(); }

    public static void save() {
        try {
            Path p = cfg();
            Files.createDirectories(p.getParent());
            Properties pr = new Properties();
            pr.setProperty("far", String.valueOf(enabled));
            pr.setProperty("view", String.valueOf(view));
            pr.setProperty("near", String.valueOf(near));
            try (OutputStream o = Files.newOutputStream(p)) { pr.store(o, "LMC Recorder far-record"); }
        } catch (Exception ignored) {}
    }

    public static void init() {
        try {
            Path p = cfg();
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (InputStream i = Files.newInputStream(p)) { pr.load(i); }
                enabled = Boolean.parseBoolean(pr.getProperty("far", "false"));
                setView(Integer.parseInt(pr.getProperty("view", "32").trim()));
                setNear(Integer.parseInt(pr.getProperty("near", "2").trim()));
            }
        } catch (Exception ignored) {}
        ClientTickEvents.END_CLIENT_TICK.register(FarChunks::tick);
    }

    /** True if the view distance sent to the server should be raised (used by OptionsMixin). */
    public static boolean wantFar() {
        return enabled && ReplayRecorder.autoRecord && !ReplayPlayer.isPlaying();
    }

    // ---- state helpers (main thread only)
    private static boolean usable(Minecraft mc) {
        if (!enabled || ReplayPlayer.isPlaying() || releasing || !ReplayRecorder.isActive()) return false;
        if (!mc.isSameThread() || mc.level == null || mc.player == null) return false;
        if (heldLevel != mc.level) { held.clear(); heldLevel = mc.level; }   // new world / dimension: old packets are useless
        return true;
    }

    private static long key(int x, int z) { return ChunkPos.pack(x, z); }

    private static boolean near(Minecraft mc, int cx, int cz) {
        ChunkPos pc = mc.player.chunkPosition();
        int n = near;
        return Math.abs(cx - pc.x()) <= n && Math.abs(cz - pc.z()) <= n;
    }

    // ---- called by FarChunksMixin; true = cancel the vanilla handler (packet was held / swallowed)
    public static boolean hold(ClientboundLevelChunkWithLightPacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (!usable(mc)) return false;
        long k = key(p.getX(), p.getZ());
        if (near(mc, p.getX(), p.getZ())) { held.remove(k); return false; }
        held.put(k, new Entry(p));
        return true;
    }

    private static boolean addOp(int cx, int cz, Consumer<ClientPacketListener> op) {
        Minecraft mc = Minecraft.getInstance();
        if (!usable(mc)) return false;
        Entry e = held.get(key(cx, cz));
        if (e == null) return false;
        if (e.ops.size() < 2000) e.ops.add(op);
        return true;
    }

    public static boolean light(ClientboundLightUpdatePacket p) {
        return addOp(p.getX(), p.getZ(), l -> l.handleLightUpdatePacket(p));
    }
    public static boolean block(ClientboundBlockUpdatePacket p) {
        return addOp(p.getPos().getX() >> 4, p.getPos().getZ() >> 4, l -> l.handleBlockUpdate(p));
    }
    public static boolean section(ClientboundSectionBlocksUpdatePacket p) {
        if (!usable(Minecraft.getInstance())) return false;
        int[] c = new int[2];
        boolean[] got = {false};
        p.runUpdates((pos, st) -> { if (!got[0]) { got[0] = true; c[0] = pos.getX() >> 4; c[1] = pos.getZ() >> 4; } });
        return got[0] && addOp(c[0], c[1], l -> l.handleChunkBlocksUpdate(p));
    }
    public static boolean blockEntity(ClientboundBlockEntityDataPacket p) {
        return addOp(p.getPos().getX() >> 4, p.getPos().getZ() >> 4, l -> l.handleBlockEntityData(p));
    }
    public static boolean forget(ClientboundForgetLevelChunkPacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (!usable(mc)) return false;
        return held.remove(key(p.pos().x(), p.pos().z())) != null;   // never loaded: nothing to forget
    }

    // ---- every tick: give the game the held chunks that the player has come close to
    private static void tick(Minecraft mc) {
        if (held.isEmpty() && heldLevel == null) return;
        if (mc.level == null || mc.player == null) { held.clear(); heldLevel = null; return; }
        if (!usable(mc) || held.isEmpty()) { if (!enabled || !ReplayRecorder.isActive()) held.clear(); return; }
        ClientPacketListener l = mc.getConnection();
        if (l == null) return;
        ChunkPos pc = mc.player.chunkPosition();
        int n = near;
        for (int dx = -n; dx <= n; dx++) for (int dz = -n; dz <= n; dz++) {
            Entry e = held.remove(key(pc.x() + dx, pc.z() + dz));
            if (e == null) continue;
            releasing = true;
            try {
                l.handleLevelChunkWithLight(e.chunk);
                for (Consumer<ClientPacketListener> op : e.ops) op.accept(l);
            } catch (Throwable t) { t.printStackTrace(); }
            finally { releasing = false; }
        }
    }
}
