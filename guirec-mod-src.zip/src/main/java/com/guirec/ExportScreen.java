package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;

/** Opens when "Export" is clicked: quality (output height) + FPS slider (1..120, like the FOV slider), then Start. */
public class ExportScreen extends Screen {
    private static final int[] HEIGHTS = {720, 1080, 1440, 2160, 0};
    private static final String[] NAMES = {"720p (1K)", "1080p (Full HD)", "1440p (2K)", "2160p (4K)", "Original (game window size)"};
    private final Screen parent;
    private final Path replay;

    public ExportScreen(Screen parent, Path replay) {
        super(Component.literal("Export video"));
        this.parent = parent;
        this.replay = replay;
    }

    private static int idx() {
        for (int i = 0; i < HEIGHTS.length; i++) if (HEIGHTS[i] == ReplayExport.height) return i;
        return 1;
    }

    private Component qualityLabel() { return Component.literal("Quality: " + NAMES[idx()]); }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = this.height / 2 - 74;
        if (ReplayExport.renderDist <= 0) ReplayExport.renderDist = Math.max(2, Math.min(64, this.minecraft.options.renderDistance().get()));
        addRenderableWidget(Button.builder(qualityLabel(), b -> {
            ReplayExport.height = HEIGHTS[(idx() + 1) % HEIGHTS.length];
            b.setMessage(qualityLabel());
        }).bounds(cx, y, 240, 20).build());
        y += 24;
        addRenderableWidget(new FpsSlider(cx, y, 240));
        y += 24;
        addRenderableWidget(new RenderSlider(cx, y, 240));
        y += 24;
        addRenderableWidget(Button.builder(Component.literal("Mods on / off (fps-boost mods)..."), b -> this.minecraft.setScreen(new ModsScreen(this)))
                .bounds(cx, y, 240, 20).build());
        y += 28;
        addRenderableWidget(Button.builder(Component.literal("Start export"), b -> {
            this.minecraft.setScreen(null);
            ReplayPlayer.cleanupStale(this.minecraft);
            ReplayExport.start(this.minecraft, replay);
        }).bounds(cx, y, 240, 20).build());
        y += 24;
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(cx, y, 240, 20).build());
    }

    /** 2..64 chunks: render distance used only while exporting (your own setting is put back afterwards). */
    private static final class RenderSlider extends AbstractSliderButton {
        RenderSlider(int x, int y, int w) {
            super(x, y, w, 20, Component.empty(), (Math.max(2, Math.min(64, ReplayExport.renderDist)) - 2) / 62.0);
            updateMessage();
        }
        private int val() { return 2 + (int) Math.round(this.value * 62); }
        @Override protected void updateMessage() { setMessage(Component.literal("Render distance: " + val() + " chunks")); }
        @Override protected void applyValue() { ReplayExport.renderDist = val(); }
    }

    /** 1..120 fps slider. */
    private static final class FpsSlider extends AbstractSliderButton {
        FpsSlider(int x, int y, int w) {
            super(x, y, w, 20, Component.empty(), (Math.max(1, Math.min(120, ReplayExport.fps)) - 1) / 119.0);
            updateMessage();
        }
        private int val() { return 1 + (int) Math.round(this.value * 119); }
        @Override protected void updateMessage() { setMessage(Component.literal("FPS: " + val())); }
        @Override protected void applyValue() { ReplayExport.fps = val(); }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        var t = this.title.getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, this.height / 2 - 98, 0xFFFFFFFF);
        var n = Component.literal("Higher fps / quality / distance = slower export.").getVisualOrderText();
        g.text(this.font, n, this.width / 2 - this.font.width(n) / 2, this.height / 2 + 76, 0xFFAAAAAA);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
