package com.guirec;

import net.minecraft.client.Minecraft;
import io.netty.buffer.Unpooled;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;


import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/**
 * STAGE 1: records every clientbound network packet (config + play, raw bytes, with timestamps)
 * plus a per-frame "view state" (camera, screen, mouse cursor) into one small .guirec file.
 * No video, no PNGs, so the game does not lag. Recording starts automatically when you join a world.
 *
 * File = Deflate stream of:  "GUIREC01" then records
 *   1 PACKET : int ms, byte phase(0=config,1=play), int len, bytes
 *   2 STATE  : int ms, double x,y,z, float yaw,pitch, byte hotbarSlot, short screenId, float mouseX, mouseY, short winW, winH,
 *              byte flags (1=swinging arm, 2=offhand), UTF chatText   (v2+)
 *              v3 adds: byte pose, byte flags2 (1 sprint,2 sneak,4 using item,8 offhand), short useTicks, long breakingPos (MIN=none), byte breakStage
 *   4 INV    : int ms, byte n, n x (byte slot(100 = cursor item), int len, bytes of ItemStack)  items the client changed itself (creative!)
 *   5 CINV   : int ms, int containerId, short n, n x (short slot, int len, bytes)   item moves inside the open chest/crafting/... menu
 *   3 SCREEN : short id, UTF className       (dictionary for screenId; 0 = no screen)
 *   0 END
 */
public final class ReplayRecorder {
    public static volatile boolean autoRecord = true;
    private static final Object LOCK = new Object();
    private static volatile boolean active = false;
    private static boolean sawPlay = false;
    private static long t0;
    private static int noLevelTicks = 0;
    private static LinkedBlockingQueue<byte[]> queue;
    private static Thread writer;
    private static volatile Path file;
    public static volatile long packets, states;
    private static final Map<String, Integer> screenIds = new HashMap<>();
    private static int lastScreenId = -1;
    private static final byte[] POISON = new byte[0];
    private static final ItemStack[] lastInv = new ItemStack[46];
    private static ItemStack lastCarried = ItemStack.EMPTY;
    private static int lastMenuId = -1;
    private static ItemStack[] lastMenu = null;

    static { Runtime.getRuntime().addShutdownHook(new Thread(ReplayRecorder::stop)); }

    public static boolean isActive() { return active; }
    public static Path file() { return file; }
    public static long fileSize() { try { return file == null ? 0 : Files.size(file); } catch (Exception e) { return 0; } }

    private static int ms() { return (int) ((System.nanoTime() - t0) / 1_000_000L); }

    /** Called from the network thread for every raw clientbound packet frame. */
    public static void onPacket(String protocol, byte[] raw) {
        if (ReplayPlayer.isPlaying()) return;   // never record a replay while playing one
        boolean config = protocol.equals("CONFIGURATION");
        boolean play = protocol.equals("PLAY");
        if (!config && !play) return;
        synchronized (LOCK) {
            if (!active) {
                if (!autoRecord || !config) return;   // can only start cleanly at the start of a connection
                start();
                if (!active) return;
            }
            if (play) sawPlay = true;
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(raw.length + 16);
                DataOutputStream d = new DataOutputStream(bo);
                d.writeByte(1); d.writeInt(ms()); d.writeByte(play ? 1 : 0); d.writeInt(raw.length); d.write(raw);
                queue.add(bo.toByteArray());
                packets++;
            } catch (IOException ignored) {}
        }
    }

    /** Called once per rendered frame (render thread). */
    public static void onFrame(Minecraft mc) {
        if (!active || ReplayPlayer.isPlaying()) return;
        synchronized (LOCK) {
            if (!active) return;
            if (mc.level == null || mc.player == null) {
                if (sawPlay && ++noLevelTicks > 120) stopLocked();
                return;
            }
            noLevelTicks = 0;
            try {
                int sid = 0;
                if (mc.screen != null) {
                    String n = mc.screen.getClass().getName();
                    Integer id = screenIds.get(n);
                    if (id == null) {
                        id = screenIds.size() + 1; screenIds.put(n, id);
                        ByteArrayOutputStream b = new ByteArrayOutputStream();
                        DataOutputStream dd = new DataOutputStream(b);
                        dd.writeByte(3); dd.writeShort(id); dd.writeUTF(n);
                        queue.add(b.toByteArray());
                    }
                    sid = id;
                }
                ByteArrayOutputStream bo = new ByteArrayOutputStream(64);
                DataOutputStream d = new DataOutputStream(bo);
                var p = mc.player;
                d.writeByte(2); d.writeInt(ms());
                float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
                d.writeDouble(p.xo + (p.getX() - p.xo) * pt);
                d.writeDouble(p.yo + (p.getY() - p.yo) * pt);
                d.writeDouble(p.zo + (p.getZ() - p.zo) * pt);
                d.writeFloat(p.yRotO + (p.getYRot() - p.yRotO) * pt);
                d.writeFloat(p.xRotO + (p.getXRot() - p.xRotO) * pt);
                d.writeByte(p.getInventory().getSelectedSlot());
                d.writeShort(sid);
                d.writeFloat((float) mc.mouseHandler.xpos()); d.writeFloat((float) mc.mouseHandler.ypos());
                d.writeShort(mc.getWindow().getWidth()); d.writeShort(mc.getWindow().getHeight());
                int flags = (p.swinging ? 1 : 0) | (p.swingingArm == InteractionHand.OFF_HAND ? 2 : 0)
                        | ((Math.max(0, Math.min(7, p.swingTime))) << 2);
                Object sc = mc.screen;
                String extra = "";
                if (sc instanceof ChatScreen && sc instanceof com.guirec.ChatAccess a) extra = a.guirec$getText();
                else if (sc instanceof CreativeModeInventoryScreen && sc instanceof CreativeAccess c)
                    extra = c.guirec$getTab() + ";" + c.guirec$getScroll() + ";" + c.guirec$getSearch();
                d.writeByte(flags); d.writeUTF(extra);
                d.writeByte(p.getPose().ordinal());
                d.writeByte((p.isSprinting() ? 1 : 0) | (p.isShiftKeyDown() ? 2 : 0) | (p.isUsingItem() ? 4 : 0)
                        | (p.getUsedItemHand() == InteractionHand.OFF_HAND ? 8 : 0));
                d.writeShort(Math.min(32767, p.getTicksUsingItem()));
                var gm = mc.gameMode;
                boolean brk = gm != null && gm.isDestroying() && gm instanceof DestroyAccess da && da.guirec$destroyPos() != null;
                d.writeLong(brk ? ((DestroyAccess) gm).guirec$destroyPos().asLong() : Long.MIN_VALUE);
                d.writeByte(brk ? gm.getDestroyStage() : -1);
                queue.add(bo.toByteArray());
                states++;
                writeInv(mc, p);
            } catch (IOException ignored) {}
        }
    }

    /** Items the client changed on its own (creative inventory, cursor item) never come from the server, so save them. */
    private static void writeInv(Minecraft mc, net.minecraft.client.player.LocalPlayer p) throws IOException {
        var menu = p.inventoryMenu;
        int n = Math.min(46, menu.slots.size());
        java.util.List<Integer> idx = new java.util.ArrayList<>();
        java.util.List<ItemStack> val = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            ItemStack st = menu.getSlot(i).getItem();
            if (!ItemStack.matches(st, lastInv[i])) { lastInv[i] = st.copy(); idx.add(i); val.add(lastInv[i]); }
        }
        ItemStack car = p.containerMenu.getCarried();
        if (!ItemStack.matches(car, lastCarried)) { lastCarried = car.copy(); idx.add(100); val.add(lastCarried); }
        writeMenu(mc, p);
        if (idx.isEmpty()) return;
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        DataOutputStream d = new DataOutputStream(bo);
        d.writeByte(4); d.writeInt(ms()); d.writeByte(idx.size());
        for (int k = 0; k < idx.size(); k++) {
            RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), mc.level.registryAccess());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, val.get(k));
            byte[] b = new byte[buf.readableBytes()]; buf.readBytes(b); buf.release();
            d.writeByte(idx.get(k)); d.writeInt(b.length); d.write(b);
        }
        queue.add(bo.toByteArray());
    }

    /** Moves the player makes inside an open chest / crafting table / etc. are predicted by the client and not echoed by the server. */
    private static void writeMenu(Minecraft mc, net.minecraft.client.player.LocalPlayer p) throws IOException {
        var cm = p.containerMenu;
        if (cm == p.inventoryMenu) { lastMenuId = -1; lastMenu = null; return; }
        int n = cm.slots.size();
        if (cm.containerId != lastMenuId || lastMenu == null || lastMenu.length != n) {
            lastMenuId = cm.containerId; lastMenu = new ItemStack[n];
            for (int i = 0; i < n; i++) lastMenu[i] = cm.getSlot(i).getItem().copy();
            return;
        }
        java.util.List<Integer> idx = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            ItemStack st = cm.getSlot(i).getItem();
            if (!ItemStack.matches(st, lastMenu[i])) { lastMenu[i] = st.copy(); idx.add(i); }
        }
        if (idx.isEmpty()) return;
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        DataOutputStream d = new DataOutputStream(bo);
        d.writeByte(5); d.writeInt(ms()); d.writeInt(cm.containerId); d.writeShort(idx.size());
        for (int i : idx) {
            RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), mc.level.registryAccess());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, lastMenu[i]);
            byte[] b = new byte[buf.readableBytes()]; buf.readBytes(b); buf.release();
            d.writeShort(i); d.writeInt(b.length); d.write(b);
        }
        queue.add(bo.toByteArray());
    }

    private static void start() {
        try {
            Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("replays");
            Files.createDirectories(dir);
            file = dir.resolve("replay_" + System.currentTimeMillis() + ".guirec");
            final Path f = file;
            queue = new LinkedBlockingQueue<>();
            packets = 0; states = 0; sawPlay = false; noLevelTicks = 0; screenIds.clear();
            java.util.Arrays.fill(lastInv, ItemStack.EMPTY); lastCarried = ItemStack.EMPTY; lastMenuId = -1; lastMenu = null;
            t0 = System.nanoTime();
            final LinkedBlockingQueue<byte[]> q = queue;
            writer = new Thread(() -> {
                try (DataOutputStream out = new DataOutputStream(new DeflaterOutputStream(
                        new BufferedOutputStream(new FileOutputStream(f.toFile()), 1 << 16),
                        new Deflater(1), 1 << 15, true))) {
                    out.writeBytes("GUIREC03");
                    while (true) {
                        byte[] r = q.take();
                        if (r == POISON) break;
                        out.write(r);
                    }
                    out.writeByte(0);
                } catch (Exception e) { e.printStackTrace(); }
            }, "guirec-writer");
            writer.setDaemon(false);
            writer.start();
            active = true;
        } catch (Exception e) { e.printStackTrace(); active = false; }
    }

    public static void stop() { synchronized (LOCK) { stopLocked(); } }

    private static void stopLocked() {
        if (!active) return;
        active = false;
        queue.add(POISON);
        try { writer.join(5000); } catch (InterruptedException ignored) {}
    }
}
