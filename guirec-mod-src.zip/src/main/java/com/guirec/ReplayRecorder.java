package com.guirec;

import net.minecraft.client.Minecraft;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/**
 * STAGE 1: records every clientbound network packet (config + play, raw bytes, with timestamps)
 * plus a per-frame "view state" (camera, screen, mouse cursor) into one small .guirec file.
 * No video, no PNGs, so the game does not lag. Recording starts automatically when you join a world.
 *
 * File = Deflate stream of:  "GUIREC01" then records
 *   1 PACKET : int ms, byte phase(0=config,1=play), int len, bytes
 *   2 STATE  : int ms, double x,y,z, float yaw,pitch, byte hotbarSlot, short screenId, float mouseX, mouseY, short winW, winH
 *   3 SCREEN : short id, UTF className       (dictionary for screenId; 0 = no screen)
 *   0 END
 */
public final class ReplayRecorder {
    public static volatile boolean autoRecord = true;
    private static final Object LOCK = new Object();
    private static volatile boolean active = false;
    private static boolean sawPlay = false;
    private static long t0;
    private static int noLevelTicks = 0;
    private static LinkedBlockingQueue<byte[]> queue;
    private static Thread writer;
    private static volatile Path file;
    public static volatile long packets, states;
    private static final Map<String, Integer> screenIds = new HashMap<>();
    private static int lastScreenId = -1;
    private static final byte[] POISON = new byte[0];

    static { Runtime.getRuntime().addShutdownHook(new Thread(ReplayRecorder::stop)); }

    public static boolean isActive() { return active; }
    public static Path file() { return file; }
    public static long fileSize() { try { return file == null ? 0 : Files.size(file); } catch (Exception e) { return 0; } }

    private static int ms() { return (int) ((System.nanoTime() - t0) / 1_000_000L); }

    /** Called from the network thread for every raw clientbound packet frame. */
    public static void onPacket(String protocol, byte[] raw) {
        if (ReplayPlayer.isPlaying()) return;   // never record a replay while playing one
        boolean config = protocol.equals("CONFIGURATION");
        boolean play = protocol.equals("PLAY");
        if (!config && !play) return;
        synchronized (LOCK) {
            if (!active) {
                if (!autoRecord || !config) return;   // can only start cleanly at the start of a connection
                start();
                if (!active) return;
            }
            if (play) sawPlay = true;
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(raw.length + 16);
                DataOutputStream d = new DataOutputStream(bo);
                d.writeByte(1); d.writeInt(ms()); d.writeByte(play ? 1 : 0); d.writeInt(raw.length); d.write(raw);
                queue.add(bo.toByteArray());
                packets++;
            } catch (IOException ignored) {}
        }
    }

    /** Called once per rendered frame (render thread). */
    public static void onFrame(Minecraft mc) {
        if (!active || ReplayPlayer.isPlaying()) return;
        synchronized (LOCK) {
            if (!active) return;
            if (mc.level == null || mc.player == null) {
                if (sawPlay && ++noLevelTicks > 120) stopLocked();
                return;
            }
            noLevelTicks = 0;
            try {
                int sid = 0;
                if (mc.screen != null) {
                    String n = mc.screen.getClass().getName();
                    Integer id = screenIds.get(n);
                    if (id == null) {
                        id = screenIds.size() + 1; screenIds.put(n, id);
                        ByteArrayOutputStream b = new ByteArrayOutputStream();
                        DataOutputStream dd = new DataOutputStream(b);
                        dd.writeByte(3); dd.writeShort(id); dd.writeUTF(n);
                        queue.add(b.toByteArray());
                    }
                    sid = id;
                }
                ByteArrayOutputStream bo = new ByteArrayOutputStream(64);
                DataOutputStream d = new DataOutputStream(bo);
                var p = mc.player;
                d.writeByte(2); d.writeInt(ms());
                d.writeDouble(p.getX()); d.writeDouble(p.getY()); d.writeDouble(p.getZ());
                d.writeFloat(p.getYRot()); d.writeFloat(p.getXRot());
                d.writeByte(p.getInventory().getSelectedSlot());
                d.writeShort(sid);
                d.writeFloat((float) mc.mouseHandler.xpos()); d.writeFloat((float) mc.mouseHandler.ypos());
                d.writeShort(mc.getWindow().getWidth()); d.writeShort(mc.getWindow().getHeight());
                queue.add(bo.toByteArray());
                states++;
            } catch (IOException ignored) {}
        }
    }

    private static void start() {
        try {
            Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("replays");
            Files.createDirectories(dir);
            file = dir.resolve("replay_" + System.currentTimeMillis() + ".guirec");
            final Path f = file;
            queue = new LinkedBlockingQueue<>();
            packets = 0; states = 0; sawPlay = false; noLevelTicks = 0; screenIds.clear();
            t0 = System.nanoTime();
            final LinkedBlockingQueue<byte[]> q = queue;
            writer = new Thread(() -> {
                try (DataOutputStream out = new DataOutputStream(new DeflaterOutputStream(
                        new BufferedOutputStream(new FileOutputStream(f.toFile()), 1 << 16),
                        new Deflater(1), 1 << 15, true))) {
                    out.writeBytes("GUIREC01");
                    while (true) {
                        byte[] r = q.take();
                        if (r == POISON) break;
                        out.write(r);
                    }
                    out.writeByte(0);
                } catch (Exception e) { e.printStackTrace(); }
            }, "guirec-writer");
            writer.setDaemon(false);
            writer.start();
            active = true;
        } catch (Exception e) { e.printStackTrace(); active = false; }
    }

    public static void stop() { synchronized (LOCK) { stopLocked(); } }

    private static void stopLocked() {
        if (!active) return;
        active = false;
        queue.add(POISON);
        try { writer.join(5000); } catch (InterruptedException ignored) {}
    }
}
