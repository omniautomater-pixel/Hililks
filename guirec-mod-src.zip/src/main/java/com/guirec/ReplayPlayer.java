package com.guirec;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.client.multiplayer.CommonListenerCookie;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.HandlerNames;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.ServerLinks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.ItemStack;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.InflaterInputStream;

/**
 * Plays a .guirec file inside the game (preview only).
 * Everything runs on the game's own tick timeline (1 tick = 50 ms): packets are fed once per tick and the
 * recorded camera is sampled at (tick + partialTick), exactly like the game renders, so motion stays smooth.
 */
public final class ReplayPlayer {
    private record Pkt(int ms, byte[] data) {}
    private record St(int ms, double x, double y, double z, float yaw, float pitch, int slot, int sid,
                      float mx, float my, int w, int h, int flags, String extra,
                      int pose, int f2, int useTicks, long brk, int stage) {}
    private record Inv(int ms, int cid, int[] slots, byte[][] data) {}
    private record Out(int ms, int kind, String id, int src, float vol, float pitch, double x, double y, double z, int att, boolean rel, long pos, int stage) {}
    private record In(int ms, int kind, int i1, int i2, int i3, int i4, double d1, double d2) {}

    private static volatile boolean playing = false;
    private static List<Pkt> pkts;
    private static List<St> states;
    private static List<Inv> invs, cinvs;
    private static List<In> inputs;
    private static List<Out> outs;
    private static int oi;
    private static double clockT;
    private static long lastNs;
    private static double dtAvg;          // smoothed frame time (ms) so uneven frame starts do not make the camera stutter
    private static CamTrack track;        // smooth camera path built from the recorded states
    public static volatile boolean injectingSound, injectingCrack;
    private static BufferedWriter dbg;
    private static long dbgNext;
    private static boolean hasInput, inputPrimed;
    private static int ki;
    public static volatile boolean injecting;
    public static volatile long lastWindow;
    private static Map<Integer, String> screens;
    private static int pi, si, ii, jj, tickNo, lastSidSeen;
    private static long lastBreak = Long.MIN_VALUE;
    private static EmbeddedChannel channel;
    private static Connection connection;
    private static boolean ourScreen, prevSwing;
    private static int prevSwingTime;
    public static volatile String status = "";

    public static boolean isPlaying() { return playing; }

    // ---------------------------------------------------------------- loading
    private static void load(Path f) throws IOException {
        pkts = new ArrayList<>(); states = new ArrayList<>(); invs = new ArrayList<>(); cinvs = new ArrayList<>(); inputs = new ArrayList<>(); outs = new ArrayList<>(); screens = new HashMap<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new java.util.zip.Inflater(), 1 << 15), 1 << 16))) {
            byte[] magic = new byte[8]; in.readFully(magic);
            String mg = new String(magic);
            if (!mg.equals("GUIREC01") && !mg.equals("GUIREC02") && !mg.equals("GUIREC03")) throw new IOException("Not a GUIREC file");
            boolean v2 = !mg.equals("GUIREC01"), v3 = mg.equals("GUIREC03");
            while (true) {
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }
                if (t == 0) break;
                try {
                    if (t == 1) {
                        int ms = in.readInt(); in.readUnsignedByte(); int len = in.readInt();
                        byte[] b = new byte[len]; in.readFully(b); pkts.add(new Pkt(ms, b));
                    } else if (t == 2) {
                        int ms = in.readInt();
                        double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        float yaw = in.readFloat(), pit = in.readFloat();
                        int slot = in.readUnsignedByte(); int sid = in.readShort();
                        float mx = in.readFloat(), my = in.readFloat(); int w = in.readShort(), h = in.readShort();
                        int fl = 0; String extra = "";
                        if (v2) { fl = in.readUnsignedByte(); extra = in.readUTF(); }
                        int pose = -1, f2 = 0, ut = 0, stg = -1; long brk = Long.MIN_VALUE;
                        if (v3) { pose = in.readUnsignedByte(); f2 = in.readUnsignedByte(); ut = in.readShort(); brk = in.readLong(); stg = in.readByte(); }
                        states.add(new St(ms, x, y, z, yaw, pit, slot, sid, mx, my, w, h, fl, extra, pose, f2, ut, brk, stg));
                    } else if (t == 3) {
                        int id = in.readShort(); screens.put(id, in.readUTF());
                    } else if (t == 4) {
                        int ms = in.readInt(); int n = in.readUnsignedByte();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedByte(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        invs.add(new Inv(ms, 0, sl, dt));
                    } else if (t == 5) {
                        int ms = in.readInt(); int cid = in.readInt(); int n = in.readUnsignedShort();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedShort(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        cinvs.add(new Inv(ms, cid, sl, dt));
                    } else if (t == 6) {
                        int ms = in.readInt(); int kind = in.readUnsignedByte();
                        switch (kind) {
                            case 0 -> { int a = in.readUnsignedByte(), k = in.readInt(), sc = in.readInt(), md = in.readInt(); inputs.add(new In(ms, 0, a, k, sc, md, 0, 0)); }
                            case 1 -> inputs.add(new In(ms, 1, in.readInt(), 0, 0, 0, 0, 0));
                            case 2 -> { int b = in.readInt(), md = in.readInt(), a = in.readUnsignedByte(); inputs.add(new In(ms, 2, b, md, a, 0, 0, 0)); }
                            case 3, 4 -> { double x = in.readDouble(), y = in.readDouble(); inputs.add(new In(ms, kind, 0, 0, 0, 0, x, y)); }
                            default -> throw new IOException("Bad input kind " + kind);
                        }
                    } else if (t == 7) {
                        int ms = in.readInt(); String id = in.readUTF(); int src = in.readUnsignedByte();
                        float vol = in.readFloat(), pit = in.readFloat(); double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        int att = in.readUnsignedByte(); boolean rel = in.readUnsignedByte() != 0;
                        outs.add(new Out(ms, 7, id, src, vol, pit, x, y, z, att, rel, 0, 0));
                    } else if (t == 8) {
                        int ms = in.readInt(); long pos = in.readLong(); int stage = in.readByte();
                        outs.add(new Out(ms, 8, "", 0, 0, 0, 0, 0, 0, 0, false, pos, stage));
                    } else throw new IOException("Bad record type " + t);
                } catch (EOFException e) { break; }
            }
        }
        // smooth camera path (cubic curve through the recorded per-frame camera samples)
        int ns = states.size();
        double[] ts = new double[ns], tx = new double[ns], ty = new double[ns], tz = new double[ns], tyaw = new double[ns], tpit = new double[ns];
        for (int k = 0; k < ns; k++) {
            St s = states.get(k);
            ts[k] = s.ms(); tx[k] = s.x(); ty[k] = s.y(); tz[k] = s.z(); tyaw[k] = s.yaw(); tpit[k] = s.pitch();
        }
        track = new CamTrack(ts, tx, ty, tz, tyaw, tpit, ns);
    }

    // ---------------------------------------------------------------- start / stop
    public static void play(Minecraft mc, Path f) {
        if (playing) return;
        try {
            load(f);
            if (pkts.isEmpty()) { status = "Replay has no packets."; return; }
            status = "Loading replay...";
            connection = new Connection(PacketFlow.CLIENTBOUND);
            channel = new EmbeddedChannel();
            Connection.configureInMemoryPipeline(channel.pipeline(), PacketFlow.CLIENTBOUND);
            channel.pipeline().addLast(HandlerNames.PACKET_HANDLER, connection);
            connection.channelActive(channel.pipeline().context(connection));

            var user = mc.getUser();
            GameProfile profile = new GameProfile(user.getProfileId(), user.getName());
            CommonListenerCookie cookie = new CommonListenerCookie(
                    new LevelLoadTracker(), profile,
                    mc.getTelemetryManager().createWorldSessionManager(false, null, null),
                    RegistryAccess.EMPTY, FeatureFlags.DEFAULT_FLAGS, "vanilla", null, null,
                    Map.of(), mc.gui.getChat().storeState(), Map.of(), ServerLinks.EMPTY, Map.of(), false);
            var listener = new ClientConfigurationPacketListenerImpl(mc, connection, cookie);
            connection.setupInboundProtocol(ConfigurationProtocols.CLIENTBOUND, listener);
            connection.setupOutboundProtocol(ConfigurationProtocols.SERVERBOUND);

            hasInput = !inputs.isEmpty(); inputPrimed = false; ki = 0; injecting = false;
            oi = 0; clockT = 0; lastNs = 0; dtAvg = 0; injectingSound = false; injectingCrack = false;
            try { Path dp = mc.gameDirectory.toPath().resolve("guirec").resolve("replay_debug.log"); Files.createDirectories(dp.getParent()); dbg = Files.newBufferedWriter(dp); dbgNext = 0; } catch (Exception ignored) { dbg = null; }
            pi = 0; si = 0; ii = 0; jj = 0; tickNo = 0; lastSidSeen = 0; lastBreak = Long.MIN_VALUE; ourScreen = false; prevSwing = false; prevSwingTime = 0;
            playing = true;
            ReplayRecorder.stop();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Could not start replay: " + t;
            playing = false;
        }
    }

    public static void stop(Minecraft mc) {
        if (!playing) return;
        playing = false;
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; track = null; pkts = null; states = null; invs = null; cinvs = null; inputs = null; outs = null; injecting = false;
        try { if (dbg != null) dbg.close(); } catch (Exception ignored) {} dbg = null;
        mc.disconnect(new TitleScreen(), false);
    }

    // ---------------------------------------------------------------- once per game tick
    public static void onTick(Minecraft mc) {
        if (!playing) return;
        try {
            tickNo++;
            channel.releaseOutbound();
            connection.tick();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    // ---------------------------------------------------------------- ONE timeline for packets AND input
    /**
     * Packets and recorded input are processed together, strictly in the order (and at the millisecond) they happened,
     * at the start of every frame, exactly like the real game processes network tasks and input.
     * Heavy bursts (chunk loading) are spread over a few frames so the preview does not freeze.
     */
    private static void feed(Minecraft mc, int F) {
        long t0 = System.nanoTime();
        St sref = (states == null || states.isEmpty()) ? null : states.get(Math.min(si, states.size() - 1));
        var w = mc.getWindow();
        double sx = sref != null && sref.w() > 0 ? w.getWidth() / (double) sref.w() : 1.0;
        double sy = sref != null && sref.h() > 0 ? w.getHeight() / (double) sref.h() : 1.0;
        long win = lastWindow != 0 ? lastWindow : org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        try {
            while (true) {
                boolean ready = mc.level != null && mc.player != null;
                if (ready && !inputPrimed) {
                    while (ki < inputs.size() && inputs.get(ki).ms() < F - 100) ki++;   // skip what happened while loading
                    while (oi < outs.size() && outs.get(oi).ms() < F - 100) oi++;
                    inputPrimed = true;
                }
                int pm = pi < pkts.size() ? pkts.get(pi).ms() : Integer.MAX_VALUE;
                int im = hasInput && ready && ki < inputs.size() ? inputs.get(ki).ms() : Integer.MAX_VALUE;
                int om = ready && oi < outs.size() ? outs.get(oi).ms() : Integer.MAX_VALUE;
                int m = Math.min(pm, Math.min(im, om));
                if (m > F) break;
                if (System.nanoTime() - t0 > 8_000_000L && F - m < 400) break;   // time budget (unless we are far behind)
                if (pm <= im && pm <= om) {
                    ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                    if (ctx == null) break;
                    ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                    pi++;
                } else if (im <= om) {
                    In e = inputs.get(ki++);
                    injecting = true;
                    try {
                        switch (e.kind()) {
                            case 0 -> { if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$key(win, e.i1(), e.i2(), e.i3(), e.i4()); }
                            case 1 -> { if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$char(win, e.i1()); }
                            case 2 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$button(win, e.i1(), e.i2(), e.i3()); }
                            case 3 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$move(win, e.d1() * sx, e.d2() * sy); }
                            case 4 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$scroll(win, e.d1(), e.d2()); }
                            default -> {}
                        }
                    } finally { injecting = false; }
                } else {
                    Out o = outs.get(oi++);
                    if (o.kind() == 7) {
                        var inst = new net.minecraft.client.resources.sounds.SimpleSoundInstance(
                                net.minecraft.resources.Identifier.parse(o.id()),
                                net.minecraft.sounds.SoundSource.values()[Math.min(o.src(), net.minecraft.sounds.SoundSource.values().length - 1)],
                                o.vol(), o.pitch(), net.minecraft.util.RandomSource.create(), false, 0,
                                net.minecraft.client.resources.sounds.SoundInstance.Attenuation.values()[Math.min(o.att(), 1)],
                                o.x(), o.y(), o.z(), o.rel());
                        injectingSound = true;
                        try { mc.getSoundManager().play(inst); } finally { injectingSound = false; }
                    } else {
                        injectingCrack = true;
                        try { mc.level.destroyBlockProgress(mc.player.getId(), BlockPos.of(o.pos()), o.stage()); }
                        finally { injectingCrack = false; }
                    }
                }
            }
            if (pi >= pkts.size() && F > pkts.get(pkts.size() - 1).ms() + 3000) status = "Replay finished. Press F7 to leave.";
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    /** One line per second into .minecraft/guirec/replay_debug.log: send this file if something does not replay right. */
    private static void debug(Minecraft mc, int F) {
        if (dbg == null) return;
        long nowMs = System.currentTimeMillis();
        if (nowMs < dbgNext) return;
        dbgNext = nowMs + 1000;
        try {
            String hit = mc.hitResult == null ? "null" : mc.hitResult.getType().toString();
            dbg.write(String.format("T=%d pkt=%d/%d input=%d/%d out=%d/%d level=%b screen=%s grabbed=%b attackDown=%b hit=%s ground=%s slot=%s%n",
                    F, pi, pkts.size(), ki, inputs.size(), oi, outs.size(), mc.level != null,
                    mc.screen == null ? "none" : mc.screen.getClass().getSimpleName(),
                    mc.mouseHandler.isMouseGrabbed(), mc.options.keyAttack.isDown(), hit,
                    mc.player == null ? "-" : String.valueOf(mc.player.onGround()),
                    mc.player == null ? "-" : String.valueOf(mc.player.getInventory().getSelectedSlot())));
            dbg.flush();
        } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------------- once per frame, BEFORE it is drawn
    public static void onFrame(Minecraft mc, float partial) {
        if (!playing) return;
        // smooth replay clock: real time between frames, but a long hitch (chunk loading) never makes time jump
        // The clock advances by a smoothed frame time (moving average), so a frame that merely STARTED a bit late/early
        // does not produce a camera step. The average keeps the total equal to real time (no drift).
        long nowNs = System.nanoTime();
        if (lastNs == 0) lastNs = nowNs;
        double dt = (nowNs - lastNs) / 1_000_000.0;
        lastNs = nowNs;
        if (dt > 40.0) {
            clockT += 40.0;                                    // hitch (chunk loading): time never jumps
        } else {
            dtAvg = dtAvg == 0 ? dt : dtAvg + (dt - dtAvg) * 0.15;
            clockT += dtAvg;
        }
        int now = (int) clockT;                                // whole ms only for packets / input / state lookup
        feed(mc, now);
        debug(mc, now);
        if (!playing || states == null || states.isEmpty() || mc.player == null || mc.level == null) return;
        boolean closedEdge = false;
        while (si + 1 < states.size() && states.get(si + 1).ms() <= now) {
            si++;
            int sd = states.get(si).sid();
            if (sd == 0 && lastSidSeen != 0) closedEdge = true;
            lastSidSeen = sd;
        }
        St s = states.get(si);
        var p = mc.player;

        // camera: sampled from the smooth cubic path at the exact (fractional) replay time
        track.evalSmoothVelocity(clockT);          // also leaves the camera for clockT in track.cur
        double[] c = track.cur;
        p.setPos(c[0], c[1], c[2]);
        float yaw = (float) c[3], pit = Mth.clamp((float) c[4], -90.0f, 90.0f);
        p.setYRot(yaw); p.setXRot(pit);
        p.setOldPosAndRot();                       // old = new, so the game's own partial-tick lerp cannot add a second, wrong blend
        p.setYHeadRot(yaw); p.yHeadRotO = yaw;
        // smooth real velocity (blocks per tick) so view-bobbing and the arm sway behave
        p.setDeltaMovement(track.vel[0], track.vel[1], track.vel[2]);
        p.getInventory().setSelectedSlot(s.slot());

        if (s.pose() >= 0) p.setOnGround((s.f2() & 16) != 0);   // block-breaking speed depends on being on the ground
        // sprint comes from the recording, not from re-simulated logic: the replay's own physics can drop sprint for a tick
        // (collision at the snapped position...) which makes the sprint FOV and view-bobbing flicker
        if (s.pose() >= 0 && p.isSprinting() != ((s.f2() & 1) != 0)) p.setSprinting((s.f2() & 1) != 0);
        // arm swing from the recording, in BOTH modes: while you hold attack the game restarts the swing every few ticks.
        // Re-running the game logic alone only swung once (the swing restart depends on the re-simulated block progress,
        // which does not match the recorded block breaks). p.swing() ignores a restart that comes too early, so no double swing.
        boolean swing = (s.flags() & 1) != 0;
        int swingTime = (s.flags() >> 2) & 7;
        if (swing && (!prevSwing || swingTime < prevSwingTime))
            p.swing((s.flags() & 2) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        prevSwing = swing; prevSwingTime = swingTime;

        if (hasInput) return;   // new recordings: the real game logic re-runs on the recorded input

        // ---- old recordings without input: best-effort emulation below ----
        // items the client changed itself (creative inventory, cursor item)
        try {
            while (ii < invs.size() && invs.get(ii).ms() <= now) {
                Inv e = invs.get(ii++);
                for (int k = 0; k < e.slots().length; k++) {
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    int sl = e.slots()[k];
                    if (sl == 100) p.containerMenu.setCarried(st);
                    else if (sl < p.inventoryMenu.slots.size()) p.inventoryMenu.getSlot(sl).set(st);
                }
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // item moves inside the open menu (chest, crafting table...)
        try {
            while (jj < cinvs.size() && cinvs.get(jj).ms() <= now) {
                Inv e = cinvs.get(jj);
                if (p.containerMenu.containerId != e.cid()) {
                    if (now - e.ms() > 1500) { jj++; continue; }   // menu never opened here: drop
                    break;                                          // menu packet not here yet: wait
                }
                for (int k = 0; k < e.slots().length; k++) {
                    int sl = e.slots()[k];
                    if (sl >= p.containerMenu.slots.size()) continue;
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    p.containerMenu.getSlot(sl).set(st);
                }
                jj++;
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // client-side body state: pose, sprint, sneak, eating / bow, block-break cracks
        if (s.pose() >= 0 && s.pose() < Pose.values().length) p.setPose(Pose.values()[s.pose()]);
        p.setSprinting((s.f2() & 1) != 0);
        p.setShiftKeyDown((s.f2() & 2) != 0);
        boolean using = (s.f2() & 4) != 0;
        if (using && !p.isUsingItem()) p.startUsingItem((s.f2() & 8) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        else if (!using && p.isUsingItem()) p.stopUsingItem();
        if (s.brk() != Long.MIN_VALUE && s.stage() >= 0) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(s.brk()), s.stage());
            lastBreak = s.brk();
        } else if (lastBreak != Long.MIN_VALUE) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(lastBreak), -1);
            lastBreak = Long.MIN_VALUE;
        }

        // screens
        String name = s.sid() == 0 ? "" : screens.getOrDefault(s.sid(), "");
        if (name.endsWith("CreativeModeInventoryScreen")) {
            if (!(mc.screen instanceof CreativeModeInventoryScreen)) {
                mc.setScreen(new CreativeModeInventoryScreen(p, FeatureFlags.DEFAULT_FLAGS, true)); ourScreen = true;
            }
            if (mc.screen instanceof CreativeAccess ca) {
                String[] parts = s.extra().split(";", 3);
                try {
                    if (parts.length >= 1) ca.guirec$setTab(Integer.parseInt(parts[0]));
                    if (parts.length >= 2) ca.guirec$setScroll(Float.parseFloat(parts[1]));
                    if (parts.length >= 3) ca.guirec$setSearch(parts[2]);
                } catch (NumberFormatException ignored) {}
            }
        } else if (name.endsWith("InventoryScreen")) {
            if (!(mc.screen instanceof InventoryScreen)) { mc.setScreen(new InventoryScreen(p)); ourScreen = true; }
        } else if (name.endsWith("PauseScreen")) {
            if (!(mc.screen instanceof PauseScreen)) { mc.setScreen(new PauseScreen(true)); ourScreen = true; }
        } else if (name.endsWith("ChatScreen")) {
            if (!(mc.screen instanceof ChatScreen)) { mc.setScreen(new ChatScreen("", false)); ourScreen = true; }
            if (mc.screen instanceof ChatAccess ca) ca.guirec$setText(s.extra());
        } else if (name.isEmpty() && mc.screen != null) {
            // recorded: no screen open. Close containers (the server never tells us when the player closes one).
            if (mc.screen instanceof AbstractContainerScreen<?>) { if (closedEdge) { p.closeContainer(); ourScreen = false; } }
            else if (ourScreen) { mc.setScreen(null); ourScreen = false; }
        }

        if (mc.screen != null && s.w() > 0 && s.h() > 0 && mc.mouseHandler instanceof MouseAccess m) {
            var w = mc.getWindow();
            m.guirec$set(s.mx() * w.getWidth() / s.w(), s.my() * w.getHeight() / s.h());
        }
    }
}
