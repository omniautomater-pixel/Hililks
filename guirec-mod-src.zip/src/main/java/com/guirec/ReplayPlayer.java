package com.guirec;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.client.multiplayer.CommonListenerCookie;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.HandlerNames;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.ServerLinks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.ItemStack;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.InflaterInputStream;

/**
 * Plays a .guirec file inside the game (preview only).
 * Everything runs on the game's own tick timeline (1 tick = 50 ms): packets are fed once per tick and the
 * recorded camera is sampled at (tick + partialTick), exactly like the game renders, so motion stays smooth.
 */
public final class ReplayPlayer {
    private record Pkt(int ms, byte[] data) {}
    private record St(int ms, double x, double y, double z, float yaw, float pitch, int slot, int sid,
                      float mx, float my, int w, int h, int flags, String extra,
                      int pose, int f2, int useTicks, long brk, int stage) {}
    private record Inv(int ms, int cid, int[] slots, byte[][] data) {}
    private record Out(int ms, int kind, String id, int src, float vol, float pitch, double x, double y, double z, int att, boolean rel, long pos, int stage) {}
    private record In(int ms, int kind, int i1, int i2, int i3, int i4, double d1, double d2) {}

    private static volatile boolean playing = false;
    private static List<Pkt> pkts;
    private static List<St> states;
    private static List<Inv> invs, cinvs;
    private static List<In> inputs;
    private static List<Out> outs;
    private static int oi;
    private static double clockT;
    private static long lastNs;
    private static double dtAvg;          // smoothed frame time (ms) so uneven frame starts do not make the camera stutter
    private static CamTrack track;        // smooth camera path built from the recorded states
    public static volatile boolean injectingSound, injectingCrack;

    // ---- sound bookkeeping: recorded sounds are played, and a sound the GAME makes by itself is only blocked if the same
    // sound was recorded around that moment (so nothing is played twice, and nothing the recording missed is lost)
    public static volatile int soundsLoaded, soundsInjected;
    public static volatile String soundLast = "-";
    private static volatile int soundClock;
    private static final String[] recentId = new String[48];
    private static final int[] recentMs = new int[48];
    private static int recentPos;

    private static void rememberInjected(String id, int ms) { recentId[recentPos] = id; recentMs[recentPos] = ms; recentPos = (recentPos + 1) % recentId.length; }

    /** True = the recording has this very sound (just played, or about to), so the game's own copy must stay silent. */
    public static boolean blockGameSound(net.minecraft.client.resources.sounds.SoundInstance si) {
        try {
            String id = String.valueOf(si.getIdentifier());
            int F = soundClock;
            for (int i = 0; i < recentId.length; i++) if (id.equals(recentId[i]) && Math.abs(F - recentMs[i]) <= 160) return true;
            List<Out> o = outs;
            if (o == null) return false;
            for (int k = oi; k < o.size(); k++) {
                Out e = o.get(k);
                if (e.ms() > F + 160) break;
                if (e.kind() == 7 && id.equals(e.id())) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }
    private static BufferedWriter dbg;
    private static long dbgNext;
    private static boolean hasInput, inputPrimed;
    private static int ki;
    public static volatile boolean injecting;
    public static volatile long lastWindow;
    private static Map<Integer, String> screens;
    private static int pi, si, ii, jj, tickNo, lastSidSeen;
    private static long lastBreak = Long.MIN_VALUE;
    private static EmbeddedChannel channel;
    private static Connection connection;
    private static boolean ourScreen, prevSwing;
    private static int noScreenSince = -1, containerSince = -1;
    public static volatile boolean cameraHookRan;   // GameRenderer.update ran this frame (see GameRendererMixin)
    private static boolean keepBob;                    // smooth.txt contains the word "bob": keep vanilla view bobbing in replays
    private static int fN; private static double fSum, fSq, fMax;   // frame-time stats for the debug log

    /** View bobbing is driven by the replay's own physics (not by the recording) = random sway while sprinting. Off in replays. */
    public static boolean suppressBob() { return playing && !keepBob; }
    private static int prevSwingTime;
    public static volatile String status = "";

    // ---- smooth UI cursor (v1.0.11): path of the recorded mouse cursor while a screen was open
    private static double[] cT, cX, cY;       // sample time (ms), position (recorded window pixels)
    private static boolean[] cBrk;            // true = this sample starts a new run (no curve to the previous one)
    private static int cN, cIdx;
    private static double curX, curY;         // result of cursorAt()
    private static double recX, recY;         // the exact cursor position of the last RECORDED move event
    private static boolean haveRec, smoothed; // smoothed = the cursor currently sits on the smooth path, not on the recorded point
    private static int btnMask;               // mouse buttons currently held (drags must follow the recorded points exactly)

    // ---- editor support (v1.0.12): pause, jump forward (fast-forward) and backward (restart + fast-forward)
    private static volatile boolean paused;
    private static volatile int seekTarget = -1;      // ms we are fast-forwarding to, -1 = none
    private static volatile boolean restartPending;   // jump backwards: reload the replay from 0, then fast-forward (done between frames, in onTick)
    private static int restartTarget;
    private static boolean restarting;                // the restart disconnects the world on purpose: onLeave() must not end the replay
    private static int totalMs;
    private static int readyMs = -1;                  // replay time when the world was ready the first time (a jump back never goes before it)
    private static final HashMap<Integer, int[]> heldKeys = new HashMap<>();   // keys held by the recorded input (to release them on a jump)

    public static void setPaused(boolean p) { paused = p; }
    public static boolean isPaused() { return paused; }
    public static int timeMs() { return (int) clockT; }
    /**
     * Mobs / players popped in "all at once" when you came close: the game only draws an entity closer than size * 64 blocks * viewScale
     * (Entity.shouldRenderAtSqrDistance; viewScale = the "Entity Distance" video option, default 1.0). During a replay the scale is
     * raised to the maximum (5.0) and then put back to the player's own option.
     */
    private static void farEntities(boolean on) {
        try {
            var mc = Minecraft.getInstance();
            net.minecraft.world.entity.Entity.setViewScale(on ? 5.0 : mc.options.entityDistanceScaling().get());
        } catch (Throwable ignored) {}
    }
    public static boolean worldReady() { return readyMs >= 0; }
    private static int expSeen = -1;
    public static int totalMs() { return totalMs; }
    public static boolean seeking() { return seekTarget >= 0 || restartPending; }
    /** While the editor is open (replay paused) the REAL mouse / keyboard work, the replay's own input is stopped. */
    public static boolean realInput() { return playing && paused && ReplayEditor.active; }

    /** Jump to ms: forward = fast-forward through the packets, backward = reload the replay and fast-forward (the world has to be rebuilt). */
    public static void seekTo(int ms) {
        if (!playing || pkts == null) return;
        ms = Math.max(0, Math.min(totalMs, ms));
        if (ms >= (int) clockT) { seekTarget = ms; restartPending = false; }
        else { restartPending = true; restartTarget = ms; seekTarget = -1; }
        status = "Seeking...";
    }

    public static boolean isPlaying() { return playing; }

    // ---------------------------------------------------------------- loading
    private static void load(Path f) throws IOException {
        soundsLoaded = 0;
        pkts = new ArrayList<>(); states = new ArrayList<>(); invs = new ArrayList<>(); cinvs = new ArrayList<>(); inputs = new ArrayList<>(); outs = new ArrayList<>(); screens = new HashMap<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new java.util.zip.Inflater(), 1 << 15), 1 << 16))) {
            byte[] magic = new byte[8]; in.readFully(magic);
            String mg = new String(magic);
            if (!mg.equals("GUIREC01") && !mg.equals("GUIREC02") && !mg.equals("GUIREC03")) throw new IOException("Not a GUIREC file");
            boolean v2 = !mg.equals("GUIREC01"), v3 = mg.equals("GUIREC03");
            while (true) {
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }
                if (t == 0) break;
                try {
                    if (t == 1) {
                        int ms = in.readInt(); in.readUnsignedByte(); int len = in.readInt();
                        byte[] b = new byte[len]; in.readFully(b); pkts.add(new Pkt(ms, b));
                    } else if (t == 2) {
                        int ms = in.readInt();
                        double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        float yaw = in.readFloat(), pit = in.readFloat();
                        int slot = in.readUnsignedByte(); int sid = in.readShort();
                        float mx = in.readFloat(), my = in.readFloat(); int w = in.readShort(), h = in.readShort();
                        int fl = 0; String extra = "";
                        if (v2) { fl = in.readUnsignedByte(); extra = in.readUTF(); }
                        int pose = -1, f2 = 0, ut = 0, stg = -1; long brk = Long.MIN_VALUE;
                        if (v3) { pose = in.readUnsignedByte(); f2 = in.readUnsignedByte(); ut = in.readShort(); brk = in.readLong(); stg = in.readByte(); }
                        states.add(new St(ms, x, y, z, yaw, pit, slot, sid, mx, my, w, h, fl, extra, pose, f2, ut, brk, stg));
                    } else if (t == 3) {
                        int id = in.readShort(); screens.put(id, in.readUTF());
                    } else if (t == 4) {
                        int ms = in.readInt(); int n = in.readUnsignedByte();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedByte(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        invs.add(new Inv(ms, 0, sl, dt));
                    } else if (t == 5) {
                        int ms = in.readInt(); int cid = in.readInt(); int n = in.readUnsignedShort();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedShort(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        cinvs.add(new Inv(ms, cid, sl, dt));
                    } else if (t == 6) {
                        int ms = in.readInt(); int kind = in.readUnsignedByte();
                        switch (kind) {
                            case 0 -> { int a = in.readUnsignedByte(), k = in.readInt(), sc = in.readInt(), md = in.readInt(); inputs.add(new In(ms, 0, a, k, sc, md, 0, 0)); }
                            case 1 -> inputs.add(new In(ms, 1, in.readInt(), 0, 0, 0, 0, 0));
                            case 2 -> { int b = in.readInt(), md = in.readInt(), a = in.readUnsignedByte(); inputs.add(new In(ms, 2, b, md, a, 0, 0, 0)); }
                            case 3, 4 -> { double x = in.readDouble(), y = in.readDouble(); inputs.add(new In(ms, kind, 0, 0, 0, 0, x, y)); }
                            default -> throw new IOException("Bad input kind " + kind);
                        }
                    } else if (t == 7) {
                        int ms = in.readInt(); String id = in.readUTF(); int src = in.readUnsignedByte();
                        float vol = in.readFloat(), pit = in.readFloat(); double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        int att = in.readUnsignedByte(); boolean rel = in.readUnsignedByte() != 0;
                        outs.add(new Out(ms, 7, id, src, vol, pit, x, y, z, att, rel, 0, 0)); soundsLoaded++;
                    } else if (t == 8) {
                        int ms = in.readInt(); long pos = in.readLong(); int stage = in.readByte();
                        outs.add(new Out(ms, 8, "", 0, 0, 0, 0, 0, 0, 0, false, pos, stage));
                    } else throw new IOException("Bad record type " + t);
                } catch (EOFException e) { break; }
            }
        }
        // smooth camera path (cubic curve through the recorded per-frame camera samples)
        int ns = states.size();
        double[] ts = new double[ns], tx = new double[ns], ty = new double[ns], tz = new double[ns], tyaw = new double[ns], tpit = new double[ns];
        for (int k = 0; k < ns; k++) {
            St s = states.get(k);
            ts[k] = s.ms(); tx[k] = s.x(); ty[k] = s.y(); tz[k] = s.z(); tyaw[k] = s.yaw(); tpit[k] = s.pitch();
        }
        // strength knob: .minecraft/guirec/smooth.txt containing a number (1 = default, 2 = smoother, 0 = off)
        double strength = 1.0;
        keepBob = false;
        try {
            Path cfg = f.toAbsolutePath().getParent().getParent().resolve("smooth.txt");
            if (Files.exists(cfg)) {
                String txt = Files.readString(cfg).trim();
                keepBob = txt.toLowerCase().contains("bob");
                String first = txt.split("\\s+")[0];
                try { strength = Math.max(0.0, Math.min(6.0, Double.parseDouble(first))); } catch (NumberFormatException ignored) {}
            }
        } catch (Exception ignored) {}
        track = new CamTrack(ts, tx, ty, tz, tyaw, tpit, ns, strength);
        buildCursor();
        totalMs = !states.isEmpty() ? states.get(states.size() - 1).ms() : (pkts.isEmpty() ? 0 : pkts.get(pkts.size() - 1).ms());
    }

    // ---------------------------------------------------------------- smooth cursor path
    /**
     * The recording was made at e.g. 20 fps, so the mouse cursor only has ~20 positions per second (GLFW hands over all events
     * of a frame at once). Replaying them as they are shows the cursor, the carried item, hover highlights and the player model
     * in the inventory moving at 20 fps even when the replay runs at 120. Here we build a smooth monotone curve through the
     * recorded cursor positions of the time a screen was open; onFrame() then moves the cursor along it every rendered frame.
     * Several events with the same millisecond (one recorded frame) are spread over the time since the previous frame.
     */
    private static void buildCursor() {
        cN = 0; cIdx = 0;
        ArrayList<double[]> raw = new ArrayList<>();   // t, x, y, startsRun
        int sp = 0;
        boolean prevValid = false;
        double lastT = -1e9;
        for (In e : inputs) {
            if (e.kind() != 3) continue;
            while (sp < states.size() && states.get(sp).ms() < e.ms()) sp++;   // sp = first state at/after the event
            boolean valid = sp > 0 && sp < states.size() && states.get(sp).sid() != 0 && states.get(sp - 1).sid() != 0;
            if (!valid) { prevValid = false; continue; }
            boolean brk = !prevValid || e.ms() - lastT > 200;
            raw.add(new double[]{e.ms(), e.d1(), e.d2(), brk ? 1 : 0});
            prevValid = true; lastT = e.ms();
        }
        // one sample per recorded frame (same ms): spread the events of a frame over the time since the previous frame
        ArrayList<double[]> out = new ArrayList<>();
        int i = 0;
        double prevT = 0; boolean havePrev = false;
        while (i < raw.size()) {
            int j = i;
            while (j + 1 < raw.size() && raw.get(j + 1)[0] == raw.get(i)[0] && raw.get(j + 1)[3] == 0) j++;
            int n = j - i + 1;
            double t = raw.get(i)[0];
            boolean runStart = raw.get(i)[3] != 0;
            if (runStart || !havePrev || t <= prevT) {
                double[] r = raw.get(j);
                out.add(new double[]{t, r[1], r[2], 1});
            } else {
                for (int k = 0; k < n; k++) {
                    double[] r = raw.get(i + k);
                    out.add(new double[]{prevT + (t - prevT) * (k + 1) / n, r[1], r[2], 0});
                }
            }
            prevT = t; havePrev = true;
            i = j + 1;
        }
        cN = out.size();
        cT = new double[cN]; cX = new double[cN]; cY = new double[cN]; cBrk = new boolean[cN];
        for (int k = 0; k < cN; k++) { double[] r = out.get(k); cT[k] = r[0]; cX[k] = r[1]; cY[k] = r[2]; cBrk[k] = r[3] != 0; }
    }

    private static double tangent(double[] y, int k) {
        boolean hp = k > 0 && !cBrk[k], hn = k + 1 < cN && !cBrk[k + 1];
        double d0 = hp ? (y[k] - y[k - 1]) / (cT[k] - cT[k - 1]) : 0, d1 = hn ? (y[k + 1] - y[k]) / (cT[k + 1] - cT[k]) : 0;
        if (!hp && !hn) return 0;
        if (!hp) return d1;
        if (!hn) return d0;
        if (d0 * d1 <= 0) return 0;                       // local extreme: flat, so the curve never overshoots
        double h0 = cT[k] - cT[k - 1], h1 = cT[k + 1] - cT[k], w1 = 2 * h1 + h0, w2 = h1 + 2 * h0;
        return (w1 + w2) / (w1 / d0 + w2 / d1);
    }

    private static double hermite(double[] y, int k, double s, double h) {
        double m0 = tangent(y, k) * h, m1 = tangent(y, k + 1) * h;
        double s2 = s * s, s3 = s2 * s;
        return (2 * s3 - 3 * s2 + 1) * y[k] + (s3 - 2 * s2 + s) * m0 + (-2 * s3 + 3 * s2) * y[k + 1] + (s3 - s2) * m1;
    }

    /** Cursor on the smooth path at time T (ms). False if T is not inside a continuous stretch of recorded cursor movement. */
    private static boolean cursorAt(double T) {
        if (cN < 2) return false;
        if (cIdx >= cN || cT[cIdx] > T) cIdx = 0;                                  // time went backwards: restart the search
        while (cIdx + 1 < cN && cT[cIdx + 1] <= T) cIdx++;
        int k = cIdx;
        if (k + 1 >= cN || cBrk[k + 1] || T < cT[k]) return false;
        double h = cT[k + 1] - cT[k], s = (T - cT[k]) / h;
        curX = hermite(cX, k, s, h); curY = hermite(cY, k, s, h);
        return true;
    }

    /** Put the cursor back on the exact recorded point before a click / scroll / key, so the game hits exactly what was hit. */
    private static void snapToRecorded(Minecraft mc, long win, double sx, double sy) {
        if (!smoothed || !haveRec) return;
        smoothed = false;
        if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$move(win, recX * sx, recY * sy);
    }

    /** Every rendered frame: move the cursor along the smooth path (only while a screen is open and no button is held). */
    private static void smoothCursor(Minecraft mc, St s) {
        if (paused || cN < 2 || mc.screen == null || btnMask != 0 || s.w() <= 0 || s.h() <= 0 || mc.mouseHandler.isMouseGrabbed()) return;
        if (!cursorAt(clockT)) return;
        var w = mc.getWindow();
        double x = curX * w.getWidth() / s.w(), y = curY * w.getHeight() / s.h();
        if (x == mc.mouseHandler.xpos() && y == mc.mouseHandler.ypos()) return;
        if (!(((Object) mc.mouseHandler) instanceof MouseAccess mm)) return;
        long win = lastWindow != 0 ? lastWindow : org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        injecting = true;
        try { mm.guirec$move(win, x, y); smoothed = true; } finally { injecting = false; }
    }

    // ---------------------------------------------------------------- start / stop
    public static void play(Minecraft mc, Path f) { play(mc, f, false); }

    /** Creates the in-memory connection that the recorded packets are fed into (the same for a start and for a restart). */
    private static void startConnection(Minecraft mc) throws Exception {
        status = "Loading replay...";
        connection = new Connection(PacketFlow.CLIENTBOUND);
        channel = new EmbeddedChannel();
        Connection.configureInMemoryPipeline(channel.pipeline(), PacketFlow.CLIENTBOUND);
        channel.pipeline().addLast(HandlerNames.PACKET_HANDLER, connection);
        connection.channelActive(channel.pipeline().context(connection));

        var user = mc.getUser();
        GameProfile profile = new GameProfile(user.getProfileId(), user.getName());
        CommonListenerCookie cookie = new CommonListenerCookie(
                new LevelLoadTracker(), profile,
                mc.getTelemetryManager().createWorldSessionManager(false, null, null),
                RegistryAccess.EMPTY, FeatureFlags.DEFAULT_FLAGS, "vanilla", null, null,
                Map.of(), mc.gui.getChat().storeState(), Map.of(), ServerLinks.EMPTY, Map.of(), false);
        var listener = new ClientConfigurationPacketListenerImpl(mc, connection, cookie);
        connection.setupInboundProtocol(ConfigurationProtocols.CLIENTBOUND, listener);
        connection.setupOutboundProtocol(ConfigurationProtocols.SERVERBOUND);
    }

    /** All replay positions back to the start (play and restart). */
    private static void resetPlayback() {
        inputPrimed = false; ki = 0; injecting = false;
        btnMask = 0; haveRec = false; smoothed = false; cIdx = 0; heldKeys.clear();
        oi = 0; clockT = 0; lastNs = 0; dtAvg = 0; injectingSound = false; injectingCrack = false;
        soundsInjected = 0; soundLast = "-"; java.util.Arrays.fill(recentId, null);
        pi = 0; si = 0; ii = 0; jj = 0; tickNo = 0; lastSidSeen = 0; lastBreak = Long.MIN_VALUE; ourScreen = false; prevSwing = false; prevSwingTime = 0; noScreenSince = -1; containerSince = -1;
    }

    /** edit = open in the editor (timeline, jump, delete, split, save). */
    public static void play(Minecraft mc, Path f, boolean edit) {
        if (playing) return;
        try {
            load(f);
            if (pkts.isEmpty()) { status = "Replay has no packets."; return; }
            startConnection(mc);
            hasInput = !inputs.isEmpty();
            resetPlayback();
            paused = false; seekTarget = -1; restartPending = false; restarting = false; readyMs = -1;
            try { Path dp = mc.gameDirectory.toPath().resolve("guirec").resolve("replay_debug.log"); Files.createDirectories(dp.getParent()); dbg = Files.newBufferedWriter(dp); dbgNext = 0; } catch (Exception ignored) { dbg = null; }
            ReplayEditor.end();
            if (edit) ReplayEditor.begin(f, totalMs);
            playing = true; expSeen = -1; farEntities(true);
            ReplayRecorder.stop();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Could not start replay: " + t;
            playing = false;
        }
    }

    public static void stop(Minecraft mc) {
        if (!playing) return;
        ReplayExport.finish(); farEntities(false);
        playing = false; paused = false; seekTarget = -1; restartPending = false; ReplayEditor.end();
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; track = null; pkts = null; states = null; invs = null; cinvs = null; inputs = null; outs = null; injecting = false;
        try { if (dbg != null) dbg.close(); } catch (Exception ignored) {} dbg = null;
        mc.disconnect(new TitleScreen(), false);
    }

    /**
     * The game left the replay by itself (pause menu > Disconnect, Save and Quit, the replayed server disconnecting...):
     * give up the replay state WITHOUT touching the connection again. Before, only F7 reset it, so after leaving any other way
     * "playing" stayed true: the next replay silently did nothing, and on a real server every hook kept cancelling the
     * mouse, keys, sounds and outgoing packets (= broken game / crash).
     */
    public static void onLeave() {
        if (!playing || restarting) return;     // a restart (jump backwards in the editor) disconnects on purpose
        ReplayExport.finish(); farEntities(false);
        playing = false; paused = false; seekTarget = -1; restartPending = false; ReplayEditor.end();
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; track = null; pkts = null; states = null; invs = null; cinvs = null; inputs = null; outs = null;
        injecting = false; injectingSound = false; injectingCrack = false; cameraHookRan = false;
        try { if (dbg != null) dbg.close(); } catch (Exception ignored) {} dbg = null;
    }

    /** Safety net before starting a replay: a replay flag left over while no world is open is stale. */
    public static void cleanupStale(Minecraft mc) {
        if (playing && mc.level == null) onLeave();
    }

    // ---------------------------------------------------------------- once per game tick
    public static void onTick(Minecraft mc) {
        if (!playing) return;
        try {
            if (restartPending) { restartPending = false; doRestart(mc); return; }
            if (readyMs < 0 && mc.level != null && mc.player != null && mc.screen == null) readyMs = (int) clockT + 200;
            // the editor screen comes back by itself after a jump / when a replayed server menu replaced it
            if (ReplayEditor.wantEditor && ReplayEditor.active && seekTarget < 0 && mc.level != null && mc.player != null
                    && !(mc.screen instanceof ReplayEditorScreen)
                    && (mc.screen == null || mc.screen instanceof AbstractContainerScreen<?> || mc.screen instanceof ChatScreen || mc.screen instanceof PauseScreen))
                mc.setScreen(new ReplayEditorScreen(mc.screen));
            tickNo++;
            channel.releaseOutbound();
            connection.tick();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    // ---------------------------------------------------------------- editor: jumping
    /** Jump backwards: throw the replayed world away and load the replay again from 0 (then fast-forward to the target). */
    private static void doRestart(Minecraft mc) throws Exception {
        int target = Math.max(restartTarget, Math.max(0, readyMs));   // before readyMs the world is not even there
        restarting = true;
        try {
            try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
            mc.disconnect(new TitleScreen(), false);
        } finally { restarting = false; }
        startConnection(mc);
        resetPlayback();
        seekTarget = target > 0 ? target : -1;
        if (seekTarget < 0) status = "";
    }

    /** Fast-forward: give the game every packet up to the target (in slices of ~25 ms per frame), drop the input / sounds in between. */
    private static void seekStep(Minecraft mc) {
        long t0 = System.nanoTime();
        int target = seekTarget;
        try {
            while (true) {
                int pm = pi < pkts.size() ? pkts.get(pi).ms() : Integer.MAX_VALUE;
                if (pm > target) { finishSeek(mc, target); return; }
                if (System.nanoTime() - t0 > 25_000_000L) { clockT = Math.max(clockT, pm); skipInputs((int) clockT); status = "Seeking..."; return; }
                ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                if (ctx == null) { finishSeek(mc, target); return; }
                ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                pi++;
            }
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    private static void finishSeek(Minecraft mc, int target) {
        clockT = target; seekTarget = -1; lastNs = 0; dtAvg = 0; status = "";
        skipInputs(target);
        releaseHeld(mc);
        // a screen that was open before the jump but was not open at the target time: close it (the recorded keys that closed it were skipped)
        if (states != null && !states.isEmpty() && mc.level != null && mc.player != null) {
            int k = Math.min(si, states.size() - 1);
            while (k + 1 < states.size() && states.get(k + 1).ms() <= target) k++;
            while (k > 0 && states.get(k).ms() > target) k--;
            if (states.get(k).sid() == 0 && (mc.screen instanceof AbstractContainerScreen<?> || mc.screen instanceof ChatScreen || mc.screen instanceof PauseScreen))
                mc.setScreen(null);
        }
    }

    /** Drop recorded input / sounds / cracks older than F (a jump skips them), but remember which keys / buttons are still held. */
    private static void skipInputs(int F) {
        if (inputs == null) return;
        while (ki < inputs.size() && inputs.get(ki).ms() < F) {
            In e = inputs.get(ki++);
            if (e.kind() == 0) { if (e.i1() == 0) heldKeys.remove(e.i2()); else heldKeys.put(e.i2(), new int[]{e.i3(), e.i4()}); }
            else if (e.kind() == 2) { int b = e.i1(); if (b >= 0 && b < 31) { if (e.i3() == 0) btnMask &= ~(1 << b); else btnMask |= (1 << b); } }
            else if (e.kind() == 3) { recX = e.d1(); recY = e.d2(); haveRec = true; }
        }
        while (oi < outs.size() && outs.get(oi).ms() < F) oi++;
    }

    /** After a jump nothing may stay held down (a W / attack press whose release was skipped). */
    private static void releaseHeld(Minecraft mc) {
        if (heldKeys.isEmpty() && btnMask == 0) return;
        long win = lastWindow != 0 ? lastWindow : org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        injecting = true;
        try {
            if (((Object) mc.keyboardHandler) instanceof KbAccess k)
                for (var en : new ArrayList<>(heldKeys.entrySet())) k.guirec$key(win, 0, en.getKey(), en.getValue()[0], en.getValue()[1]);
            if (((Object) mc.mouseHandler) instanceof MouseAccess mm)
                for (int b = 0; b < 31; b++) if ((btnMask & (1 << b)) != 0) mm.guirec$button(win, b, 0, 0);
        } catch (Throwable ignored) {
        } finally { injecting = false; }
        heldKeys.clear(); btnMask = 0; smoothed = false;
    }

    // ---------------------------------------------------------------- ONE timeline for packets AND input
    /**
     * Packets and recorded input are processed together, strictly in the order (and at the millisecond) they happened,
     * at the start of every frame, exactly like the real game processes network tasks and input.
     * Heavy bursts (chunk loading) are spread over a few frames so the preview does not freeze.
     */
    private static void feed(Minecraft mc, int F) {
        long t0 = System.nanoTime();
        long bytes = 0;   // packet bytes handed to the game this frame (chunk bursts are spread over several frames)
        St sref = (states == null || states.isEmpty()) ? null : states.get(Math.min(si, states.size() - 1));
        var w = mc.getWindow();
        double sx = sref != null && sref.w() > 0 ? w.getWidth() / (double) sref.w() : 1.0;
        double sy = sref != null && sref.h() > 0 ? w.getHeight() / (double) sref.h() : 1.0;
        long win = lastWindow != 0 ? lastWindow : org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        try {
            while (true) {
                boolean ready = mc.level != null && mc.player != null;
                if (ready && !inputPrimed) {
                    while (ki < inputs.size() && inputs.get(ki).ms() < F - 100) ki++;   // skip what happened while loading
                    while (oi < outs.size() && outs.get(oi).ms() < F - 100) oi++;
                    inputPrimed = true;
                }
                int pm = pi < pkts.size() ? pkts.get(pi).ms() : Integer.MAX_VALUE;
                int im = hasInput && ready && ki < inputs.size() ? inputs.get(ki).ms() : Integer.MAX_VALUE;
                int om = ready && oi < outs.size() ? outs.get(oi).ms() : Integer.MAX_VALUE;
                int m = Math.min(pm, Math.min(im, om));
                if (m > F) break;
                if (System.nanoTime() - t0 > 4_000_000L && F - m < 400) break;   // time budget (unless we are far behind)
                if (pm <= im && pm <= om) {
                    // spread chunk bursts: a limited amount of packet data per frame, more allowed the further behind we are
                    // (order is never changed: we just stop here and continue next frame). No limit when >400 ms behind.
                    long behind = F - pm;
                    if (behind < 400 && bytes >= 40_000L + behind * 300L) break;
                    bytes += pkts.get(pi).data().length;
                    ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                    if (ctx == null) break;
                    ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                    pi++;
                } else if (im <= om) {
                    In e = inputs.get(ki++);
                    injecting = true;
                    try {
                        switch (e.kind()) {
                            case 0 -> { snapToRecorded(mc, win, sx, sy);
                                if (e.i1() == 0) heldKeys.remove(e.i2()); else heldKeys.put(e.i2(), new int[]{e.i3(), e.i4()});
                                if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$key(win, e.i1(), e.i2(), e.i3(), e.i4()); }
                            case 1 -> { if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$char(win, e.i1()); }
                            case 2 -> {
                                snapToRecorded(mc, win, sx, sy);
                                int b = e.i1();
                                if (b >= 0 && b < 31) { if (e.i3() == 0) btnMask &= ~(1 << b); else btnMask |= (1 << b); }
                                if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$button(win, e.i1(), e.i2(), e.i3());
                            }
                            case 3 -> {
                                recX = e.d1(); recY = e.d2(); haveRec = true; smoothed = false;
                                if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$move(win, e.d1() * sx, e.d2() * sy);
                            }
                            case 4 -> { snapToRecorded(mc, win, sx, sy); if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$scroll(win, e.d1(), e.d2()); }
                            default -> {}
                        }
                    } finally { injecting = false; }
                } else {
                    Out o = outs.get(oi++);
                    if (o.kind() == 7) {
                        try {
                            var inst = new net.minecraft.client.resources.sounds.SimpleSoundInstance(
                                    net.minecraft.resources.Identifier.parse(o.id()),
                                    net.minecraft.sounds.SoundSource.values()[Math.min(o.src(), net.minecraft.sounds.SoundSource.values().length - 1)],
                                    o.vol(), o.pitch(), net.minecraft.util.RandomSource.create(), false, 0,
                                    net.minecraft.client.resources.sounds.SoundInstance.Attenuation.values()[Math.min(o.att(), 1)],
                                    o.x(), o.y(), o.z(), o.rel());
                            rememberInjected(o.id(), o.ms());
                            injectingSound = true;
                            try { soundLast = String.valueOf(mc.getSoundManager().play(inst)); } finally { injectingSound = false; }
                            soundsInjected++;
                        } catch (Throwable ex) { soundLast = "error: " + ex; }   // one bad sound must never stop the replay
                    } else {
                        injectingCrack = true;
                        try { mc.level.destroyBlockProgress(mc.player.getId(), BlockPos.of(o.pos()), o.stage()); }
                        finally { injectingCrack = false; }
                    }
                }
            }
            if (pi >= pkts.size() && F > pkts.get(pkts.size() - 1).ms() + 3000) status = "Replay finished. Press F7 to leave.";
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    /** One line per second into .minecraft/guirec/replay_debug.log: send this file if something does not replay right. */
    private static void debug(Minecraft mc, int F) {
        if (dbg == null) return;
        long nowMs = System.currentTimeMillis();
        if (nowMs < dbgNext) return;
        dbgNext = nowMs + 1000;
        try {
            String hit = mc.hitResult == null ? "null" : mc.hitResult.getType().toString();
            dbg.write(String.format("T=%d pkt=%d/%d input=%d/%d out=%d/%d level=%b screen=%s grabbed=%b attackDown=%b hit=%s ground=%s slot=%s%n",
                    F, pi, pkts.size(), ki, inputs.size(), oi, outs.size(), mc.level != null,
                    mc.screen == null ? "none" : mc.screen.getClass().getSimpleName(),
                    mc.mouseHandler.isMouseGrabbed(), mc.options.keyAttack.isDown(), hit,
                    mc.player == null ? "-" : String.valueOf(mc.player.onGround()),
                    mc.player == null ? "-" : String.valueOf(mc.player.getInventory().getSelectedSlot())));
            dbg.write(String.format("  sounds: in file=%d played=%d last=%s%n", soundsLoaded, soundsInjected, soundLast));
            if (fN > 1) {
                double avg = fSum / fN, sd = Math.sqrt(Math.max(0, fSq / fN - avg * avg));
                dbg.write(String.format("  frames=%d (%.0f fps) frame-time avg=%.2f ms sd=%.2f ms max=%.1f ms%n", fN, 1000.0 / avg, avg, sd, fMax));
                fN = 0; fSum = 0; fSq = 0; fMax = 0;
            }
            dbg.flush();
        } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------------- once per frame, BEFORE it is drawn
    public static void onFrame(Minecraft mc, float partial) {
        if (!playing || restartPending) return;
        // smooth replay clock: real time between frames, but a long hitch (chunk loading) never makes time jump
        // The clock advances by a smoothed frame time (moving average), so a frame that merely STARTED a bit late/early
        // does not produce a camera step. The average keeps the total equal to real time (no drift).
        long nowNs = System.nanoTime();
        if (lastNs == 0) lastNs = nowNs;
        double dt = (nowNs - lastNs) / 1_000_000.0;
        if (ReplayExport.active) {
            // video export: every rendered frame is exactly 1/fps of replay time (independent of how long rendering takes)
            lastNs = nowNs;
            if (!paused && seekTarget < 0 && expSeen != ReplayExport.frame) { expSeen = ReplayExport.frame; clockT += ReplayExport.stepMs(); }
        } else if (paused || seekTarget >= 0) {
            lastNs = nowNs;                                    // paused (editor open) or jumping: the clock does not run
        } else if (dt < 0.3 && clockT > 0) {
            // a second call inside the same frame (the game also renders extra frames when a screen opens): same time, no new step
        } else {
            lastNs = nowNs;
            if (dt < 1000.0) { fN++; fSum += dt; fSq += dt * dt; if (dt > fMax) fMax = dt; }
            if (dt > 40.0) {
                clockT += 40.0;                                    // hitch (chunk loading): time never jumps
            } else {
                dtAvg = dtAvg == 0 ? dt : dtAvg + (dt - dtAvg) * 0.15;
                clockT += dtAvg;
            }
        }
        // editor: a deleted part is skipped (its packets are still given to the game, see ReplayEdit)
        if (ReplayEditor.active && seekTarget < 0 && !paused) {
            int de = ReplayEditor.deletedEnd((int) clockT);
            if (de >= 0) seekTarget = Math.min(de, Math.max(totalMs, (int) clockT));
        }
        if (seekTarget >= 0) seekStep(mc);
        int now = (int) clockT;                                // whole ms only for packets / input / state lookup
        soundClock = now;
        if (seekTarget < 0 && playing) feed(mc, now);
        debug(mc, now);
        if (!playing || states == null || states.isEmpty() || mc.player == null || mc.level == null) return;
        boolean closedEdge = false;
        while (si + 1 < states.size() && states.get(si + 1).ms() <= now) {
            si++;
            int sd = states.get(si).sid();
            if (sd == 0 && lastSidSeen != 0) closedEdge = true;
            lastSidSeen = sd;
        }
        St s = states.get(si);
        var p = mc.player;

        // camera: sampled from the smooth cubic path at the exact (fractional) replay time
        track.evalSmoothVelocity(clockT);          // also leaves the camera for clockT in track.cur
        double[] c = track.cur;
        p.setPos(c[0], c[1], c[2]);
        float yaw = (float) c[3], pit = Mth.clamp((float) c[4], -90.0f, 90.0f);
        p.setYRot(yaw); p.setXRot(pit);
        p.setOldPosAndRot();                       // old = new, so the game's own partial-tick lerp cannot add a second, wrong blend
        p.setYHeadRot(yaw); p.yHeadRotO = yaw;
        // smooth real velocity (blocks per tick) so view-bobbing and the arm sway behave
        p.setDeltaMovement(track.vel[0], track.vel[1], track.vel[2]);
        p.getInventory().setSelectedSlot(s.slot());

        if (s.pose() >= 0) p.setOnGround((s.f2() & 16) != 0);   // block-breaking speed depends on being on the ground
        // sprint comes from the recording, not from re-simulated logic: the replay's own physics can drop sprint for a tick
        // (collision at the snapped position...) which makes the sprint FOV and view-bobbing flicker
        if (s.pose() >= 0 && p.isSprinting() != ((s.f2() & 1) != 0)) p.setSprinting((s.f2() & 1) != 0);
        // arm swing from the recording, in BOTH modes: while you hold attack the game restarts the swing every few ticks.
        // Re-running the game logic alone only swung once (the swing restart depends on the re-simulated block progress,
        // which does not match the recorded block breaks). p.swing() ignores a restart that comes too early, so no double swing.
        boolean swing = (s.flags() & 1) != 0;
        int swingTime = (s.flags() >> 2) & 7;
        if (swing && (!prevSwing || swingTime < prevSwingTime))
            p.swing((s.flags() & 2) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        prevSwing = swing; prevSwingTime = swingTime;

        // INVENTORY, in BOTH modes. The recording stores every change of the inventory / carried item / open chest exactly as
        // the client showed it (including the instant client-side result of your click, long before the server's answer).
        // Re-running the clicks alone can miss (slot hit slightly differently, menu not open yet...) and then the result only
        // shows when the recorded server packet arrives = "items appear late". Applying the recorded values at their time fixes that.
        // items the client changed itself (creative inventory, cursor item)
        try {
            while (ii < invs.size() && invs.get(ii).ms() <= now) {
                Inv e = invs.get(ii++);
                for (int k = 0; k < e.slots().length; k++) {
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    int sl = e.slots()[k];
                    if (sl == 100) p.containerMenu.setCarried(st);
                    else if (sl < p.inventoryMenu.slots.size()) p.inventoryMenu.getSlot(sl).set(st);
                }
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // item moves inside the open menu (chest, crafting table...)
        try {
            while (jj < cinvs.size() && cinvs.get(jj).ms() <= now) {
                Inv e = cinvs.get(jj);
                if (p.containerMenu.containerId != e.cid()) {
                    if (now - e.ms() > 1500) { jj++; continue; }   // menu never opened here: drop
                    break;                                          // menu packet not here yet: wait
                }
                for (int k = 0; k < e.slots().length; k++) {
                    int sl = e.slots()[k];
                    if (sl >= p.containerMenu.slots.size()) continue;
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    p.containerMenu.getSlot(sl).set(st);
                }
                jj++;
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // SAFETY NET for the open screen in input mode: the replayed keys normally close the inventory / chest. If a container
        // screen is STILL open although the recording has had no screen for a good while, close it (a missed key).
        // IMPORTANT: the grace time counts from the moment the replay's screen OPENED. A server menu (NPC / lobby compass) opens in
        // the replay from its packet slightly BEFORE the recorded screen state flips, so "recorded: no screen" is briefly true while
        // the menu is legitimately open; closing it then made menus flicker away or never show.
        boolean containerOpen = mc.screen instanceof AbstractContainerScreen<?>;
        if (containerOpen) { if (containerSince < 0) containerSince = now; } else containerSince = -1;
        if (s.sid() == 0) { if (noScreenSince < 0) noScreenSince = now; } else noScreenSince = -1;
        if (hasInput && containerOpen && noScreenSince >= 0 && now - Math.max(noScreenSince, containerSince) > 500) {
            p.closeContainer(); ourScreen = false; containerSince = -1;
        }

        if (hasInput) { smoothCursor(mc, s); return; }   // new recordings: the real game logic re-runs on the recorded input

        // ---- old recordings without input: best-effort emulation below ----
        // client-side body state: pose, sprint, sneak, eating / bow, block-break cracks
        if (s.pose() >= 0 && s.pose() < Pose.values().length) p.setPose(Pose.values()[s.pose()]);
        p.setSprinting((s.f2() & 1) != 0);
        p.setShiftKeyDown((s.f2() & 2) != 0);
        boolean using = (s.f2() & 4) != 0;
        if (using && !p.isUsingItem()) p.startUsingItem((s.f2() & 8) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        else if (!using && p.isUsingItem()) p.stopUsingItem();
        if (s.brk() != Long.MIN_VALUE && s.stage() >= 0) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(s.brk()), s.stage());
            lastBreak = s.brk();
        } else if (lastBreak != Long.MIN_VALUE) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(lastBreak), -1);
            lastBreak = Long.MIN_VALUE;
        }

        // screens
        String name = s.sid() == 0 ? "" : screens.getOrDefault(s.sid(), "");
        if (name.endsWith("CreativeModeInventoryScreen")) {
            if (!(mc.screen instanceof CreativeModeInventoryScreen)) {
                mc.setScreen(new CreativeModeInventoryScreen(p, FeatureFlags.DEFAULT_FLAGS, true)); ourScreen = true;
            }
            if (mc.screen instanceof CreativeAccess ca) {
                String[] parts = s.extra().split(";", 3);
                try {
                    if (parts.length >= 1) ca.guirec$setTab(Integer.parseInt(parts[0]));
                    if (parts.length >= 2) ca.guirec$setScroll(Float.parseFloat(parts[1]));
                    if (parts.length >= 3) ca.guirec$setSearch(parts[2]);
                } catch (NumberFormatException ignored) {}
            }
        } else if (name.endsWith("InventoryScreen")) {
            if (!(mc.screen instanceof InventoryScreen)) { mc.setScreen(new InventoryScreen(p)); ourScreen = true; }
        } else if (name.endsWith("PauseScreen")) {
            if (!(mc.screen instanceof PauseScreen)) { mc.setScreen(new PauseScreen(true)); ourScreen = true; }
        } else if (name.endsWith("ChatScreen")) {
            if (!(mc.screen instanceof ChatScreen)) { mc.setScreen(new ChatScreen("", false)); ourScreen = true; }
            if (mc.screen instanceof ChatAccess ca) ca.guirec$setText(s.extra());
        } else if (name.isEmpty() && mc.screen != null) {
            // recorded: no screen open. Close containers (the server never tells us when the player closes one).
            if (mc.screen instanceof AbstractContainerScreen<?>) { if (closedEdge) { p.closeContainer(); ourScreen = false; } }
            else if (ourScreen) { mc.setScreen(null); ourScreen = false; }
        }

        if (mc.screen != null && s.w() > 0 && s.h() > 0 && mc.mouseHandler instanceof MouseAccess m) {
            var w = mc.getWindow();
            m.guirec$set(s.mx() * w.getWidth() / s.w(), s.my() * w.getHeight() / s.h());
        }
    }
}
