package com.guirec;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.client.multiplayer.CommonListenerCookie;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.HandlerNames;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.ServerLinks;
import net.minecraft.world.flag.FeatureFlags;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.InflaterInputStream;

/**
 * STAGE 2: plays a .guirec file inside the game (preview only).
 * A fake in-memory connection is fed the recorded packets on the recorded timeline, so the real
 * client builds the world, entities, health, hunger and inventory exactly as it did while recording.
 * The recorded camera / hotbar slot / open screen / mouse are applied every frame on top.
 */
public final class ReplayPlayer {
    private record Pkt(int ms, byte[] data) {}
    private record St(int ms, double x, double y, double z, float yaw, float pitch, int slot, int sid,
                      float mx, float my, int w, int h) {}

    private static volatile boolean playing = false;
    private static List<Pkt> pkts;
    private static List<St> states;
    private static Map<Integer, String> screens;
    private static int pi, si;
    private static long startNs;
    private static EmbeddedChannel channel;
    private static Connection connection;
    private static boolean ourScreen;
    public static volatile String status = "";

    public static boolean isPlaying() { return playing; }
    public static int clockMs() { return (int) ((System.nanoTime() - startNs) / 1_000_000L); }

    // ---------------------------------------------------------------- loading
    private static void load(Path f) throws IOException {
        pkts = new ArrayList<>(); states = new ArrayList<>(); screens = new HashMap<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new java.util.zip.Inflater(), 1 << 15), 1 << 16))) {
            byte[] magic = new byte[8]; in.readFully(magic);
            if (!new String(magic).equals("GUIREC01")) throw new IOException("Not a GUIREC01 file");
            while (true) {
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }   // crashed/unfinished file is OK
                if (t == 0) break;
                try {
                    if (t == 1) {
                        int ms = in.readInt(); in.readUnsignedByte(); int len = in.readInt();
                        byte[] b = new byte[len]; in.readFully(b); pkts.add(new Pkt(ms, b));
                    } else if (t == 2) {
                        int ms = in.readInt();
                        double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        float yaw = in.readFloat(), pit = in.readFloat();
                        int slot = in.readUnsignedByte(); int sid = in.readShort();
                        float mx = in.readFloat(), my = in.readFloat(); int w = in.readShort(), h = in.readShort();
                        states.add(new St(ms, x, y, z, yaw, pit, slot, sid, mx, my, w, h));
                    } else if (t == 3) {
                        int id = in.readShort(); screens.put(id, in.readUTF());
                    } else throw new IOException("Bad record type " + t);
                } catch (EOFException e) { break; }
            }
        }
    }

    // ---------------------------------------------------------------- start / stop
    public static void play(Minecraft mc, Path f) {
        if (playing) return;
        try {
            load(f);
            if (pkts.isEmpty()) { status = "Replay has no packets."; return; }
            status = "Loading replay...";
            connection = new Connection(PacketFlow.CLIENTBOUND);
            channel = new EmbeddedChannel();
            Connection.configureInMemoryPipeline(channel.pipeline(), PacketFlow.CLIENTBOUND);
            channel.pipeline().addLast(HandlerNames.PACKET_HANDLER, connection);
            connection.channelActive(channel.pipeline().context(connection));

            var user = mc.getUser();
            GameProfile profile = new GameProfile(user.getProfileId(), user.getName());
            CommonListenerCookie cookie = new CommonListenerCookie(
                    new LevelLoadTracker(), profile,
                    mc.getTelemetryManager().createWorldSessionManager(false, null, null),
                    RegistryAccess.EMPTY, FeatureFlags.DEFAULT_FLAGS, "vanilla", null, null,
                    Map.of(), mc.gui.getChat().storeState(), Map.of(), ServerLinks.EMPTY, Map.of(), false);
            var listener = new ClientConfigurationPacketListenerImpl(mc, connection, cookie);
            connection.setupInboundProtocol(ConfigurationProtocols.CLIENTBOUND, listener);
            connection.setupOutboundProtocol(ConfigurationProtocols.SERVERBOUND);

            pi = 0; si = 0; ourScreen = false;
            startNs = System.nanoTime();
            playing = true;
            ReplayRecorder.stop();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Could not start replay: " + t;
            playing = false;
        }
    }

    public static void stop(Minecraft mc) {
        if (!playing) return;
        playing = false;
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; pkts = null; states = null;
        mc.disconnect(new TitleScreen(), false);
    }

    // ---------------------------------------------------------------- per tick: feed packets
    public static void onTick(Minecraft mc) {
        if (!playing) return;
        try {
            int now = clockMs();
            while (pi < pkts.size() && pkts.get(pi).ms() <= now) {
                ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                if (ctx == null) break;
                ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                pi++;
            }
            channel.releaseOutbound();
            connection.tick();
            if (pi >= pkts.size() && now > pkts.get(pkts.size() - 1).ms() + 3000) status = "Replay finished. Press F7 to leave.";
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    // ---------------------------------------------------------------- per frame: camera, hotbar, screen, cursor
    public static void onFrame(Minecraft mc) {
        if (!playing || states == null || states.isEmpty() || mc.player == null) return;
        int now = clockMs();
        while (si + 1 < states.size() && states.get(si + 1).ms() <= now) si++;
        St s = states.get(si);
        var p = mc.player;
        p.setPos(s.x(), s.y(), s.z());
        p.setYRot(s.yaw()); p.setXRot(s.pitch());
        p.setOldPosAndRot();
        p.setYHeadRot(s.yaw());
        p.getInventory().setSelectedSlot(s.slot());

        String name = s.sid() == 0 ? "" : screens.getOrDefault(s.sid(), "");
        boolean wantInv = name.endsWith("InventoryScreen");
        boolean wantPause = name.endsWith("PauseScreen");
        if (wantInv && !(mc.screen instanceof InventoryScreen)) { mc.setScreen(new InventoryScreen(p)); ourScreen = true; }
        else if (wantPause && !(mc.screen instanceof PauseScreen)) { mc.setScreen(new PauseScreen(true)); ourScreen = true; }
        else if (name.isEmpty() && ourScreen && mc.screen != null) { mc.setScreen(null); ourScreen = false; }

        if (mc.screen != null && s.w() > 0 && s.h() > 0 && mc.mouseHandler instanceof MouseAccess m) {
            var w = mc.getWindow();
            m.guirec$set(s.mx() * w.getWidth() / s.w(), s.my() * w.getHeight() / s.h());
        }
    }
}
