package com.guirec;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.client.multiplayer.CommonListenerCookie;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.HandlerNames;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.ServerLinks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.ItemStack;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.InflaterInputStream;

/**
 * Plays a .guirec file inside the game (preview only).
 * The replay clock is real (wall) time, NOT game ticks, so the camera stays smooth even when ticks are heavy or bunch up.
 * Things the game does on its own and no server packet carries (sounds, block-crack texture, arm swing) are recorded as
 * outcomes and replayed as-is; the game's own versions of those are suppressed while replaying (GUIREC04+ files).
 */
public final class ReplayPlayer {
    private record Pkt(int ms, byte[] data) {}
    private record St(int ms, double x, double y, double z, float yaw, float pitch, int slot, int sid,
                      float mx, float my, int w, int h, int flags, String extra,
                      int pose, int f2, int useTicks, long brk, int stage) {}
    private record Inv(int ms, int cid, int[] slots, byte[][] data) {}
    private record In(int ms, int kind, int i1, int i2, int i3, int i4, double d1, double d2) {}
    /** kind 7 sound (s=id, a=source, f1=vol, f2=pitch, x/y/z, b=attenuation|relative<<1), 8 crack (l=pos, a=stage), 9 swing (a=hand) */
    private record Ev(int ms, int kind, String s, int a, int b, float f1, float f2, double x, double y, double z, long l) {}

    private static volatile boolean playing = false;
    private static List<Pkt> pkts;
    private static List<St> states;
    private static List<Inv> invs, cinvs;
    private static List<In> inputs;
    private static List<Ev> events;
    private static boolean hasEvents;
    private static int ei;
    private static long startNs, lastNs;
    // ---- preview controls
    public static volatile boolean paused, smooth;
    public static volatile double speed = 1.0;
    private static boolean seekPending, burst, reopenControls, wasSmooth;
    private static double seekTo;
    private static int totalMs;
    private static Path curFile;
    private static long retMs, offset;
    private static double retMsD;
    public static volatile long lastRealMs;
    private static double clockMs;
    private static long crackActive = Long.MIN_VALUE;
    public static volatile boolean soundInjecting, crackInjecting, swingInjecting;
    private static boolean hasInput, inputPrimed;
    private static int ki;
    public static volatile boolean injecting;
    public static volatile long lastWindow;
    private static Map<Integer, String> screens;
    private static int pi, si, ii, jj, tickNo, lastSidSeen;
    private static long lastBreak = Long.MIN_VALUE;
    private static EmbeddedChannel channel;
    private static Connection connection;
    private static boolean ourScreen, prevSwing;
    private static int prevSwingTime;
    public static volatile String status = "";

    public static boolean isPlaying() { return playing; }

    /** While replaying a GUIREC04+ file, the game's own one-shot sounds are dropped; the recorded ones are played instead. */
    public static boolean blockSound(net.minecraft.client.resources.sounds.SoundInstance s) {
        return playing && hasEvents && !soundInjecting && ReplayRecorder.isOneShotSound(s);
    }
    /** Same for the local player's block-crack texture. */
    public static boolean blockCrack(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        return playing && hasEvents && !crackInjecting && mc.player != null && mc.player.getId() == entityId;
    }
    /** Same for the local player's arm swing. */
    public static boolean blockSwing() { return playing && hasEvents && !swingInjecting; }

    // ---------------------------------------------------------------- loading
    private static void load(Path f) throws IOException {
        pkts = new ArrayList<>(); events = new ArrayList<>(); hasEvents = false; states = new ArrayList<>(); invs = new ArrayList<>(); cinvs = new ArrayList<>(); inputs = new ArrayList<>(); screens = new HashMap<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new java.util.zip.Inflater(), 1 << 15), 1 << 16))) {
            byte[] magic = new byte[8]; in.readFully(magic);
            String mg = new String(magic);
            if (!mg.equals("GUIREC01") && !mg.equals("GUIREC02") && !mg.equals("GUIREC03") && !mg.equals("GUIREC04")) throw new IOException("Not a GUIREC file");
            boolean v2 = !mg.equals("GUIREC01"), v3 = mg.equals("GUIREC03") || mg.equals("GUIREC04");
            hasEvents = mg.equals("GUIREC04");
            while (true) {
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }
                if (t == 0) break;
                try {
                    if (t == 1) {
                        int ms = in.readInt(); in.readUnsignedByte(); int len = in.readInt();
                        byte[] b = new byte[len]; in.readFully(b); pkts.add(new Pkt(ms, b));
                    } else if (t == 2) {
                        int ms = in.readInt();
                        double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        float yaw = in.readFloat(), pit = in.readFloat();
                        int slot = in.readUnsignedByte(); int sid = in.readShort();
                        float mx = in.readFloat(), my = in.readFloat(); int w = in.readShort(), h = in.readShort();
                        int fl = 0; String extra = "";
                        if (v2) { fl = in.readUnsignedByte(); extra = in.readUTF(); }
                        int pose = -1, f2 = 0, ut = 0, stg = -1; long brk = Long.MIN_VALUE;
                        if (v3) { pose = in.readUnsignedByte(); f2 = in.readUnsignedByte(); ut = in.readShort(); brk = in.readLong(); stg = in.readByte(); }
                        states.add(new St(ms, x, y, z, yaw, pit, slot, sid, mx, my, w, h, fl, extra, pose, f2, ut, brk, stg));
                    } else if (t == 3) {
                        int id = in.readShort(); screens.put(id, in.readUTF());
                    } else if (t == 4) {
                        int ms = in.readInt(); int n = in.readUnsignedByte();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedByte(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        invs.add(new Inv(ms, 0, sl, dt));
                    } else if (t == 5) {
                        int ms = in.readInt(); int cid = in.readInt(); int n = in.readUnsignedShort();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedShort(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        cinvs.add(new Inv(ms, cid, sl, dt));
                    } else if (t == 6) {
                        int ms = in.readInt(); int kind = in.readUnsignedByte();
                        switch (kind) {
                            case 0 -> { int a = in.readUnsignedByte(), k = in.readInt(), sc = in.readInt(), md = in.readInt(); inputs.add(new In(ms, 0, a, k, sc, md, 0, 0)); }
                            case 1 -> inputs.add(new In(ms, 1, in.readInt(), 0, 0, 0, 0, 0));
                            case 2 -> { int b = in.readInt(), md = in.readInt(), a = in.readUnsignedByte(); inputs.add(new In(ms, 2, b, md, a, 0, 0, 0)); }
                            case 3, 4 -> { double x = in.readDouble(), y = in.readDouble(); inputs.add(new In(ms, kind, 0, 0, 0, 0, x, y)); }
                            default -> throw new IOException("Bad input kind " + kind);
                        }
                    } else if (t == 7) {
                        int ms = in.readInt(); String id = in.readUTF(); int src = in.readUnsignedByte();
                        float vol = in.readFloat(), pit = in.readFloat(); double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        int att = in.readUnsignedByte(); boolean rel = in.readBoolean();
                        events.add(new Ev(ms, 7, id, src, att | (rel ? 2 : 0), vol, pit, x, y, z, 0));
                    } else if (t == 8) {
                        int ms = in.readInt(); long pos = in.readLong(); int st = in.readByte();
                        events.add(new Ev(ms, 8, null, st, 0, 0, 0, 0, 0, 0, pos));
                    } else if (t == 9) {
                        int ms = in.readInt(); int hand = in.readUnsignedByte();
                        events.add(new Ev(ms, 9, null, hand, 0, 0, 0, 0, 0, 0, 0));
                    } else throw new IOException("Bad record type " + t);
                } catch (EOFException e) { break; }
            }
        }
    }

    // ---------------------------------------------------------------- start / stop
    public static void play(Minecraft mc, Path f) {
        if (playing) return;
        try {
            load(f);
            if (pkts.isEmpty()) { status = "Replay has no packets."; return; }
            curFile = f;
            totalMs = Math.max(pkts.get(pkts.size() - 1).ms(), states.isEmpty() ? 0 : states.get(states.size() - 1).ms());
            paused = false; smooth = false; speed = 1.0;
            begin(mc, 0);
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Could not start replay: " + t;
            playing = false;
        }
    }

    /** (Re)builds the fake connection and starts playing at startMs. The loaded recording is kept. */
    private static void begin(Minecraft mc, double startMs) throws Throwable {
        status = startMs > 0 ? "Seeking..." : "Loading replay...";
        connection = new Connection(PacketFlow.CLIENTBOUND);
        channel = new EmbeddedChannel();
        Connection.configureInMemoryPipeline(channel.pipeline(), PacketFlow.CLIENTBOUND);
        channel.pipeline().addLast(HandlerNames.PACKET_HANDLER, connection);
        connection.channelActive(channel.pipeline().context(connection));

        var user = mc.getUser();
        GameProfile profile = new GameProfile(user.getProfileId(), user.getName());
        CommonListenerCookie cookie = new CommonListenerCookie(
                new LevelLoadTracker(), profile,
                mc.getTelemetryManager().createWorldSessionManager(false, null, null),
                RegistryAccess.EMPTY, FeatureFlags.DEFAULT_FLAGS, "vanilla", null, null,
                Map.of(), mc.gui.getChat().storeState(), Map.of(), ServerLinks.EMPTY, Map.of(), false);
        var listener = new ClientConfigurationPacketListenerImpl(mc, connection, cookie);
        connection.setupInboundProtocol(ConfigurationProtocols.CLIENTBOUND, listener);
        connection.setupOutboundProtocol(ConfigurationProtocols.SERVERBOUND);

        hasInput = !inputs.isEmpty(); inputPrimed = false; ki = 0; injecting = false;
        pi = 0; si = 0; ii = 0; jj = 0; ei = 0; tickNo = 0; crackActive = Long.MIN_VALUE; startNs = System.nanoTime(); lastNs = startNs;
        clockMs = startMs; burst = startMs > 0; lastSidSeen = 0; lastBreak = Long.MIN_VALUE; ourScreen = false; prevSwing = false; prevSwingTime = 0;
        seekPending = false;
        playing = true;
        ReplayRecorder.stop();
    }

    // ---------------------------------------------------------------- seeking / controls
    public static double clock() { return clockMs; }
    public static int total() { return totalMs; }
    public static boolean controlsOpen() { return Minecraft.getInstance().screen instanceof ReplayControlsScreen; }
    private static double step() { return 1000.0 / 60.0 * speed; }

    /** Jump to a time (ms). Forward = fast-forward the packets; backward = rebuild the world and fast-forward from the start. */
    public static void seek(double ms) {
        if (!playing) return;
        seekTo = Math.max(0, Math.min(totalMs, ms));
        seekPending = true;
    }

    private static void doSeek(Minecraft mc) {
        double target = seekTo;
        if (target >= clockMs - 1 && mc.level != null && mc.player != null) {
            clockMs = target;
            while (ki < inputs.size() && inputs.get(ki).ms() < target - 100) ki++;
            while (ei < events.size() && events.get(ei).ms() < target) ei++;
            burst = true;
            return;
        }
        try {   // backward: rebuild the world, then fast-forward to the target
            playing = false;
            try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
            channel = null; connection = null; injecting = false;
            mc.disconnect(new TitleScreen(), false);
            reopenControls = true;
            begin(mc, target);
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Seek failed: " + t;
            playing = false;
        }
    }

    public static void stop(Minecraft mc) {
        if (!playing) return;
        playing = false; seekPending = false; reopenControls = false; paused = false;
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; pkts = null; states = null; invs = null; cinvs = null; inputs = null; events = null; hasEvents = false; injecting = false;
        mc.disconnect(new TitleScreen(), false);
    }

    // ---------------------------------------------------------------- once per game tick
    public static void onTick(Minecraft mc) {
        if (!playing) return;
        try {
            tickNo++;
            channel.releaseOutbound();
            connection.tick();
            if (seekPending) { seekPending = false; doSeek(mc); }
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    // ---------------------------------------------------------------- ONE timeline for packets AND input
    /**
     * Packets and recorded input are processed together, strictly in the order (and at the millisecond) they happened,
     * at the start of every frame, exactly like the real game processes network tasks and input.
     * Heavy bursts (chunk loading) are spread over a few frames so the preview does not freeze.
     */
    private static void feed(Minecraft mc, int F) {
        long t0 = System.nanoTime();
        St sref = (states == null || states.isEmpty()) ? null : states.get(Math.min(si, states.size() - 1));
        var w = mc.getWindow();
        double sx = sref != null && sref.w() > 0 ? w.getWidth() / (double) sref.w() : 1.0;
        double sy = sref != null && sref.h() > 0 ? w.getHeight() / (double) sref.h() : 1.0;
        long win = lastWindow != 0 ? lastWindow : org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        try {
            while (true) {
                boolean inputsOk = hasInput && mc.level != null && mc.player != null;
                if (inputsOk && !inputPrimed) {
                    while (ki < inputs.size() && inputs.get(ki).ms() < F - 100) ki++;   // skip what happened while loading
                    inputPrimed = true;
                }
                int pm = pi < pkts.size() ? pkts.get(pi).ms() : Integer.MAX_VALUE;
                int im = inputsOk && ki < inputs.size() ? inputs.get(ki).ms() : Integer.MAX_VALUE;
                int m = Math.min(pm, im);
                if (m > F) break;
                if (!smooth && !burst && System.nanoTime() - t0 > (F - m > 3000 ? 20_000_000L : 8_000_000L)) break;   // per-frame time budget, always
                if (pm <= im) {
                    ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                    if (ctx == null) break;
                    ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                    pi++;
                } else {
                    In e = inputs.get(ki++);
                    if (controlsOpen()) continue;   // while the controls are open, recorded input must not click into them
                    injecting = true;
                    try {
                        switch (e.kind()) {
                            case 0 -> { if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$key(win, e.i1(), e.i2(), e.i3(), e.i4()); }
                            case 1 -> { if (((Object) mc.keyboardHandler) instanceof KbAccess k) k.guirec$char(win, e.i1()); }
                            case 2 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$button(win, e.i1(), e.i2(), e.i3()); }
                            case 3 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$move(win, e.d1() * sx, e.d2() * sy); }
                            case 4 -> { if (((Object) mc.mouseHandler) instanceof MouseAccess mm) mm.guirec$scroll(win, e.d1(), e.d2()); }
                            default -> {}
                        }
                    } finally { injecting = false; }
                }
            }
            if (pi >= pkts.size() && F > pkts.get(pkts.size() - 1).ms() + 3000) status = "Replay finished. Press F7 to leave.";
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    /** Timer hook: in smooth mode the game's own clock (ticks, animations) follows the fixed per-frame step. */
    public static long timerMs(long real) {
        lastRealMs = real;
        if (smooth && playing) {
            if (!wasSmooth) { wasSmooth = true; retMsD = retMs; }
            return retMs;
        }
        if (wasSmooth) { wasSmooth = false; offset = retMs - real; }
        retMs = real + offset;
        return retMs;
    }

    /** After a frame is drawn: advance the game's smooth clock by the same step the replay clock took. */
    public static void afterFrame(Minecraft mc) {
        if (playing && smooth && !paused) { retMsD += step(); retMs = (long) retMsD; }
    }

    private static double herm(St a, St s, St n, St b, double t, java.util.function.ToDoubleFunction<St> f) {
        double p0 = f.applyAsDouble(s), p1 = f.applyAsDouble(n);
        double span = n.ms() - s.ms();
        if (span <= 0) return p0;
        double d0 = s.ms() - a.ms(), d1 = b.ms() - n.ms();
        double m0 = d0 > 0 ? (p1 - f.applyAsDouble(a)) / (n.ms() - a.ms()) * span : (p1 - p0);
        double m1 = d1 > 0 ? (f.applyAsDouble(b) - p0) / (b.ms() - s.ms()) * span : (p1 - p0);
        double t2 = t * t, t3 = t2 * t;
        return (2 * t3 - 3 * t2 + 1) * p0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * p1 + (t3 - t2) * m1;
    }

    // ---------------------------------------------------------------- recorded outcomes: sounds, cracks, swings
    private static void playEvents(Minecraft mc, int now) {
        if (!hasEvents || events == null) return;
        boolean ready = mc.level != null && mc.player != null;
        try {
            while (ei < events.size() && events.get(ei).ms() <= now) {
                Ev e = events.get(ei++);
                if (!ready || now - e.ms() > 1500) continue;   // happened while loading / far in the past: drop
                switch (e.kind()) {
                    case 7 -> {
                        var si = new net.minecraft.client.resources.sounds.SimpleSoundInstance(
                                net.minecraft.resources.Identifier.parse(e.s()),
                                net.minecraft.sounds.SoundSource.values()[Math.min(e.a(), net.minecraft.sounds.SoundSource.values().length - 1)],
                                e.f1(), e.f2(), net.minecraft.util.RandomSource.create(), false, 0,
                                (e.b() & 1) == 0 ? net.minecraft.client.resources.sounds.SoundInstance.Attenuation.NONE
                                                 : net.minecraft.client.resources.sounds.SoundInstance.Attenuation.LINEAR,
                                e.x(), e.y(), e.z(), (e.b() & 2) != 0);
                        soundInjecting = true;
                        try { mc.getSoundManager().play(si); } finally { soundInjecting = false; }
                    }
                    case 8 -> {
                        crackInjecting = true;
                        try {
                            if (e.a() < 0) {
                                if (e.l() != Long.MIN_VALUE) mc.level.destroyBlockProgress(mc.player.getId(), BlockPos.of(e.l()), -1);
                                crackActive = Long.MIN_VALUE;
                            } else {
                                if (crackActive != Long.MIN_VALUE && crackActive != e.l())
                                    mc.level.destroyBlockProgress(mc.player.getId(), BlockPos.of(crackActive), -1);
                                mc.level.destroyBlockProgress(mc.player.getId(), BlockPos.of(e.l()), e.a());
                                crackActive = e.l();
                            }
                        } finally { crackInjecting = false; }
                    }
                    case 9 -> {
                        swingInjecting = true;
                        try { mc.player.swing(e.a() == 1 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND); }
                        finally { swingInjecting = false; }
                    }
                    default -> {}
                }
            }
        } catch (Throwable t) { t.printStackTrace(); }
    }

    // ---------------------------------------------------------------- once per frame, BEFORE it is drawn
    public static void onFrame(Minecraft mc, float partial) {
        if (!playing) return;
        // Real-time clock, independent of game ticks. If packet processing falls behind (chunk bursts after raising the
        // render distance) the clock slows down instead of freezing the game to catch up, so nothing jumps.
        long nowNs = System.nanoTime();
        double dt = Math.min(100.0, (nowNs - lastNs) / 1_000_000.0); lastNs = nowNs;
        int nextPkt = (pkts != null && pi < pkts.size()) ? pkts.get(pi).ms() : Integer.MAX_VALUE;
        if (smooth) {
            if (!paused) clockMs += step();   // fixed 1/60 s per drawn frame: every frame is complete, slow-mo on a slow device
        } else if (!paused) {
            clockMs += dt * speed * ((clockMs - nextPkt) > 150 ? 0.25 : 1.0);
        }
        if (clockMs > totalMs) clockMs = totalMs;
        if (reopenControls && mc.level != null && mc.player != null && mc.screen == null) {
            reopenControls = false; mc.setScreen(new ReplayControlsScreen());
        }
        int now = (int) clockMs;
        feed(mc, now);
        burst = false;
        if (mc.level != null && mc.player != null && status.equals("Seeking...")) status = "";
        playEvents(mc, now);
        if (!playing || states == null || states.isEmpty() || mc.player == null || mc.level == null) return;
        boolean closedEdge = false;
        while (si + 1 < states.size() && states.get(si + 1).ms() <= now) {
            si++;
            int sd = states.get(si).sid();
            if (sd == 0 && lastSidSeen != 0) closedEdge = true;
            lastSidSeen = sd;
        }
        St s = states.get(si);
        St n = si + 1 < states.size() ? states.get(si + 1) : s;
        double span = n.ms() - s.ms();
        double t = span > 0 ? Math.min(1.0, Math.max(0.0, (now - s.ms()) / span)) : 0.0;
        var p = mc.player;

        // smooth (cubic Hermite / Catmull-Rom) camera through the recorded samples instead of straight lines between them
        St a0 = si > 0 ? states.get(si - 1) : s;
        St b1 = si + 2 < states.size() ? states.get(si + 2) : n;
        double px = herm(a0, s, n, b1, t, St::x), py = herm(a0, s, n, b1, t, St::y), pz = herm(a0, s, n, b1, t, St::z);
        p.setPos(px, py, pz);
        float yaw = (float) herm(a0, s, n, b1, t, x -> x.yaw());
        float pit = (float) Math.max(-90.0, Math.min(90.0, herm(a0, s, n, b1, t, x -> x.pitch())));
        p.setYRot(yaw); p.setXRot(pit);
        p.setOldPosAndRot();
        p.setYHeadRot(yaw);
        if (span > 0) {   // real velocity (blocks per tick) so view-bobbing and the arm sway behave
            double k = 50.0 / span;
            p.setDeltaMovement((n.x() - s.x()) * k, (n.y() - s.y()) * k, (n.z() - s.z()) * k);
        }
        p.getInventory().setSelectedSlot(s.slot());

        if (s.pose() >= 0) p.setOnGround((s.f2() & 16) != 0);   // block-breaking speed depends on being on the ground
        if (hasInput) return;   // new recordings: the real game logic re-runs on the recorded input

        // ---- old recordings without input: best-effort emulation below ----
        // items the client changed itself (creative inventory, cursor item)
        try {
            while (ii < invs.size() && invs.get(ii).ms() <= now) {
                Inv e = invs.get(ii++);
                for (int k = 0; k < e.slots().length; k++) {
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    int sl = e.slots()[k];
                    if (sl == 100) p.containerMenu.setCarried(st);
                    else if (sl < p.inventoryMenu.slots.size()) p.inventoryMenu.getSlot(sl).set(st);
                }
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // item moves inside the open menu (chest, crafting table...)
        try {
            while (jj < cinvs.size() && cinvs.get(jj).ms() <= now) {
                Inv e = cinvs.get(jj);
                if (p.containerMenu.containerId != e.cid()) {
                    if (now - e.ms() > 1500) { jj++; continue; }   // menu never opened here: drop
                    break;                                          // menu packet not here yet: wait
                }
                for (int k = 0; k < e.slots().length; k++) {
                    int sl = e.slots()[k];
                    if (sl >= p.containerMenu.slots.size()) continue;
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    p.containerMenu.getSlot(sl).set(st);
                }
                jj++;
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // client-side body state: pose, sprint, sneak, eating / bow, block-break cracks
        if (s.pose() >= 0 && s.pose() < Pose.values().length) p.setPose(Pose.values()[s.pose()]);
        p.setSprinting((s.f2() & 1) != 0);
        p.setShiftKeyDown((s.f2() & 2) != 0);
        boolean using = (s.f2() & 4) != 0;
        if (using && !p.isUsingItem()) p.startUsingItem((s.f2() & 8) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        else if (!using && p.isUsingItem()) p.stopUsingItem();
        if (s.brk() != Long.MIN_VALUE && s.stage() >= 0) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(s.brk()), s.stage());
            lastBreak = s.brk();
        } else if (lastBreak != Long.MIN_VALUE) {
            mc.level.destroyBlockProgress(p.getId(), BlockPos.of(lastBreak), -1);
            lastBreak = Long.MIN_VALUE;
        }

        // arm swing: start a swing when it begins, or restarts while still swinging
        boolean swing = (s.flags() & 1) != 0;
        int swingTime = (s.flags() >> 2) & 7;
        if (swing && (!prevSwing || swingTime < prevSwingTime))
            p.swing((s.flags() & 2) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        prevSwing = swing; prevSwingTime = swingTime;

        if (controlsOpen()) return;
        // screens
        String name = s.sid() == 0 ? "" : screens.getOrDefault(s.sid(), "");
        if (name.endsWith("CreativeModeInventoryScreen")) {
            if (!(mc.screen instanceof CreativeModeInventoryScreen)) {
                mc.setScreen(new CreativeModeInventoryScreen(p, FeatureFlags.DEFAULT_FLAGS, true)); ourScreen = true;
            }
            if (mc.screen instanceof CreativeAccess ca) {
                String[] parts = s.extra().split(";", 3);
                try {
                    if (parts.length >= 1) ca.guirec$setTab(Integer.parseInt(parts[0]));
                    if (parts.length >= 2) ca.guirec$setScroll(Float.parseFloat(parts[1]));
                    if (parts.length >= 3) ca.guirec$setSearch(parts[2]);
                } catch (NumberFormatException ignored) {}
            }
        } else if (name.endsWith("InventoryScreen")) {
            if (!(mc.screen instanceof InventoryScreen)) { mc.setScreen(new InventoryScreen(p)); ourScreen = true; }
        } else if (name.endsWith("PauseScreen")) {
            if (!(mc.screen instanceof PauseScreen)) { mc.setScreen(new PauseScreen(true)); ourScreen = true; }
        } else if (name.endsWith("ChatScreen")) {
            if (!(mc.screen instanceof ChatScreen)) { mc.setScreen(new ChatScreen("", false)); ourScreen = true; }
            if (mc.screen instanceof ChatAccess ca) ca.guirec$setText(s.extra());
        } else if (name.isEmpty() && mc.screen != null) {
            // recorded: no screen open. Close containers (the server never tells us when the player closes one).
            if (mc.screen instanceof AbstractContainerScreen<?>) { if (closedEdge) { p.closeContainer(); ourScreen = false; } }
            else if (ourScreen) { mc.setScreen(null); ourScreen = false; }
        }

        if (mc.screen != null && s.w() > 0 && s.h() > 0 && mc.mouseHandler instanceof MouseAccess m) {
            var w = mc.getWindow();
            m.guirec$set(s.mx() * w.getWidth() / s.w(), s.my() * w.getHeight() / s.h());
        }
    }
}
