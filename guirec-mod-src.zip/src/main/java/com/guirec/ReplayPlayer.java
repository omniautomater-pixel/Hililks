package com.guirec;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.client.multiplayer.CommonListenerCookie;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.HandlerNames;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.ServerLinks;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.ItemStack;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.InflaterInputStream;

/**
 * Plays a .guirec file inside the game (preview only).
 * Everything runs on the game's own tick timeline (1 tick = 50 ms): packets are fed once per tick and the
 * recorded camera is sampled at (tick + partialTick), exactly like the game renders, so motion stays smooth.
 */
public final class ReplayPlayer {
    private record Pkt(int ms, byte[] data) {}
    private record St(int ms, double x, double y, double z, float yaw, float pitch, int slot, int sid,
                      float mx, float my, int w, int h, int flags, String extra) {}
    private record Inv(int ms, int[] slots, byte[][] data) {}

    private static volatile boolean playing = false;
    private static List<Pkt> pkts;
    private static List<St> states;
    private static List<Inv> invs;
    private static Map<Integer, String> screens;
    private static int pi, si, ii, tickNo;
    private static EmbeddedChannel channel;
    private static Connection connection;
    private static boolean ourScreen, prevSwing;
    private static int prevSwingTime;
    public static volatile String status = "";

    public static boolean isPlaying() { return playing; }

    // ---------------------------------------------------------------- loading
    private static void load(Path f) throws IOException {
        pkts = new ArrayList<>(); states = new ArrayList<>(); invs = new ArrayList<>(); screens = new HashMap<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new java.util.zip.Inflater(), 1 << 15), 1 << 16))) {
            byte[] magic = new byte[8]; in.readFully(magic);
            String mg = new String(magic);
            if (!mg.equals("GUIREC01") && !mg.equals("GUIREC02")) throw new IOException("Not a GUIREC file");
            boolean v2 = mg.equals("GUIREC02");
            while (true) {
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }
                if (t == 0) break;
                try {
                    if (t == 1) {
                        int ms = in.readInt(); in.readUnsignedByte(); int len = in.readInt();
                        byte[] b = new byte[len]; in.readFully(b); pkts.add(new Pkt(ms, b));
                    } else if (t == 2) {
                        int ms = in.readInt();
                        double x = in.readDouble(), y = in.readDouble(), z = in.readDouble();
                        float yaw = in.readFloat(), pit = in.readFloat();
                        int slot = in.readUnsignedByte(); int sid = in.readShort();
                        float mx = in.readFloat(), my = in.readFloat(); int w = in.readShort(), h = in.readShort();
                        int fl = 0; String extra = "";
                        if (v2) { fl = in.readUnsignedByte(); extra = in.readUTF(); }
                        states.add(new St(ms, x, y, z, yaw, pit, slot, sid, mx, my, w, h, fl, extra));
                    } else if (t == 3) {
                        int id = in.readShort(); screens.put(id, in.readUTF());
                    } else if (t == 4) {
                        int ms = in.readInt(); int n = in.readUnsignedByte();
                        int[] sl = new int[n]; byte[][] dt = new byte[n][];
                        for (int k = 0; k < n; k++) { sl[k] = in.readUnsignedByte(); int len = in.readInt(); dt[k] = new byte[len]; in.readFully(dt[k]); }
                        invs.add(new Inv(ms, sl, dt));
                    } else throw new IOException("Bad record type " + t);
                } catch (EOFException e) { break; }
            }
        }
    }

    // ---------------------------------------------------------------- start / stop
    public static void play(Minecraft mc, Path f) {
        if (playing) return;
        try {
            load(f);
            if (pkts.isEmpty()) { status = "Replay has no packets."; return; }
            status = "Loading replay...";
            connection = new Connection(PacketFlow.CLIENTBOUND);
            channel = new EmbeddedChannel();
            Connection.configureInMemoryPipeline(channel.pipeline(), PacketFlow.CLIENTBOUND);
            channel.pipeline().addLast(HandlerNames.PACKET_HANDLER, connection);
            connection.channelActive(channel.pipeline().context(connection));

            var user = mc.getUser();
            GameProfile profile = new GameProfile(user.getProfileId(), user.getName());
            CommonListenerCookie cookie = new CommonListenerCookie(
                    new LevelLoadTracker(), profile,
                    mc.getTelemetryManager().createWorldSessionManager(false, null, null),
                    RegistryAccess.EMPTY, FeatureFlags.DEFAULT_FLAGS, "vanilla", null, null,
                    Map.of(), mc.gui.getChat().storeState(), Map.of(), ServerLinks.EMPTY, Map.of(), false);
            var listener = new ClientConfigurationPacketListenerImpl(mc, connection, cookie);
            connection.setupInboundProtocol(ConfigurationProtocols.CLIENTBOUND, listener);
            connection.setupOutboundProtocol(ConfigurationProtocols.SERVERBOUND);

            pi = 0; si = 0; ii = 0; tickNo = 0; ourScreen = false; prevSwing = false; prevSwingTime = 0;
            playing = true;
            ReplayRecorder.stop();
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Could not start replay: " + t;
            playing = false;
        }
    }

    public static void stop(Minecraft mc) {
        if (!playing) return;
        playing = false;
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        channel = null; connection = null; pkts = null; states = null; invs = null;
        mc.disconnect(new TitleScreen(), false);
    }

    // ---------------------------------------------------------------- once per game tick: feed packets
    public static void onTick(Minecraft mc) {
        if (!playing) return;
        try {
            tickNo++;
            int limit = tickNo * 50;
            while (pi < pkts.size() && pkts.get(pi).ms() <= limit) {
                ChannelHandlerContext ctx = channel.pipeline().context(HandlerNames.DECODER);
                if (ctx == null) break;
                ((ByteToMessageDecoder) ctx.handler()).channelRead(ctx, Unpooled.wrappedBuffer(pkts.get(pi).data()));
                pi++;
            }
            channel.releaseOutbound();
            connection.tick();
            if (pi >= pkts.size() && limit > pkts.get(pkts.size() - 1).ms() + 3000) status = "Replay finished. Press F7 to leave.";
        } catch (Throwable t) {
            t.printStackTrace();
            status = "Replay error: " + t;
            playing = false;
        }
    }

    // ---------------------------------------------------------------- once per frame, BEFORE it is drawn
    public static void onFrame(Minecraft mc, float partial) {
        if (!playing || states == null || states.isEmpty() || mc.player == null || mc.level == null) return;
        int now = Math.max(0, (int) ((tickNo - 1 + partial) * 50f));
        while (si + 1 < states.size() && states.get(si + 1).ms() <= now) si++;
        St s = states.get(si);
        St n = si + 1 < states.size() ? states.get(si + 1) : s;
        double span = n.ms() - s.ms();
        double t = span > 0 ? Math.min(1.0, Math.max(0.0, (now - s.ms()) / span)) : 0.0;
        var p = mc.player;

        p.setPos(s.x() + (n.x() - s.x()) * t, s.y() + (n.y() - s.y()) * t, s.z() + (n.z() - s.z()) * t);
        float yaw = (float) (s.yaw() + (n.yaw() - s.yaw()) * t), pit = (float) (s.pitch() + (n.pitch() - s.pitch()) * t);
        p.setYRot(yaw); p.setXRot(pit);
        p.setOldPosAndRot();
        p.setYHeadRot(yaw);
        if (span > 0) {   // real velocity (blocks per tick) so view-bobbing and the arm sway behave
            double k = 50.0 / span;
            p.setDeltaMovement((n.x() - s.x()) * k, (n.y() - s.y()) * k, (n.z() - s.z()) * k);
        }
        p.getInventory().setSelectedSlot(s.slot());

        // items the client changed itself (creative inventory, cursor item)
        try {
            while (ii < invs.size() && invs.get(ii).ms() <= now) {
                Inv e = invs.get(ii++);
                for (int k = 0; k < e.slots().length; k++) {
                    ItemStack st = ItemStack.OPTIONAL_STREAM_CODEC.decode(
                            new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(e.data()[k]), mc.level.registryAccess()));
                    int sl = e.slots()[k];
                    if (sl == 100) p.containerMenu.setCarried(st);
                    else if (sl < p.inventoryMenu.slots.size()) p.inventoryMenu.getSlot(sl).set(st);
                }
            }
        } catch (Throwable ex) { ex.printStackTrace(); }

        // arm swing: start a swing when it begins, or restarts while still swinging
        boolean swing = (s.flags() & 1) != 0;
        int swingTime = (s.flags() >> 2) & 7;
        if (swing && (!prevSwing || swingTime < prevSwingTime))
            p.swing((s.flags() & 2) != 0 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        prevSwing = swing; prevSwingTime = swingTime;

        // screens
        String name = s.sid() == 0 ? "" : screens.getOrDefault(s.sid(), "");
        if (name.endsWith("CreativeModeInventoryScreen")) {
            if (!(mc.screen instanceof CreativeModeInventoryScreen)) {
                mc.setScreen(new CreativeModeInventoryScreen(p, FeatureFlags.DEFAULT_FLAGS, true)); ourScreen = true;
            }
            if (mc.screen instanceof CreativeAccess ca) {
                String[] parts = s.extra().split(";", 3);
                try {
                    if (parts.length >= 1) ca.guirec$setTab(Integer.parseInt(parts[0]));
                    if (parts.length >= 2) ca.guirec$setScroll(Float.parseFloat(parts[1]));
                    if (parts.length >= 3) ca.guirec$setSearch(parts[2]);
                } catch (NumberFormatException ignored) {}
            }
        } else if (name.endsWith("InventoryScreen")) {
            if (!(mc.screen instanceof InventoryScreen)) { mc.setScreen(new InventoryScreen(p)); ourScreen = true; }
        } else if (name.endsWith("PauseScreen")) {
            if (!(mc.screen instanceof PauseScreen)) { mc.setScreen(new PauseScreen(true)); ourScreen = true; }
        } else if (name.endsWith("ChatScreen")) {
            if (!(mc.screen instanceof ChatScreen)) { mc.setScreen(new ChatScreen("", false)); ourScreen = true; }
            if (mc.screen instanceof ChatAccess ca) ca.guirec$setText(s.extra());
        } else if (name.isEmpty() && mc.screen != null) {
            // recorded: no screen open. Close containers (the server never tells us when the player closes one).
            if (mc.screen instanceof AbstractContainerScreen<?>) { p.closeContainer(); ourScreen = false; }
            else if (ourScreen) { mc.setScreen(null); ourScreen = false; }
        }

        if (mc.screen != null && s.w() > 0 && s.h() > 0 && mc.mouseHandler instanceof MouseAccess m) {
            var w = mc.getWindow();
            m.guirec$set(s.mx() * w.getWidth() / s.w(), s.my() * w.getHeight() / s.h());
        }
    }
}
