package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Vanilla-style menu: recording status + list of replays to preview. Uses Minecraft's own widgets and font. */
public class RecorderScreen extends Screen {
    private final Screen parent;

    public RecorderScreen(Screen parent) {
        super(Component.literal("GUI Replay"));
        this.parent = parent;
    }

    private List<Path> replays() {
        List<Path> out = new ArrayList<>();
        try {
            Path dir = this.minecraft.gameDirectory.toPath().resolve("guirec").resolve("replays");
            if (Files.isDirectory(dir)) try (var s = Files.list(dir)) {
                s.filter(p -> p.toString().endsWith(".guirec"))
                 .sorted(Comparator.comparingLong((Path p) -> p.toFile().lastModified()).reversed())
                 .limit(5).forEach(out::add);
            }
        } catch (Exception ignored) {}
        return out;
    }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = 34;
        addRenderableWidget(Button.builder(autoLabel(), b -> {
            ReplayRecorder.autoRecord = !ReplayRecorder.autoRecord;
            b.setMessage(autoLabel());
        }).bounds(cx, y, 240, 20).build());
        y += 28;
        if (this.minecraft.level == null) {
            for (Path p : replays()) {
                String label = String.format("Play %s (%.1f MB)", p.getFileName().toString().replace("replay_", "").replace(".guirec", ""),
                        p.toFile().length() / 1048576.0);
                addRenderableWidget(Button.builder(Component.literal(label), b -> {
                    this.minecraft.setScreen(null);
                    ReplayPlayer.play(this.minecraft, p);
                }).bounds(cx, y, 240, 20).build());
                y += 24;
            }
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx, this.height - 28, 240, 20).build());
    }

    private Component autoLabel() {
        return Component.literal("Auto-record on world join: " + (ReplayRecorder.autoRecord ? "ON" : "OFF"));
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), 14, 0xFFFFFFFF);
        int y = this.height - 62;
        if (ReplayRecorder.isActive())
            line(g, String.format("RECORDING  %d packets, %d frames, %.2f MB", ReplayRecorder.packets, ReplayRecorder.states, ReplayRecorder.fileSize() / 1048576.0), y, 0xFFFF6666);
        else if (this.minecraft.level != null)
            line(g, "Go to the main menu to play a replay", y, 0xFFAAAAAA);
        if (!ReplayPlayer.status.isEmpty()) line(g, ReplayPlayer.status, y + 14, 0xFFFFDD66);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
