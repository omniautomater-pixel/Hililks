package com.guirec;
/** Implemented by KeyboardHandlerMixin: lets the replay type keys exactly like the recorded player did. */
public interface KbAccess {
    void guirec$key(long window, int action, int key, int scancode, int mods);
    void guirec$char(long window, int codepoint);
}
