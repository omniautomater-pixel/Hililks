GUI REPLAY - recording + in-game preview
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
Play (preview): main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Records client-side things too (container moves, block cracks, sneak, eating). Pojav: hide the launcher MOUSE overlay while a replay plays (the mod draws its own cursor).
Next: FFmpeg render (2K 120fps).
