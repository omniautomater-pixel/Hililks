GUI REPLAY - STAGE 1 + 2
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
Play (preview): main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Stage 3 (FFmpeg render 2K 120fps) is next.
