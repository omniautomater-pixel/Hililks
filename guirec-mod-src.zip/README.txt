GUI REPLAY
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
It saves (1) every packet the server sends, (2) your camera each frame, (3) every key / mouse / touch input.
Replay: the packets rebuild the world; your recorded input is fed back into the REAL game logic, so everything the game
generates itself (block cracks, GUIs, container moves, sneaking, eating, creative screen, chat typing, other mods' screens)
happens automatically. Old recordings (no input) use the older emulation.
Play: main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Pojav: hide the launcher MOUSE overlay while a replay plays.

Sounds + block-break cracks are recorded as RESULTS (everything the game plays/sets) and replayed directly.
If something does not replay right, send .minecraft/guirec/replay_debug.log

CAMERA SMOOTHING (v1.0.1)
Replay camera is no longer straight lines between recorded frames. CamTrack builds a smooth cubic (monotone Hermite) path
through the recorded camera samples and the replay samples it at the exact fractional time of every rendered frame, so
60 / 120 / 240 fps playback all look smooth even if the recording was only 30 fps. Also: yaw wrap (350 -> 10) no longer
spins the camera, teleports are cuts (no fly-across), frame time is averaged so uneven frame starts do not stutter,
head rotation + velocity follow the same smooth path.

SPRINT JITTER FIX (v1.0.2)
- Recorder now stamps each camera sample with the START of the frame (MinecraftMixin, runTick HEAD), not the end.
  (Old: late by the random render time of that frame -> shake that grows with speed, worst while sprinting.)
- Playback averages the timestamps of OLD recordings (zero lag) to remove that error, uses a wider velocity window,
  and takes the sprint flag from the recording so sprint FOV / bobbing cannot flicker.

HAND SWING WHILE BREAKING (v1.0.3)
Holding attack to break blocks now swings the hand repeatedly in the replay. The swing is taken from the recorded swing
state in every mode (before, new recordings relied on re-simulated logic and swung only once).

HUMAN-SMOOTH CAMERA (v1.0.4)
Gaussian low-pass on the recorded camera (view 30 ms, position 45 ms sigma) before the curve is built: removes mouse-step /
low-fps / timer noise but keeps real hand motion. Strength knob: create .minecraft/guirec/smooth.txt with one number
(1 = default, 2 = smoother, 3 = very smooth, 0 = off). Picked up the next time you play a replay.

LESS LAG WHILE LOADING CHUNKS (v1.0.5)
Recording: each packet is copied once (was 3x), nothing is copied when not recording, the lock is no longer held while
copying, and the compressing thread runs at low priority so it cannot steal CPU from the game.
Replay: 4 ms (was 8 ms) packet budget per frame and a limit on packet data per frame, so a burst of chunks is spread over
several frames instead of freezing one. No limit when the replay is >400 ms behind, so it still catches up. Order unchanged.

INVENTORY INSTANT + CURSOR (v1.0.6)
- The recorded inventory / carried item / open chest changes (what the client showed, incl. the instant result of your click)
  are now applied in new recordings too, at their recorded time. Before, shift-click / taking items could show only when the
  recorded server packet arrived (late), because the replayed click could miss.
- Safety net: if the recording has had no screen for 250 ms and an inventory / chest is still open in the replay, it is closed.
- Replay mouse arrow is smaller (8 px instead of 12).
