GUI REPLAY
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
It saves (1) every packet the server sends, (2) your camera each frame, (3) every key / mouse / touch input.
Replay: the packets rebuild the world; your recorded input is fed back into the REAL game logic, so everything the game
generates itself (block cracks, GUIs, container moves, sneaking, eating, creative screen, chat typing, other mods' screens)
happens automatically. Old recordings (no input) use the older emulation.
Play: main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Pojav: hide the launcher MOUSE overlay while a replay plays.

v1.1 (GUIREC04 files)
Besides packets + input, the recorder now saves what the game does on its own and no server packet carries:
every one-shot sound (position/volume/pitch), your block-crack texture, and your arm swings. In a replay the game's own
versions of those are switched off and the recorded ones are played instead. The replay clock is now real time (not game
ticks), so the camera no longer jumps when ticks bunch up. Old recordings (GUIREC01-03) still play the old way.
