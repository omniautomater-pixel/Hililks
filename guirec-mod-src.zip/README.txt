GUI REPLAY
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
It saves (1) every packet the server sends, (2) your camera each frame, (3) every key / mouse / touch input.
Replay: the packets rebuild the world; your recorded input is fed back into the REAL game logic, so everything the game
generates itself (block cracks, GUIs, container moves, sneaking, eating, creative screen, chat typing, other mods' screens)
happens automatically. Old recordings (no input) use the older emulation.
Play: main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Pojav: hide the launcher MOUSE overlay while a replay plays.

v1.1 (GUIREC04 files)
Besides packets + input, the recorder now saves what the game does on its own and no server packet carries:
every one-shot sound (position/volume/pitch), your block-crack texture, and your arm swings. In a replay the game's own
versions of those are switched off and the recorded ones are played instead. The replay clock is now real time (not game
ticks), so the camera no longer jumps when ticks bunch up. Old recordings (GUIREC01-03) still play the old way.

v1.2
Replay clock now slows down (instead of freezing) when packet processing falls behind, e.g. chunk bursts after raising
the render distance; per-frame packet work is always time-capped. Camera follows a smooth cubic (Catmull-Rom) curve
through the recorded samples instead of straight lines, which removes the low-fps "stepping" look.

v1.4  PLAYBACK CONTROLS
Press F8 during a replay -> controls: seek -30s/-10s/-5s/+5s/+10s/+30s, frame step (-1f/+1f, pauses), Pause/Play, Speed
(x0.1 .. x4), Start, a clickable progress bar, and "60fps" = smooth preview: every 1/60 s of the recording is fully rendered,
so on a slow device it plays in slow motion (20 fps device = 1/3 speed) but nothing is skipped or laggy.
Normal mode stays real-time, so lag shows like in the game. Seeking forward fast-forwards the packets; seeking backward rebuilds
the world and fast-forwards from the start (takes a moment). Close the controls with Close / Esc to see the replay clean.
(Rendering to a video file is left for later; the fixed 1/60 s clock used by the smooth preview is the part it will reuse.)
