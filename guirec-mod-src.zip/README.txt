GUI REPLAY
Author: IamZeeva  |  YouTube: https://youtube.com/@iamzeeva
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
It saves (1) every packet the server sends, (2) your camera each frame, (3) every key / mouse / touch input.
Replay: the packets rebuild the world; your recorded input is fed back into the REAL game logic, so everything the game
generates itself (block cracks, GUIs, container moves, sneaking, eating, creative screen, chat typing, other mods' screens)
happens automatically. Old recordings (no input) use the older emulation.
Play: main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Pojav: hide the launcher MOUSE overlay while a replay plays.

Sounds + block-break cracks are recorded as RESULTS (everything the game plays/sets) and replayed directly.
If something does not replay right, send .minecraft/guirec/replay_debug.log

CAMERA SMOOTHING (v1.0.1)
Replay camera is no longer straight lines between recorded frames. CamTrack builds a smooth cubic (monotone Hermite) path
through the recorded camera samples and the replay samples it at the exact fractional time of every rendered frame, so
60 / 120 / 240 fps playback all look smooth even if the recording was only 30 fps. Also: yaw wrap (350 -> 10) no longer
spins the camera, teleports are cuts (no fly-across), frame time is averaged so uneven frame starts do not stutter,
head rotation + velocity follow the same smooth path.

SPRINT JITTER FIX (v1.0.2)
- Recorder now stamps each camera sample with the START of the frame (MinecraftMixin, runTick HEAD), not the end.
  (Old: late by the random render time of that frame -> shake that grows with speed, worst while sprinting.)
- Playback averages the timestamps of OLD recordings (zero lag) to remove that error, uses a wider velocity window,
  and takes the sprint flag from the recording so sprint FOV / bobbing cannot flicker.

HAND SWING WHILE BREAKING (v1.0.3)
Holding attack to break blocks now swings the hand repeatedly in the replay. The swing is taken from the recorded swing
state in every mode (before, new recordings relied on re-simulated logic and swung only once).

HUMAN-SMOOTH CAMERA (v1.0.4)
Gaussian low-pass on the recorded camera (view 30 ms, position 45 ms sigma) before the curve is built: removes mouse-step /
low-fps / timer noise but keeps real hand motion. Strength knob: create .minecraft/guirec/smooth.txt with one number
(1 = default, 2 = smoother, 3 = very smooth, 0 = off). Picked up the next time you play a replay.

LESS LAG WHILE LOADING CHUNKS (v1.0.5)
Recording: each packet is copied once (was 3x), nothing is copied when not recording, the lock is no longer held while
copying, and the compressing thread runs at low priority so it cannot steal CPU from the game.
Replay: 4 ms (was 8 ms) packet budget per frame and a limit on packet data per frame, so a burst of chunks is spread over
several frames instead of freezing one. No limit when the replay is >400 ms behind, so it still catches up. Order unchanged.

INVENTORY INSTANT + CURSOR (v1.0.6)
- The recorded inventory / carried item / open chest changes (what the client showed, incl. the instant result of your click)
  are now applied in new recordings too, at their recorded time. Before, shift-click / taking items could show only when the
  recorded server packet arrived (late), because the replayed click could miss.
- Safety net: if the recording has had no screen for 250 ms and an inventory / chest is still open in the replay, it is closed.
- Replay mouse arrow is smaller (8 px instead of 12).

NO VIEW-BOB SHAKE IN REPLAYS (v1.0.7)
The game adds a sine sway to the camera every frame from walkDist/bob, which the REPLAY's own physics produces (not the
recording) -> irregular shaking, worst while sprinting. It is now skipped during replays (GameRendererMixin.bobView, require=0,
your options are not touched). To get vanilla bobbing back put the word "bob" in .minecraft/guirec/smooth.txt (e.g. "1 bob").
replay_debug.log now also has a frame-time line per second (fps, avg, sd, max) to tell frame pacing problems from camera ones.

ROOT CAUSE OF THE REPLAY CAMERA JITTER (v1.0.8)
26.1 builds a frame as: Minecraft.renderFrame -> GameRenderer.update (Camera.update takes position + rotation from the player)
-> pick -> extract -> render. The replay set the player's position/rotation at the start of GameRenderer.render(), i.e. AFTER
the camera was already built. So the camera showed the previous frame's value, and on tick frames the replay's own physics
position = constant jitter that grows with speed (sprint). The replay now runs right before Camera.update (GameRendererMixin
"update(DeltaTracker,Z)V", require=0, with a fallback at render HEAD). Also fixes pick()/hand using stale positions.

LEAVING A REPLAY (v1.0.9)
Only F7 used to end the replay state. Leaving any other way (pause menu > Disconnect, Save and Quit, the recorded server
disconnecting) left "playing" = true: the next replay silently did nothing and on a real server the mouse / keys / sounds /
outgoing packets stayed cancelled (broken game, crash). Now Minecraft.disconnect(...) (both overloads, require=0) calls
ReplayPlayer.onLeave(), and the Replays screen clears a stale flag before starting a replay.

SERVER MENUS (NPC / lobby compass) FLICKERING AWAY (v1.0.10)
Bug from v1.0.6: the "no screen recorded -> close the container" safety net also fired in the short moment between the replay
opening a server menu from its packet and the recorded screen state flipping, so menus were closed right away (or never seen),
depending on timing and worst when opened and closed quickly. The 500 ms grace now counts from the moment the replay's screen
opened.

SMOOTH UI CURSOR AT ANY FPS (v1.0.11)
A recording made at 20 fps only has ~20 mouse positions per second, so in a 120 fps replay the inventory / NPC menu cursor, the
carried item, hover highlights and the player model in the inventory still moved at 20 fps. ReplayPlayer.buildCursor() now builds a
smooth monotone curve (no overshoot) through the recorded cursor positions of the time a screen was open (events of one recorded
frame are spread over that frame), and smoothCursor() moves the real cursor along it every rendered frame.
Clicks / scrolls / keys first snap the cursor back to the exact recorded point, so the same slot is hit as in the recording.
While a mouse button is held (drag) the exact recorded points are used. The replay arrow is drawn at sub-pixel position.

REPLAY EDITOR (v1.0.12)
Main menu -> Replays -> "Edit" next to a replay. The replay plays in edit mode: a thin timeline bar sits at the bottom, F8 opens the
editor (replay paused): -10s / -1s / +1s / +10s, click or drag the timeline to jump (forward = fast-forward, backward = the replay is
loaded again and fast-forwarded), Play = continue from there (any fps). Set A / Set B + Delete = cut that part out, Split = split at
the current time, Undo = undo the last delete / split, Save = writes NEW replays into the Replays list (the original is never changed;
no split = replay_<time>_edit, with splits = replay_<time>_part1, _part2 ...). Keys in the editor: Space / Esc / F8 = play, Left / Right = +-1 s, F7 = leave.
A deleted part is skipped when playing. Its network packets are kept (moved to the cut point and played in one go) so the world stays
correct; camera, sounds and input of the part are removed. Cutting off the END drops everything after it.
The Replays list now has pages (5 per page) and shows readable dates.

SOUNDS (v1.1.1)
Sound is recorded where the game plays it (SoundManager.play, used by every sound: server packets, your own steps / breaking /
UI clicks, other mods). The menu shows "N sounds" while recording. Replay plays the recorded sounds; the game's own copy of the SAME
sound (same id within 160 ms) is silenced so nothing plays twice, but a sound the recording does not have is NOT blocked any more
(before: every game sound was blocked, so anything missing from the recording was silent). One broken sound no longer stops a replay.
replay_debug.log has a "sounds: in file / played / last" line per second.

VIDEO EXPORT WITH BUILT-IN FFMPEG (v1.0.13)
Replays -> "Export" button next to a replay (top-left button: 30 / 60 / 24 fps). The replay plays with a fixed clock (each rendered frame
= exactly 1/fps), every frame is read back and encoded to H.264 by ffmpeg: .minecraft/guirec/exports/<replay>_<fps>fps.mp4. Slow phone =
slower export, but the video stays smooth. F7 = stop early (the part exported so far is kept). No audio in the video (yet).
ffmpeg is INSIDE this mod (resources/guirec_ffmpeg/arm64-v8a, from the PojavLauncher FFmpeg plugin): no plugin APK needed. On first export it is
copied to <java.io.tmpdir>/guirec-ffmpeg (or .minecraft/guirec/ffmpeg) and started directly, or through /system/bin/linker64 if Android blocks
the direct start. On PC the ffmpeg from PATH is used. Phone must be arm64.
If the export fails send .minecraft/guirec/export_debug.log (shows which start method / which ffmpeg line failed).
NOTE: the repo must contain the .so files (about 19 MB) - upload the whole folder, including src/main/resources/guirec_ffmpeg.
FFmpeg order: 1) ffmpeg from PATH (phone or PC), 2) the built-in one. The folder src/main/resources/guirec_ffmpeg can be deleted
(small jar): the mod then only uses an ffmpeg that is already installed.
