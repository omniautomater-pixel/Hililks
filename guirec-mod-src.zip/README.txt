GUI REPLAY
Record: join any world -> auto recorded to .minecraft/guirec/replays/*.guirec (small, no lag).
It saves (1) every packet the server sends, (2) your camera each frame, (3) every key / mouse / touch input.
Replay: the packets rebuild the world; your recorded input is fed back into the REAL game logic, so everything the game
generates itself (block cracks, GUIs, container moves, sneaking, eating, creative screen, chat typing, other mods' screens)
happens automatically. Old recordings (no input) use the older emulation.
Play: main menu -> "Replays" button (top right) -> Play. F7 = leave replay. F8 = menu in-game.
Pojav: hide the launcher MOUSE overlay while a replay plays.
