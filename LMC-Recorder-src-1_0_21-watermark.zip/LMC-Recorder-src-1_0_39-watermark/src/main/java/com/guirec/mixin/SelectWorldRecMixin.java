package com.guirec.mixin;

import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** v1.0.37: "Start rec / Stop rec" button in the top right corner of this menu. */
@Mixin(SelectWorldScreen.class)
public abstract class SelectWorldRecMixin extends Screen {
    protected SelectWorldRecMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void guirec$recButton(CallbackInfo ci) {
        this.addRenderableWidget(com.guirec.RecButton.make(this.width - 90, 6, 84));
    }
}
