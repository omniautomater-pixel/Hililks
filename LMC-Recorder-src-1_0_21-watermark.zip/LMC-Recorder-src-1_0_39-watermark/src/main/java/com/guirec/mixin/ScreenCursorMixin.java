package com.guirec.mixin;

import com.guirec.CursorStyle;
import com.guirec.FarChunks;
import com.guirec.ReplayEditorScreen;
import com.guirec.ReplayPlayer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws a mouse cursor on top of screens while a replay plays (the replay hides the launcher's own pointer).
 * v1.0.31: it is YOUR real mouse in every menu of the mod (menu, cursor editor, skins, export), also while RECORDING (F8) and in the
 * replay editor (there the recorded cursor of the video is drawn in addition, as a "ghost", at its recorded place).
 */
@Mixin(Screen.class)
public class ScreenCursorMixin {
    @Inject(method = "extractRenderStateWithTooltipAndSubtitles", at = @At("TAIL"), require = 0)
    private void guirec$cursor(GuiGraphicsExtractor g, int mx, int my, float delta, CallbackInfo ci) {
        Screen self = (Screen) (Object) this;
        boolean own = ReplayPlayer.isOwnScreen(self);
        boolean editor = self instanceof ReplayEditorScreen;
        if (!ReplayPlayer.isPlaying()) return;                 // not in a replay (also not while RECORDING / exporting): only your own cursor
        if (own && ReplayPlayer.userUi) return;                // v1.0.34: a menu YOU opened (F8): only your real cursor, no second arrow behind it

        var mc = net.minecraft.client.Minecraft.getInstance();
        // your real mouse, sub-pixel: mx / my are whole GUI units, so at high GUI scales the arrow would hop in steps
        float fx = (float) (mc.mouseHandler.getScaledXPos(mc.getWindow()) - mx), fy = (float) (mc.mouseHandler.getScaledYPos(mc.getWindow()) - my);
        if (!(fx >= -1f && fx <= 1f)) fx = 0f;
        if (!(fy >= -1f && fy <= 1f)) fy = 0f;

        if (editor) {
            // v1.0.24: the replay's own recorded cursor, at its recorded position (only while the recorded video had a screen open)
            if (ReplayPlayer.ghostOn) {
                int gx = (int) Math.floor(ReplayPlayer.ghostX), gy = (int) Math.floor(ReplayPlayer.ghostY);
                draw(g, gx, gy, (float) (ReplayPlayer.ghostX - gx), (float) (ReplayPlayer.ghostY - gy), true);
            }
            draw(g, mx, my, fx, fy, false);      // v1.0.31: and YOUR cursor (plain arrow) so you can see what you are clicking
        } else {
            draw(g, mx, my, fx, fy, true);
        }
    }

    private static void draw(GuiGraphicsExtractor g, int mx, int my, float fx, float fy, boolean styled) {
        float k = FarChunks.cursorSize / 8f;                 // 8 = default arrow height, set with the "Cursor size" slider
        g.pose().pushMatrix();
        g.pose().translate(mx + fx, my + fy);
        g.pose().scale(k, k);
        if (!styled || !CursorStyle.draw(g)) {               // sword / pickaxe / saved pixel cursor; false = the old arrow
            for (int r = 0; r < 8; r++) {                        // black arrow outline
                int w = Math.min(r + 2, 6);
                g.fill(0, r, w, r + 1, 0xFF000000);
            }
            for (int r = 1; r < 7; r++) {                        // white inside
                int w = Math.min(r + 1, 5);
                g.fill(1, r, w, r + 1, 0xFFFFFFFF);
            }
        }
        g.pose().popMatrix();
    }
}
