package com.guirec;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * Cuts a .guirec file (no Minecraft classes in here, it only moves records around).
 *
 * Deleting a part of the timeline [a,b):
 *   - camera / screen state, sounds, cracks and input inside the part are dropped (only "release" events are kept, so no key stays stuck)
 *   - NETWORK PACKETS inside the part are KEPT but moved to the cut point: the world must still receive every block / entity change,
 *     otherwise the rest of the replay would show a different world. They are simply played in one go when the replay reaches the cut.
 *   - everything after the part moves earlier by (b-a) ms.
 * Split = the same cut done twice: one file keeps [0,t), the other keeps [t,end).
 */
public final class ReplayEdit {
    private ReplayEdit() {}

    private record Rec(int type, int ms, byte[] raw, boolean release) {}

    /** Copies every byte the DataInputStream reads, so a record can be written back exactly as it was. */
    private static final class Capture extends FilterInputStream {
        final ByteArrayOutputStream cap = new ByteArrayOutputStream(256);
        Capture(InputStream in) { super(in); }
        @Override public int read() throws IOException { int b = in.read(); if (b >= 0) cap.write(b); return b; }
        @Override public int read(byte[] b, int off, int len) throws IOException { int n = in.read(b, off, len); if (n > 0) cap.write(b, off, n); return n; }
    }

    private static void skip(DataInputStream in, int n) throws IOException { in.readFully(new byte[n]); }

    private static String magic;

    private static List<Rec> read(Path f) throws IOException {
        List<Rec> out = new ArrayList<>();
        try (InputStream raw = new BufferedInputStream(new InflaterInputStream(new BufferedInputStream(Files.newInputStream(f)), new Inflater(), 1 << 15), 1 << 16)) {
            Capture cap = new Capture(raw);
            DataInputStream in = new DataInputStream(cap);
            byte[] mg = new byte[8];
            new DataInputStream(raw).readFully(mg);
            magic = new String(mg);
            if (!magic.equals("GUIREC01") && !magic.equals("GUIREC02") && !magic.equals("GUIREC03") && !magic.equals("GUIREC04")) throw new IOException("Not a GUIREC file");
            boolean v2 = !magic.equals("GUIREC01"), v3 = magic.equals("GUIREC03") || magic.equals("GUIREC04");
            while (true) {
                cap.cap.reset();
                int t;
                try { t = in.readUnsignedByte(); } catch (EOFException e) { break; }
                if (t == 0) break;
                int ms = -1;
                boolean release = false;
                try {
                    switch (t) {
                        case 1 -> { ms = in.readInt(); in.readUnsignedByte(); skip(in, in.readInt()); }
                        case 2 -> {
                            ms = in.readInt(); skip(in, 24 + 8 + 1 + 2 + 8 + 4);   // 3 doubles, 2 floats, slot, screen id, 2 floats, 2 shorts
                            if (v2) { in.readUnsignedByte(); in.readUTF(); }
                            if (v3) skip(in, 1 + 1 + 2 + 8 + 1);
                        }
                        case 3 -> { in.readShort(); in.readUTF(); }
                        case 4 -> { ms = in.readInt(); int n = in.readUnsignedByte(); for (int k = 0; k < n; k++) { in.readUnsignedByte(); skip(in, in.readInt()); } }
                        case 5 -> { ms = in.readInt(); in.readInt(); int n = in.readUnsignedShort(); for (int k = 0; k < n; k++) { in.readUnsignedShort(); skip(in, in.readInt()); } }
                        case 6 -> {
                            ms = in.readInt(); int kind = in.readUnsignedByte();
                            switch (kind) {
                                case 0 -> { int a = in.readUnsignedByte(); skip(in, 12); release = a == 0; }
                                case 1 -> skip(in, 4);
                                case 2 -> { skip(in, 8); int a = in.readUnsignedByte(); release = a == 0; }
                                case 3, 4 -> skip(in, 16);
                                default -> throw new IOException("Bad input kind " + kind);
                            }
                        }
                        case 7 -> { ms = in.readInt(); in.readUTF(); in.readUnsignedByte(); skip(in, 8 + 24 + 2); }
                        case 8 -> { ms = in.readInt(); skip(in, 9); }
                        case 9 -> { ms = in.readInt(); skip(in, 2 + 4 + 4 + 2 + 2); }
                        default -> throw new IOException("Bad record type " + t);
                    }
                } catch (EOFException e) { break; }
                out.add(new Rec(t, ms, cap.cap.toByteArray(), release));
            }
        }
        return out;
    }

    /** Sorted, merged ranges [a,b) in original ms; b may be Integer.MAX_VALUE (= to the end). */
    private static List<long[]> merge(List<long[]> in) {
        List<long[]> s = new ArrayList<>();
        for (long[] r : in) if (r[1] > r[0]) s.add(new long[]{Math.max(0, r[0]), r[1]});
        s.sort(Comparator.comparingLong(r -> r[0]));
        List<long[]> m = new ArrayList<>();
        for (long[] r : s) {
            if (!m.isEmpty() && r[0] <= m.get(m.size() - 1)[1]) m.get(m.size() - 1)[1] = Math.max(m.get(m.size() - 1)[1], r[1]);
            else m.add(new long[]{r[0], r[1]});
        }
        return m;
    }

    /** Writes the edited file. removed = ranges to cut out (original ms). Returns the number of records written. */
    private static int write(List<Rec> recs, List<long[]> removedIn, Path out) throws IOException {
        List<long[]> rm = merge(removedIn);
        int n = rm.size();
        long[] ra = new long[n], rb = new long[n], before = new long[n];   // before[i] = total length removed before range i
        long sum = 0;
        for (int i = 0; i < n; i++) {
            ra[i] = rm.get(i)[0]; rb[i] = rm.get(i)[1]; before[i] = sum;
            if (rb[i] < Integer.MAX_VALUE) sum += rb[i] - ra[i];
        }
        int written = 0;
        try (DataOutputStream o = new DataOutputStream(new DeflaterOutputStream(
                new BufferedOutputStream(new FileOutputStream(out.toFile()), 1 << 16), new Deflater(6), 1 << 15))) {
            o.writeBytes(magic);
            for (Rec r : recs) {
                byte[] raw = r.raw();
                if (r.type() == 3) { o.write(raw); written++; continue; }   // screen dictionary: always kept
                long m = r.ms();
                // last range that starts at or before m
                int lo = -1, hi = n - 1;
                while (lo < hi) { int mid = (lo + hi + 1) >>> 1; if (ra[mid] <= m) lo = mid; else hi = mid - 1; }
                boolean inside = lo >= 0 && m < rb[lo];
                long nt;
                if (inside) {
                    if (rb[lo] == Integer.MAX_VALUE) continue;   // cut off the END: nothing after it will ever be shown, drop it all
                    nt = ra[lo] - before[lo];
                    // what survives inside a deleted part: packets (world must stay correct), the player's own inventory changes
                    // (creative: nothing else would restore them) and key / button RELEASES (so nothing stays held)
                    boolean keep = r.type() == 1 || r.type() == 4 || (r.type() == 6 && r.release());
                    if (!keep) continue;
                } else {
                    nt = lo < 0 ? m : m - (before[lo] + (rb[lo] - ra[lo]));
                }
                int t = (int) Math.max(0, nt);
                byte[] c = raw.clone();
                c[1] = (byte) (t >>> 24); c[2] = (byte) (t >>> 16); c[3] = (byte) (t >>> 8); c[4] = (byte) t;
                o.write(c); written++;
            }
            o.writeByte(0);
        }
        return written;
    }

    /**
     * Saves the edit. removed = deleted ranges {a,b}; splits = split points (ms). One file per part between the split points.
     * Files are named replay_<time>_edit.guirec (one part) or replay_<time>_part1.guirec ... and go to outDir (the Replays list).
     */
    public static List<Path> save(Path src, List<int[]> removed, List<Integer> splits, int totalMs, Path outDir) throws IOException {
        List<Rec> recs = read(src);
        Files.createDirectories(outDir);
        TreeSet<Integer> sp = new TreeSet<>();
        for (int s : splits) if (s > 200 && s < totalMs - 200) sp.add(s);
        List<int[]> parts = new ArrayList<>();           // {from, to}  to = MAX_VALUE for the last one
        int prev = 0;
        for (int s : sp) { parts.add(new int[]{prev, s}); prev = s; }
        parts.add(new int[]{prev, Integer.MAX_VALUE});

        long base = System.currentTimeMillis();
        List<Path> files = new ArrayList<>();
        for (int i = parts.size() - 1; i >= 0; i--) {     // last part first, so part 1 ends up on top of the list (newest)
            int[] p = parts.get(i);
            List<long[]> rm = new ArrayList<>();
            for (int[] r : removed) rm.add(new long[]{r[0], r[1]});
            if (p[0] > 0) rm.add(new long[]{0, p[0]});
            if (p[1] != Integer.MAX_VALUE) rm.add(new long[]{p[1], Integer.MAX_VALUE});
            String name = "replay_" + (base + i) + (parts.size() == 1 ? "_edit" : "_part" + (i + 1)) + ".guirec";
            Path out = outDir.resolve(name);
            write(recs, rm, out);
            files.add(0, out);
        }
        return files;
    }
}
