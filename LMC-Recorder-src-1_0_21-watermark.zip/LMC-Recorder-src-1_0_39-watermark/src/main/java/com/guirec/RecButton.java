package com.guirec;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** v1.0.37: the "Start rec / Stop rec" button on the title screen, the world list and the server list. */
public final class RecButton {
    private RecButton() {}

    private static Component label() {
        return Component.literal(ReplayRecorder.isActive() ? "Stop rec" : "Start rec full");
    }

    public static Button make(int x, int y, int w) {
        return Button.builder(label(), b -> {
            if (ReplayRecorder.isActive()) ReplayRecorder.stop();
            else ReplayRecorder.manualStart();
            b.setMessage(label());
        }).bounds(x, y, w, 20).build();
    }
}
