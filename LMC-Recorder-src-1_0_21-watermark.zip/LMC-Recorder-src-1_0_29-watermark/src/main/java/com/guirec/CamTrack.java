package com.guirec;

/**
 * Smooth camera path built from the recorded per-frame camera samples.
 *
 * The recording only has one sample per frame the recorder rendered (often 30-60 per second, with uneven spacing).
 * Playing that back with straight lines between samples changes the speed at every sample, which looks like judder
 * even when the replay itself renders at 120+ fps. This turns the samples into a C1-continuous cubic Hermite curve
 * (no overshoot, so the camera never "bounces" when you stop turning), so any playback frame rate gets a smooth view.
 *
 * - yaw is unwrapped (350 -> 10 degrees is a +20 turn, not a -340 spin)
 * - teleports / long gaps are treated as cuts: the camera holds, then snaps (no flying across the map)
 * - a tiny zero-lag 3-tap filter removes the 1 ms timestamp quantisation noise of the recording
 *
 * Channels: 0=x 1=y 2=z 3=yaw 4=pitch. Time is in recording milliseconds (double).
 */
public final class CamTrack {
    public static final int CH = 5;
    private static final double GAP_MS = 250.0;       // longer than this between two samples = cut
    private static final double TELEPORT = 24.0;      // blocks between two samples = cut
    private static final double LONG_GAP_MS = 5000.0;  // a hole longer than this is always a cut
    private static final double MAX_SPEED_BPS = 60.0;  // blocks/s: further than TELEPORT + this * gap = teleport, not movement
    // A human hand / walking motion has nothing above ~6 Hz; the recorded samples do (mouse steps, low fps, timer noise).
    // Gaussian low-pass in TIME: sigma 30 ms ~ 4.4 Hz (-3 dB) for the view, 45 ms for position.
    private static final double SIGMA_ROT_MS = 30.0;
    private static final double SIGMA_POS_MS = 45.0;

    private final int n;
    private final double[] t;
    private final double[][] v = new double[CH][];
    private final double[][] m = new double[CH][];    // tangents (units per ms)
    private final boolean[] cut;                      // cut[i] = discontinuity between sample i-1 and i
    private int hint = 0;

    /** Output of the last eval(): position + rotation. */
    public final double[] cur = new double[CH];
    /** Output of the last eval(): velocity per game tick (50 ms), same channels. */
    public final double[] vel = new double[CH];

    public CamTrack(double[] ts, double[] x, double[] y, double[] z, double[] yaw, double[] pitch, int count) {
        this(ts, x, y, z, yaw, pitch, count, 1.0);
    }

    /** strength: 1 = default, 0 = no smoothing (only the curve), 2 = twice as smooth ... */
    public CamTrack(double[] ts, double[] x, double[] y, double[] z, double[] yaw, double[] pitch, int count, double strength) {
        // drop samples whose time does not move forward
        int k = 0;
        double[] tt = new double[count];
        double[][] vv = new double[CH][count];
        double[][] src = {x, y, z, yaw, pitch};
        for (int i = 0; i < count; i++) {
            if (k > 0 && ts[i] <= tt[k - 1]) continue;
            tt[k] = ts[i];
            for (int c = 0; c < CH; c++) vv[c][k] = src[c][i];
            k++;
        }
        n = k;
        t = tt;
        for (int c = 0; c < CH; c++) { v[c] = vv[c]; m[c] = new double[Math.max(n, 1)]; }
        cut = new boolean[Math.max(n, 1)];
        if (n == 0) return;

        for (int i = 1; i < n; i++) {
            double dx = v[0][i] - v[0][i - 1], dy = v[1][i] - v[1][i - 1], dz = v[2][i] - v[2][i - 1];
            double gap = t[i] - t[i - 1], d2 = dx * dx + dy * dy + dz * dz;
            if (gap <= GAP_MS) cut[i] = d2 > TELEPORT * TELEPORT;
            else if (gap > LONG_GAP_MS) cut[i] = true;   // recording paused / loading: real cut
            else {
                // v1.0.30: a lag spike while recording (64 chunks + shaders) leaves a 0.3-5 s hole between two samples. Before, every hole
                // was a "cut": the replay froze, then snapped. Now the camera glides across the hole; only a real teleport is a cut.
                double lim = TELEPORT + MAX_SPEED_BPS * gap / 1000.0;
                cut[i] = d2 > lim * lim;
            }
        }
        // yaw: unwrap to the shortest turn inside each continuous piece
        for (int i = 1; i < n; i++) {
            if (cut[i]) continue;
            double d = v[3][i] - v[3][i - 1];
            d -= 360.0 * Math.floor((d + 180.0) / 360.0);   // wrap to [-180,180)
            v[3][i] = v[3][i - 1] + d;
        }
        smoothTimes(); smoothTimes();   // = 5-tap binomial: removes random per-frame timestamp error (old recordings stamped frame END)
        for (int c = 0; c < CH; c++) gauss(c, (c == 3 || c == 4 ? SIGMA_ROT_MS : SIGMA_POS_MS) * Math.max(0.0, strength));
        for (int c = 0; c < CH; c++) tangents(c);
    }

    public int size() { return n; }
    public double startMs() { return n == 0 ? 0 : t[0]; }
    public double endMs() { return n == 0 ? 0 : t[n - 1]; }

    /**
     * Old recordings stamped each camera sample with a time that is late by that frame's random render time.
     * Real frame starts are far more regular than that, so averaging the stamps with their neighbours (zero lag,
     * order is kept) removes most of the error. At sprint speed that error is what shows up as shaking.
     */
    private void smoothTimes() {
        if (n < 3) return;
        double[] o = t.clone();
        for (int i = 1; i < n - 1; i++) {
            if (cut[i] || cut[i + 1]) continue;
            if (o[i + 1] - o[i - 1] > 120.0) continue;
            t[i] = 0.25 * o[i - 1] + 0.5 * o[i] + 0.25 * o[i + 1];
        }
    }

    /** Zero-lag Gaussian low-pass on one channel, weights by real time distance, never across a cut. */
    private void gauss(int c, double sigma) {
        if (sigma <= 0 || n < 3) return;
        double[] a = v[c], o = a.clone();
        double inv = -0.5 / (sigma * sigma), reach = 3.0 * sigma;
        for (int i = 0; i < n; i++) {
            double sum = o[i], w = 1.0;
            for (int j = i - 1; j >= 0; j--) {
                if (cut[j + 1]) break;
                double d = t[i] - t[j]; if (d > reach) break;
                double g = Math.exp(inv * d * d); sum += g * o[j]; w += g;
            }
            for (int j = i + 1; j < n; j++) {
                if (cut[j]) break;
                double d = t[j] - t[i]; if (d > reach) break;
                double g = Math.exp(inv * d * d); sum += g * o[j]; w += g;
            }
            a[i] = sum / w;
        }
    }

    /** (old 3-tap, no longer used) [0.25 0.5 0.25] along time, only between neighbours that are close in time and not cut. Zero lag. */
    private void smooth() {
        if (n < 3) return;
        for (int c = 0; c < CH; c++) {
            double[] a = v[c], o = a.clone();
            for (int i = 1; i < n - 1; i++) {
                if (cut[i] || cut[i + 1]) continue;
                if (t[i + 1] - t[i - 1] > 120.0) continue;
                // time-weighted so uneven frame spacing does not skew the sample
                double h0 = t[i] - t[i - 1], h1 = t[i + 1] - t[i];
                double w = 0.25;                       // weight of each neighbour at equal spacing
                double wl = w * 2.0 * h1 / (h0 + h1), wr = w * 2.0 * h0 / (h0 + h1);
                a[i] = (1.0 - wl - wr) * o[i] + wl * o[i - 1] + wr * o[i + 1];
            }
        }
    }

    /** Monotone (Fritsch-Carlson) tangents: smooth, and flat where the camera stops, so no overshoot. */
    private void tangents(int c) {
        double[] a = v[c], mm = m[c];
        for (int i = 0; i < n; i++) {
            boolean hasPrev = i > 0 && !cut[i];
            boolean hasNext = i + 1 < n && !cut[i + 1];
            double d0 = hasPrev ? (a[i] - a[i - 1]) / (t[i] - t[i - 1]) : 0;
            double d1 = hasNext ? (a[i + 1] - a[i]) / (t[i + 1] - t[i]) : 0;
            if (hasPrev && hasNext) {
                if (d0 * d1 <= 0) { mm[i] = 0; continue; }
                double h0 = t[i] - t[i - 1], h1 = t[i + 1] - t[i];
                double s = (d0 * h1 + d1 * h0) / (h0 + h1);
                double lim = 3.0 * Math.min(Math.abs(d0), Math.abs(d1));
                mm[i] = Math.signum(s) * Math.min(Math.abs(s), lim);
            } else if (hasPrev) mm[i] = d0;
            else if (hasNext) mm[i] = d1;
            else mm[i] = 0;
        }
    }

    /** Camera at recording time ms (any real number). Fills cur[] and vel[]. */
    public void eval(double ms) {
        if (n == 0) return;
        if (ms <= t[0]) { fill(0, 0, 0, false); return; }
        if (ms >= t[n - 1]) { fill(n - 1, 0, 0, false); return; }
        int i = hint;
        if (i >= n - 1 || t[i] > ms) i = 0;
        if (i > 0 && t[i - 1] <= ms) i--;   // time may step back a little
        while (i + 1 < n - 1 && t[i + 1] <= ms) i++;
        if (t[i] > ms) {                    // rare: moved far back, binary search
            int lo = 0, hi = n - 1;
            while (hi - lo > 1) { int mid = (lo + hi) >>> 1; if (t[mid] <= ms) lo = mid; else hi = mid; }
            i = lo;
        }
        hint = i;
        if (cut[i + 1]) { fill(i, 0, 0, false); return; }   // hold until the cut, then snap
        double h = t[i + 1] - t[i];
        fill(i, (ms - t[i]) / h, h, true);
    }

    /**
     * Velocity per tick measured over a wider +-75 ms window (the per-segment derivative is too noisy at sprint speed).
     * Result in vel[]; cur[] is left at the camera for ms.
     */
    public void evalSmoothVelocity(double ms) {
        if (n == 0) return;
        double[] a = new double[CH], b = new double[CH];
        eval(ms - 75.0); System.arraycopy(cur, 0, a, 0, CH);
        eval(ms + 75.0); System.arraycopy(cur, 0, b, 0, CH);
        double dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
        boolean jump = dx * dx + dy * dy + dz * dz > 16.0 * 16.0;   // a cut inside the window: no meaningful velocity
        eval(ms);
        double k = 50.0 / 150.0;
        for (int c = 0; c < CH; c++) vel[c] = jump ? 0 : (b[c] - a[c]) * k;
    }

    private void fill(int i, double u, double h, boolean seg) {
        if (!seg) {
            for (int c = 0; c < CH; c++) { cur[c] = v[c][i]; vel[c] = 0; }
            return;
        }
        double u2 = u * u, u3 = u2 * u;
        double h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
        double g00 = 6 * u2 - 6 * u, g10 = 3 * u2 - 4 * u + 1, g01 = -6 * u2 + 6 * u, g11 = 3 * u2 - 2 * u;
        for (int c = 0; c < CH; c++) {
            double p0 = v[c][i], p1 = v[c][i + 1], m0 = m[c][i], m1 = m[c][i + 1];
            cur[c] = h00 * p0 + h10 * h * m0 + h01 * p1 + h11 * h * m1;
            double d = (g00 * p0 + g10 * h * m0 + g01 * p1 + g11 * h * m1) / h;   // per ms
            vel[c] = d * 50.0;                                                     // per tick
        }
    }
}
