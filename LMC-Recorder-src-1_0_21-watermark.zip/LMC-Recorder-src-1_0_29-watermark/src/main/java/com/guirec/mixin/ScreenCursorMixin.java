package com.guirec.mixin;

import com.guirec.CursorStyle;
import com.guirec.FarChunks;
import com.guirec.ReplayEditorScreen;
import com.guirec.ReplayPlayer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the recorded mouse cursor on top of every screen while a replay plays. */
@Mixin(Screen.class)
public class ScreenCursorMixin {
    @Inject(method = "extractRenderStateWithTooltipAndSubtitles", at = @At("TAIL"), require = 0)
    private void guirec$cursor(GuiGraphicsExtractor g, int mx, int my, float delta, CallbackInfo ci) {
        if (!ReplayPlayer.isPlaying()) return;
        float fx = 0f, fy = 0f;
        if ((Object) this instanceof ReplayEditorScreen) {
            // v1.0.24: in the editor YOUR mouse controls the timeline; the replay's own recorded cursor is drawn separately
            // (at its recorded position, not at your mouse) and only while the recorded video had a screen open.
            if (!ReplayPlayer.ghostOn) return;
            mx = (int) Math.floor(ReplayPlayer.ghostX); my = (int) Math.floor(ReplayPlayer.ghostY);
            fx = (float) (ReplayPlayer.ghostX - mx); fy = (float) (ReplayPlayer.ghostY - my);
        } else {
            // sub-pixel position: mx / my are whole GUI units, so at high GUI scales the arrow would hop in steps even though the
            // cursor itself now moves smoothly. Shift by the fractional part of the real position.
            var mc = net.minecraft.client.Minecraft.getInstance();
            fx = (float) (mc.mouseHandler.getScaledXPos(mc.getWindow()) - mx); fy = (float) (mc.mouseHandler.getScaledYPos(mc.getWindow()) - my);
            if (!(fx >= -1f && fx <= 1f)) fx = 0f;
            if (!(fy >= -1f && fy <= 1f)) fy = 0f;
        }
        float k = FarChunks.cursorSize / 8f;                 // 8 = default arrow height, set with the "Cursor size" slider
        g.pose().pushMatrix();
        g.pose().translate(mx + fx, my + fy);
        g.pose().scale(k, k);
        if (!CursorStyle.draw(g)) {                          // v1.0.27: sword / pickaxe / custom pixel cursor; false = the old arrow
            for (int r = 0; r < 8; r++) {                        // black arrow outline
                int w = Math.min(r + 2, 6);
                g.fill(0, r, w, r + 1, 0xFF000000);
            }
            for (int r = 1; r < 7; r++) {                        // white inside
                int w = Math.min(r + 1, 5);
                g.fill(1, r, w, r + 1, 0xFFFFFFFF);
            }
        }
        g.pose().popMatrix();
    }
}
