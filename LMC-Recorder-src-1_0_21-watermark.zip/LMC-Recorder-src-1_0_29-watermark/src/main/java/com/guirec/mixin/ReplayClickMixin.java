package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Replay: use the raw recorded aim of the click moment for the block / entity the click acts on (no ghost block on a neighbour). */
@Mixin(Minecraft.class)
public class ReplayClickMixin {
    @Inject(method = "startUseItem()V", at = @At("HEAD"), require = 0)
    private void guirec$useAim(CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) ReplayPlayer.repickAtClick((Minecraft) (Object) this);
    }

    @Inject(method = "startAttack()Z", at = @At("HEAD"), require = 0)
    private void guirec$attackAim(CallbackInfoReturnable<Boolean> cir) {
        if (ReplayPlayer.isPlaying()) ReplayPlayer.repickAtClick((Minecraft) (Object) this);
    }
}
