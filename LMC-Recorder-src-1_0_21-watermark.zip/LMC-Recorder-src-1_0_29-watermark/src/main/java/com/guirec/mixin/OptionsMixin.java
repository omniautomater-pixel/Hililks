package com.guirec.mixin;

import com.guirec.FarChunks;
import net.minecraft.client.Options;
import net.minecraft.server.level.ClientInformation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Far record: tell the server we want "view" chunks (slider in the F8 menu), whatever the local render distance is. */
@Mixin(Options.class)
public class OptionsMixin {
    @Inject(method = "buildPlayerInformation", at = @At("RETURN"), cancellable = true)
    private void guirec$farView(CallbackInfoReturnable<ClientInformation> cir) {
        if (!FarChunks.wantFar()) return;
        ClientInformation i = cir.getReturnValue();
        if (i.viewDistance() == FarChunks.view()) return;
        cir.setReturnValue(new ClientInformation(i.language(), FarChunks.view(), i.chatVisibility(), i.chatColors(),
                i.modelCustomisation(), i.mainHand(), i.textFilteringEnabled(), i.allowsListing(), i.particleStatus()));
    }

    /** Vanilla render distance slider ends at 32 (64-bit Java). The constant 32 between the renderDistance and simulationDistance options in Options.<init> is that slider's max: make it 64. */
    @ModifyConstant(method = "<init>", constant = @Constant(intValue = 32),
            slice = @Slice(from = @At(value = "CONSTANT", args = "stringValue=options.renderDistance"),
                           to = @At(value = "CONSTANT", args = "stringValue=options.simulationDistance")))
    private int guirec$maxRenderDistance(int vanilla) { return FarChunks.MAX_CHUNKS; }
}
