package com.guirec.mixin;

import com.guirec.FarChunks;
import net.minecraft.client.server.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Far record in singleplayer: the internal server only sends chunks up to max(2, your render distance).
 * With "Sent 64 / Loaded 2" the server stopped at your (small) render distance, so the recording / preview held only
 * a few chunks. Raise the server's view distance to the "Sent" value while recording.
 */
@Mixin(IntegratedServer.class)
public class IntegratedServerMixin {
    @Redirect(method = "tickServer", at = @At(value = "INVOKE", target = "Ljava/lang/Math;max(II)I", ordinal = 0), require = 0)
    private int guirec$serverView(int a, int b) {
        int v = Math.max(a, b);
        if (FarChunks.wantFar()) v = Math.max(v, FarChunks.view());
        return v;
    }
}
