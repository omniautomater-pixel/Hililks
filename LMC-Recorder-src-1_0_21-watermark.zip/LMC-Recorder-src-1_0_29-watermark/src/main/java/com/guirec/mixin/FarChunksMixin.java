package com.guirec.mixin;

import com.guirec.FarChunks;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundForgetLevelChunkPacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Far record: far-away chunk packets are NOT handed to the game while recording (they are already saved in the file
 * by PacketDecoderMixin). Does nothing unless FarChunks is enabled and a recording is running.
 */
@Mixin(ClientPacketListener.class)
public class FarChunksMixin {
    @Inject(method = "handleLevelChunkWithLight", at = @At("HEAD"), cancellable = true)
    private void guirec$chunk(ClientboundLevelChunkWithLightPacket p, CallbackInfo ci) {
        FarChunks.count(p);
        if (FarChunks.hold(p)) ci.cancel();
    }

    @Inject(method = "handleLightUpdatePacket", at = @At("HEAD"), cancellable = true)
    private void guirec$light(ClientboundLightUpdatePacket p, CallbackInfo ci) {
        if (FarChunks.light(p)) ci.cancel();
    }

    @Inject(method = "handleBlockUpdate", at = @At("HEAD"), cancellable = true)
    private void guirec$block(ClientboundBlockUpdatePacket p, CallbackInfo ci) {
        if (FarChunks.block(p)) ci.cancel();
    }

    @Inject(method = "handleChunkBlocksUpdate", at = @At("HEAD"), cancellable = true)
    private void guirec$section(ClientboundSectionBlocksUpdatePacket p, CallbackInfo ci) {
        if (FarChunks.section(p)) ci.cancel();
    }

    @Inject(method = "handleBlockEntityData", at = @At("HEAD"), cancellable = true)
    private void guirec$blockEntity(ClientboundBlockEntityDataPacket p, CallbackInfo ci) {
        if (FarChunks.blockEntity(p)) ci.cancel();
    }

    @Inject(method = "handleForgetLevelChunk", at = @At("HEAD"), cancellable = true)
    private void guirec$forget(ClientboundForgetLevelChunkPacket p, CallbackInfo ci) {
        if (FarChunks.forget(p)) ci.cancel();
    }
}
