package com.guirec;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * v1.0.27: the replay's mouse cursor can now be an item (sword / pickaxe) or your own 16x16 pixel art.
 * - ids: "arrow" (the old built-in arrow), the presets below, and "custom" (what you drew in the cursor editor).
 * - The picture is a 16x16 grid of ARGB ints (0 = transparent) plus a hot spot (the pixel that points at what you click).
 * - Saved in .minecraft/guirec/cursor.properties. The size slider (FarChunks.cursorSize) still scales it: 8 = 1 GUI px per art pixel.
 * The presets are drawn from text templates below (original pixel art, no game textures are copied).
 */
public final class CursorStyle {
    public static final int N = 16;
    public static final String ARROW = "arrow", CUSTOM = "custom";

    public static final class Preset {
        public final String id, name; public final int[] px; public final int hx, hy;
        Preset(String id, String name, int[] px, int hx, int hy) { this.id = id; this.name = name; this.px = px; this.hx = hx; this.hy = hy; }
    }

    // ---- text templates: '.' clear, 'O' outline, 'a' light, 'b' mid, 'c' dark (metal), 'h' handle, 'd' handle dark
    private static final String[] SWORD = {
            ".O..............",
            "OaOO............",
            ".ObaO...........",
            ".OcbaO..........",
            "..OcbaO.........",
            "...OcbaO........",
            "....OcbaO....O..",
            ".....OcbaO..OdO.",
            "......OcbaOOhO..",
            ".......OcbahO...",
            "........OOhO....",
            "........OhOhO...",
            ".......OhO.OhO..",
            "......OdO...OdO.",
            ".......O.....OdO",
            "..............O."
    };
    private static final String[] PICK = {
            "................",
            "......OOOO......",
            ".....OaabbO.....",
            "....OabbbcO.....",
            "...OabbcOO......",
            "..OabccO........",
            ".OabbchO........",
            ".OabcOOhO.......",
            ".ObbO..OhO......",
            ".ObcO...OhO.....",
            "..OO.....OhO....",
            "..........OhO...",
            "...........OhO..",
            "............OdO.",
            ".............OdO",
            "..............O."
    };
    private static final int OUT = 0xFF120E16, HANDLE = 0xFF9A6E3B, HANDLE_D = 0xFF5E4124;
    private static final int[] DIAMOND   = { 0xFF9BFAEF, 0xFF2FD0C0, 0xFF1B8A95 };
    private static final int[] NETHERITE = { 0xFF6B626E, 0xFF4A424D, 0xFF2E2831 };
    private static final int[] GOLD      = { 0xFFFFF38A, 0xFFF2C62F, 0xFFB8821B };
    private static final int[] IRON      = { 0xFFF0F0F0, 0xFFBEBEBE, 0xFF7E7E7E };

    private static int[] build(String[] rows, int[] metal) {
        int[] o = new int[N * N];
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            char ch = rows[r].charAt(c);
            int v = 0;
            switch (ch) {
                case 'O': v = OUT; break;
                case 'a': v = metal[0]; break;
                case 'b': v = metal[1]; break;
                case 'c': v = metal[2]; break;
                case 'h': v = HANDLE; break;
                case 'd': v = HANDLE_D; break;
                default: v = 0;
            }
            o[r * N + c] = v;
        }
        return o;
    }

    /** The old built-in arrow as 16x16 art (so it can be loaded into the editor and changed). */
    private static int[] arrowPixels() {
        int[] o = new int[N * N];
        for (int r = 0; r < 8; r++) { int w = Math.min(r + 2, 6); for (int x = 0; x < w; x++) o[r * N + x] = 0xFF000000; }
        for (int r = 1; r < 7; r++) { int w = Math.min(r + 1, 5); for (int x = 1; x < w; x++) o[r * N + x] = 0xFFFFFFFF; }
        return o;
    }

    public static final List<Preset> PRESETS = new ArrayList<>();
    static {
        PRESETS.add(new Preset(ARROW, "Arrow", arrowPixels(), 0, 0));
        PRESETS.add(new Preset("diamond_sword", "Diamond Sword", build(SWORD, DIAMOND), 1, 1));
        PRESETS.add(new Preset("netherite_sword", "Netherite Sword", build(SWORD, NETHERITE), 1, 1));
        PRESETS.add(new Preset("golden_sword", "Golden Sword", build(SWORD, GOLD), 1, 1));
        PRESETS.add(new Preset("iron_sword", "Iron Sword", build(SWORD, IRON), 1, 1));
        PRESETS.add(new Preset("diamond_pickaxe", "Diamond Pickaxe", build(PICK, DIAMOND), 4, 4));
        PRESETS.add(new Preset("netherite_pickaxe", "Netherite Pickaxe", build(PICK, NETHERITE), 4, 4));
    }

    // ---- current state
    public static volatile String selected = ARROW;
    private static int[] custom;                 // null = nothing drawn yet
    private static int customHx, customHy;
    private static int[][] rects;                // cached horizontal runs {x, y, w, argb}; null = draw the old arrow
    private static int drawHx, drawHy;

    private static Preset preset(String id) {
        for (Preset p : PRESETS) if (p.id.equals(id)) return p;
        return null;
    }

    public static boolean hasCustom() { return custom != null; }

    /** Names for the menu button. */
    public static String label(String id) {
        if (CUSTOM.equals(id)) return "Custom";
        Preset p = preset(id);
        return p == null ? "Arrow" : p.name;
    }

    /** Ids that can be loaded as a starting point in the editor (arrow + presets). */
    public static List<String> templateIds() {
        List<String> l = new ArrayList<>();
        for (Preset p : PRESETS) l.add(p.id);
        return l;
    }

    /** Ids the menu button cycles through: arrow, presets, and "custom" once you have drawn one. */
    public static List<String> cycleIds() {
        List<String> l = templateIds();
        if (custom != null) l.add(CUSTOM);
        return l;
    }

    public static int[] pixelsOf(String id) {
        if (CUSTOM.equals(id) && custom != null) return custom.clone();
        Preset p = preset(id);
        return (p == null ? PRESETS.get(0) : p).px.clone();
    }
    public static int hotXOf(String id) {
        if (CUSTOM.equals(id) && custom != null) return customHx;
        Preset p = preset(id); return p == null ? 0 : p.hx;
    }
    public static int hotYOf(String id) {
        if (CUSTOM.equals(id) && custom != null) return customHy;
        Preset p = preset(id); return p == null ? 0 : p.hy;
    }

    public static void select(String id) {
        if (CUSTOM.equals(id) && custom == null) id = ARROW;
        if (preset(id) == null && !CUSTOM.equals(id)) id = ARROW;
        selected = id;
        rebuild();
        save();
    }

    public static void cycle() {
        List<String> ids = cycleIds();
        int i = ids.indexOf(selected);
        select(ids.get((i + 1) % ids.size()));
    }

    /** Called by the cursor editor: your pixel art becomes the "custom" cursor and is selected. */
    public static void saveCustom(int[] px, int hx, int hy) {
        custom = px.clone();
        customHx = Math.max(0, Math.min(N - 1, hx));
        customHy = Math.max(0, Math.min(N - 1, hy));
        selected = CUSTOM;
        rebuild();
        save();
    }

    // ---- drawing
    private static void rebuild() {
        int[] px; int hx, hy;
        if (ARROW.equals(selected)) { rects = null; return; }
        if (CUSTOM.equals(selected) && custom != null) { px = custom; hx = customHx; hy = customHy; }
        else {
            Preset p = preset(selected);
            if (p == null) { rects = null; return; }
            px = p.px; hx = p.hx; hy = p.hy;
        }
        List<int[]> out = new ArrayList<>();
        for (int r = 0; r < N; r++) {
            int c = 0;
            while (c < N) {
                int col = px[r * N + c];
                if ((col >>> 24) == 0) { c++; continue; }
                int e = c + 1;
                while (e < N && px[r * N + e] == col) e++;
                out.add(new int[] { c, r, e - c, col });
                c = e;
            }
        }
        rects = out.toArray(new int[0][]);
        drawHx = hx; drawHy = hy;
    }

    /**
     * Draws the picture with its hot spot at (0,0) of the current matrix; the caller has already translated to the mouse position and
     * scaled by size/8. Returns false when the old built-in arrow should be drawn instead.
     */
    public static boolean draw(GuiGraphicsExtractor g) {
        int[][] rs = rects;
        if (rs == null) return false;
        for (int[] q : rs) g.fill(q[0] - drawHx, q[1] - drawHy, q[0] - drawHx + q[2], q[1] - drawHy + 1, q[3]);
        return true;
    }

    // ---- saving (.minecraft/guirec/cursor.properties)
    private static Path cfg() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("cursor.properties"); }

    public static void save() {
        try {
            Path p = cfg();
            Files.createDirectories(p.getParent());
            Properties pr = new Properties();
            pr.setProperty("style", selected);
            if (custom != null) {
                StringBuilder sb = new StringBuilder();
                for (int v : custom) sb.append(String.format("%08x", v));
                pr.setProperty("custom", sb.toString());
                pr.setProperty("hot", customHx + "," + customHy);
            }
            try (OutputStream o = Files.newOutputStream(p)) { pr.store(o, "LMC Recorder cursor"); }
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            Path p = cfg();
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (InputStream i = Files.newInputStream(p)) { pr.load(i); }
                String cs = pr.getProperty("custom", "").trim();
                if (cs.length() == N * N * 8) {
                    int[] px = new int[N * N];
                    for (int k = 0; k < px.length; k++) px[k] = (int) Long.parseLong(cs.substring(k * 8, k * 8 + 8), 16);
                    custom = px;
                    String[] h = pr.getProperty("hot", "0,0").split(",");
                    customHx = Math.max(0, Math.min(N - 1, Integer.parseInt(h[0].trim())));
                    customHy = Math.max(0, Math.min(N - 1, Integer.parseInt(h[1].trim())));
                }
                selected = pr.getProperty("style", ARROW).trim();
                if (CUSTOM.equals(selected) && custom == null) selected = ARROW;
                if (!CUSTOM.equals(selected) && preset(selected) == null) selected = ARROW;
            }
        } catch (Exception ignored) { selected = ARROW; }
        rebuild();
    }

    private CursorStyle() {}
}
