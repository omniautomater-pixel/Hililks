package com.guirec;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * Replay editor. Opens with F8 while a replay plays in edit mode (and when the replay is started with "Edit").
 * The replay is PAUSED while this screen is open. Click / drag the timeline to jump, Play continues from there.
 */
public class ReplayEditorScreen extends Screen {
    private final Screen prev;
    private boolean dragging;
    private int dragMs;
    private int barX, barY, barW;
    private static final int BAR_H = 14;

    public ReplayEditorScreen(Screen prev) {
        super(Component.literal("Replay editor"));
        this.prev = prev instanceof ReplayEditorScreen ? null : prev;
    }

    private int cur() { return dragging ? dragMs : ReplayPlayer.timeMs(); }

    private void jump(int deltaMs) { ReplayPlayer.seekTo(Math.max(0, Math.min(ReplayEditor.total, cur() + deltaMs))); }

    @Override
    protected void init() {
        ReplayPlayer.setPaused(true);
        ReplayEditor.wantEditor = true;
        barX = 20; barW = this.width - 40; barY = this.height - 72;

        int bw = 52, gap = 4, y1 = this.height - 50;
        int x = this.width / 2 - (5 * bw + 4 * gap) / 2;
        addRenderableWidget(Button.builder(Component.literal("-10s"), b -> jump(-10000)).bounds(x, y1, bw, 20).build()); x += bw + gap;
        addRenderableWidget(Button.builder(Component.literal("-1s"), b -> jump(-1000)).bounds(x, y1, bw, 20).build()); x += bw + gap;
        addRenderableWidget(Button.builder(Component.literal("Play"), b -> resume()).bounds(x, y1, bw, 20).build()); x += bw + gap;
        addRenderableWidget(Button.builder(Component.literal("+1s"), b -> jump(1000)).bounds(x, y1, bw, 20).build()); x += bw + gap;
        addRenderableWidget(Button.builder(Component.literal("+10s"), b -> jump(10000)).bounds(x, y1, bw, 20).build());

        int n = 6, w2 = Math.max(40, Math.min(64, (this.width - 40 - (n - 1) * gap) / n));
        int y2 = this.height - 26;
        x = this.width / 2 - (n * w2 + (n - 1) * gap) / 2;
        addRenderableWidget(Button.builder(Component.literal("Set A"), b -> ReplayEditor.markA = cur()).bounds(x, y2, w2, 20).build()); x += w2 + gap;
        addRenderableWidget(Button.builder(Component.literal("Set B"), b -> ReplayEditor.markB = cur()).bounds(x, y2, w2, 20).build()); x += w2 + gap;
        addRenderableWidget(Button.builder(Component.literal("Delete"), b -> {
            if (ReplayEditor.markA < 0 || ReplayEditor.markB < 0) ReplayEditor.msg = "Set A and Set B first (the part between them is deleted)";
            else ReplayEditor.addDelete(ReplayEditor.markA, ReplayEditor.markB);
        }).bounds(x, y2, w2, 20).build()); x += w2 + gap;
        addRenderableWidget(Button.builder(Component.literal("Split"), b -> ReplayEditor.addSplit(cur())).bounds(x, y2, w2, 20).build()); x += w2 + gap;
        addRenderableWidget(Button.builder(Component.literal("Undo"), b -> ReplayEditor.undo()).bounds(x, y2, w2, 20).build()); x += w2 + gap;
        addRenderableWidget(Button.builder(Component.literal("Save"), b -> ReplayEditor.saveAsync(this.minecraft)).bounds(x, y2, w2, 20).build());
    }

    /** Continue the replay from the current position and close the editor. */
    private void resume() {
        ReplayPlayer.setPaused(false);
        ReplayEditor.wantEditor = false;
        this.minecraft.gui.setScreen(prev);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float delta) {
        // no blur / dark overlay: the replay frame behind must stay visible while you scrub. Only a strip behind the controls.
        g.fill(0, this.height - 96, this.width, this.height, 0xB0000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        int c = cur();
        ReplayEditor.drawBar(g, barX, barY, barW, BAR_H, c);
        String t = ReplayEditor.fmt(c) + " / " + ReplayEditor.fmt(ReplayEditor.total) + (ReplayPlayer.seeking() ? "   seeking..." : "");
        g.text(this.font, t, barX, barY - 14, 0xFFFFFFFF);
        String info = "A " + (ReplayEditor.markA < 0 ? "-" : ReplayEditor.fmt(ReplayEditor.markA))
                + "   B " + (ReplayEditor.markB < 0 ? "-" : ReplayEditor.fmt(ReplayEditor.markB))
                + "   deleted " + ReplayEditor.deleted().size() + "   splits " + ReplayEditor.splits().size();
        g.text(this.font, info, barX + barW - this.font.width(info), barY - 14, 0xFFAAAAAA);
        if (!ReplayEditor.msg.isEmpty())
            g.text(this.font, ReplayEditor.msg, this.width / 2 - this.font.width(ReplayEditor.msg) / 2, this.height - 98 - 10, 0xFFFFDD66);
        g.text(this.font, "Replay editor  -  drag the line with your mouse to jump,  Play = continue from there", 6, 6, 0xFFFFFFFF);
    }

    private boolean onBar(double x, double y) { return x >= barX - 8 && x <= barX + barW + 8 && y >= barY - 12 && y <= barY + BAR_H + 12; }

    private int msAt(double x) {
        double r = (x - barX) / (double) barW;
        return (int) (Math.max(0, Math.min(1, r)) * ReplayEditor.total);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        if (ev.button() == 0 && onBar(ev.x(), ev.y())) { dragging = true; dragMs = msAt(ev.x()); return true; }
        return super.mouseClicked(ev, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent ev, double dx, double dy) {
        if (dragging) { dragMs = msAt(ev.x()); return true; }
        return super.mouseDragged(ev, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent ev) {
        if (dragging && ev.button() == 0) {
            dragging = false;
            ReplayPlayer.seekTo(msAt(ev.x()));     // seek once, on release (jumping back re-loads the world, so not on every pixel)
            return true;
        }
        return super.mouseReleased(ev);
    }

    @Override
    public boolean keyPressed(KeyEvent ev) {
        int k = ev.key();
        if (k == InputConstants.KEY_ESCAPE || k == InputConstants.KEY_F8 || k == InputConstants.KEY_SPACE) { resume(); return true; }
        if (k == InputConstants.KEY_F7) { ReplayPlayer.stop(this.minecraft); return true; }
        if (k == InputConstants.KEY_LEFT) { jump(-1000); return true; }
        if (k == InputConstants.KEY_RIGHT) { jump(1000); return true; }
        return super.keyPressed(ev);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean isPauseScreen() { return false; }
}
