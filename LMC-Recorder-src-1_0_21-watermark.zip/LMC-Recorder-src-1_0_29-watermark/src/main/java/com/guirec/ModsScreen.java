package com.guirec;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModOrigin;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.*;
import java.util.*;

/**
 * Turn mods off / on for a clean export (fps-boost mods that lower the picture quality).
 * A loaded mod can NOT be unloaded while the game runs (its classes + mixins are already in the JVM), so this renames the jar
 * (x.jar <-> x.jar.disabled) and the change applies the next time the game starts: use "Quit game", start it again, export,
 * come back here, "Enable all", quit and start again.
 *
 * v1.0.21: the list now shows EVERY loaded mod jar (wherever it lives: mods/, mods/<version>/ subfolders, a launcher-provided folder),
 * plus every x.jar.disabled in mods/ (two levels deep). Before, only the top level of mods/ was scanned and the page buttons could sit
 * under the bottom buttons on a small phone screen, so some mods (e.g. Replay Mod) looked "missing". The page size now follows the screen height.
 */
public class ModsScreen extends Screen {
    private final Screen parent;
    private int page;
    private String msg = "";
    private boolean quitArmed = false;
    private final Path modsDir = FabricLoader.getInstance().getGameDir().resolve("mods");

    private record Entry(Path file, String name, boolean enabled) {}

    public ModsScreen(Screen parent) {
        super(Component.literal("Mods for export"));
        this.parent = parent;
    }

    private static Path norm(Path p) { return p.toAbsolutePath().normalize(); }

    private List<Entry> entries() {
        Map<Path, Entry> found = new LinkedHashMap<>();
        Set<Path> protectedJars = new HashSet<>();
        // 1) every loaded mod that comes from a real .jar file, wherever that file is
        try {
            for (ModContainer m : FabricLoader.getInstance().getAllMods()) {
                if (m.getOrigin().getKind() != ModOrigin.Kind.PATH) continue;
                String id = m.getMetadata().getId();
                for (Path p : m.getOrigin().getPaths()) {
                    Path n = norm(p);
                    String f = n.getFileName() == null ? "" : n.getFileName().toString();
                    if (id.equals("guirec") || id.equals("fabric-api") || id.equals("fabricloader")) { protectedJars.add(n); continue; }
                    if (id.equals("minecraft") || id.equals("java")) continue;
                    if (!f.endsWith(".jar") || !Files.isRegularFile(n)) continue;
                    found.putIfAbsent(n, new Entry(n, m.getMetadata().getName(), true));
                }
            }
        } catch (Throwable ignored) {}
        // 2) every jar / disabled jar in mods/ (also the version subfolders such as mods/26.1/)
        try (var s = Files.walk(modsDir, 2)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                String f = p.getFileName().toString();
                boolean on = f.endsWith(".jar"), off = f.endsWith(".jar.disabled");
                if (!on && !off) return;
                Path n = norm(p);
                if (protectedJars.contains(n) || found.containsKey(n)) return;
                found.put(n, new Entry(p, f.replace(".disabled", ""), on));
            });
        } catch (Throwable t) { msg = "Cannot read the mods folder: " + t; }
        List<Entry> out = new ArrayList<>(found.values());
        out.sort(Comparator.comparing((Entry e) -> e.name().toLowerCase(Locale.ROOT)));
        return out;
    }

    private boolean toggle(Entry e) {
        try {
            String f = e.file().getFileName().toString();
            Path to = e.enabled() ? e.file().resolveSibling(f + ".disabled") : e.file().resolveSibling(f.substring(0, f.length() - ".disabled".length()));
            Files.move(e.file(), to);
            msg = "Done. Quit the game and start it again to apply.";
            return true;
        } catch (Throwable t) {
            msg = "Could not rename (locked by the game?): " + t.getClass().getSimpleName() + " - quit the game and rename the jar by hand";
            return false;
        }
    }

    private int perPage() { return Math.max(1, (this.height - 32 - 84) / 24); }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = 32;
        List<Entry> all = entries();
        int per = perPage();
        int pages = Math.max(1, (all.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (Entry e : all.subList(page * per, Math.min(all.size(), (page + 1) * per))) {
            String label = (e.enabled() ? "ON   " : "OFF  ") + e.name();
            addRenderableWidget(Button.builder(Component.literal(label), b -> { toggle(e); quitArmed = false; this.rebuildWidgets(); })
                    .bounds(cx, y, 240, 20).build());
            y += 24;
        }
        // bottom block (fixed rows, never overlapping the list): pager / enable all + quit / back
        int rowA = this.height - 76, rowB = this.height - 52, rowC = this.height - 28;
        addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> { page--; this.rebuildWidgets(); })
                .bounds(cx, rowA, 76, 20).build()).active = page > 0;
        addRenderableWidget(Button.builder(Component.literal("Next >"), b -> { page++; this.rebuildWidgets(); })
                .bounds(cx + 164, rowA, 76, 20).build()).active = page < pages - 1;
        addRenderableWidget(Button.builder(Component.literal("Enable all"), b -> {
            for (Entry e : entries()) if (!e.enabled()) toggle(e);
            quitArmed = false;
            this.rebuildWidgets();
        }).bounds(cx, rowB, 118, 20).build());
        addRenderableWidget(Button.builder(Component.literal(quitArmed ? "Click again: QUIT" : "Quit game"), b -> {
            if (!quitArmed) { quitArmed = true; msg = "Quit the game now so the changes apply?"; this.rebuildWidgets(); }
            else this.minecraft.stop();
        }).bounds(cx + 122, rowB, 118, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(cx, rowC, 240, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), 8, 0xFFFFFFFF);
        if (!msg.isEmpty()) line(g, msg, 20, 0xFFFFDD66);
        else line(g, "Click a mod to switch it off / on. Applies after a game restart.", 20, 0xFFAAAAAA);
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void onClose() { this.minecraft.gui.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
