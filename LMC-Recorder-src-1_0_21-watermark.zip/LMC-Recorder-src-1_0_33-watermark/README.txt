

SEARCH EVERY MINECRAFT ITEM AS A CURSOR (v1.0.33)
Cursor editor -> "Search items..." (under the name box): a picture grid of EVERY item of the game (button "Items") or every block
("Blocks"), read from the running game's resources (a resource pack changes them too; nothing is stored in the mod). Type words of the name
in the search box ("diamond pick", "apple", "torch"); the number of matches is shown. Tap a picture = select (its name is shown below),
tap it again or press "Use" = it is loaded into the editor, where you can still change it, move the red box (click point) and save it with a
name. Pages: "<" ">" or the mouse wheel. The click point starts at the tip (the pixel nearest to the top-right corner).
