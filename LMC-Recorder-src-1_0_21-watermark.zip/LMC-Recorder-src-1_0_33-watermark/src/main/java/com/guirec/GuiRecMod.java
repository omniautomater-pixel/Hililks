package com.guirec;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;

public class GuiRecMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FarChunks.init();
        CursorStyle.load();   // v1.0.27: saved cursor choice / your pixel cursor
        CustomSkins.init();   // makes .minecraft/guirec/skins and reads the saved skin / cape choice
        KeyMapping menu = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.guirec.menu", InputConstants.Type.KEYBOARD, InputConstants.KEY_F8, KeyMapping.Category.MISC));
        KeyMapping leave = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.guirec.leave", InputConstants.Type.KEYBOARD, InputConstants.KEY_F7, KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ReplayPlayer.onTick(mc);
            ReplayExport.onTick(mc);
            while (menu.consumeClick()) {
                boolean byUser = ReplayPlayer.takeUserF8();
                if (ReplayPlayer.isPlaying() && ReplayEditor.active) { if (!(mc.gui.screen() instanceof ReplayEditorScreen)) mc.gui.setScreen(new ReplayEditorScreen(mc.gui.screen())); }
                else {
                    // v1.0.32: opened by your own F8 during a replay = your real mouse (replay paused); opened by the recorded F8 = replay-driven
                    if (ReplayPlayer.isPlaying()) ReplayPlayer.userUi = byUser;
                    mc.gui.setScreen(new RecorderScreen(mc.gui.screen()));
                }
            }
            while (leave.consumeClick()) ReplayPlayer.stop(mc);
        });
    }
}
