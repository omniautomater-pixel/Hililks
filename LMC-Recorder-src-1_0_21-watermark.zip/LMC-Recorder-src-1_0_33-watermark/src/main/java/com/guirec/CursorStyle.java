package com.guirec;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * v1.0.27: the replay's mouse cursor can now be an item (sword / pickaxe) or your own 16x16 pixel art.
 * - ids: "arrow" (the old built-in arrow), the presets below, and "my:<name>" (cursors you drew and SAVED under a name in the cursor editor).
 * v1.0.30: you can save as many named cursors as you like (.minecraft/guirec/cursors/<name>.properties), load one back into the
 *          editor, change it and save it again (same name = overwrite, new name = a new cursor).
 * - The picture is a 16x16 grid of ARGB ints (0 = transparent) plus a hot spot (the pixel that points at what you click).
 * - Saved in .minecraft/guirec/cursor.properties. The size slider (FarChunks.cursorSize) still scales it: 8 = 1 GUI px per art pixel.
 * The presets are drawn from text templates below (original pixel art, no game textures are copied).
 */
public final class CursorStyle {
    public static final int N = 16;
    public static final String ARROW = "arrow", MY = "my:";

    public static final class Preset {
        public final String id, name; public int[] px; public int hx, hy;
        Preset(String id, String name, int[] px, int hx, int hy) { this.id = id; this.name = name; this.px = px; this.hx = hx; this.hy = hy; }
    }

    // ---- text templates: '.' clear, 'O' outline, 'a' light, 'b' mid, 'c' dark (metal), 'h' handle, 'd' handle dark
    private static final String[] SWORD = {
            ".O..............",
            "OaOO............",
            ".ObaO...........",
            ".OcbaO..........",
            "..OcbaO.........",
            "...OcbaO........",
            "....OcbaO....O..",
            ".....OcbaO..OdO.",
            "......OcbaOOhO..",
            ".......OcbahO...",
            "........OOhO....",
            "........OhOhO...",
            ".......OhO.OhO..",
            "......OdO...OdO.",
            ".......O.....OdO",
            "..............O."
    };
    private static final String[] PICK = {
            "................",
            "......OOOO......",
            ".....OaabbO.....",
            "....OabbbcO.....",
            "...OabbcOO......",
            "..OabccO........",
            ".OabbchO........",
            ".OabcOOhO.......",
            ".ObbO..OhO......",
            ".ObcO...OhO.....",
            "..OO.....OhO....",
            "..........OhO...",
            "...........OhO..",
            "............OdO.",
            ".............OdO",
            "..............O."
    };
    private static final int OUT = 0xFF120E16, HANDLE = 0xFF9A6E3B, HANDLE_D = 0xFF5E4124;
    private static final int[] DIAMOND   = { 0xFF9BFAEF, 0xFF2FD0C0, 0xFF1B8A95 };
    private static final int[] NETHERITE = { 0xFF6B626E, 0xFF4A424D, 0xFF2E2831 };
    private static final int[] GOLD      = { 0xFFFFF38A, 0xFFF2C62F, 0xFFB8821B };
    private static final int[] IRON      = { 0xFFF0F0F0, 0xFFBEBEBE, 0xFF7E7E7E };
    private static final int[] WOOD      = { 0xFFC69A5A, 0xFF9A6E3B, 0xFF5E4124 };
    private static final int[] STONE     = { 0xFFBEBEBE, 0xFF8A8A8A, 0xFF5A5A5A };
    private static final int[] COPPER    = { 0xFFF2A07B, 0xFFC4683F, 0xFF8A3E22 };

    private static int[] build(String[] rows, int[] metal) {
        int[] o = new int[N * N];
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            char ch = rows[r].charAt(c);
            int v = 0;
            switch (ch) {
                case 'O': v = OUT; break;
                case 'a': v = metal[0]; break;
                case 'b': v = metal[1]; break;
                case 'c': v = metal[2]; break;
                case 'h': v = HANDLE; break;
                case 'd': v = HANDLE_D; break;
                default: v = 0;
            }
            o[r * N + c] = v;
        }
        return o;
    }

    /** The old built-in arrow as 16x16 art (so it can be loaded into the editor and changed). */
    private static int[] arrowPixels() {
        int[] o = new int[N * N];
        for (int r = 0; r < 8; r++) { int w = Math.min(r + 2, 6); for (int x = 0; x < w; x++) o[r * N + x] = 0xFF000000; }
        for (int r = 1; r < 7; r++) { int w = Math.min(r + 1, 5); for (int x = 1; x < w; x++) o[r * N + x] = 0xFFFFFFFF; }
        return o;
    }

    public static final List<Preset> PRESETS = new ArrayList<>();
    static {
        PRESETS.add(new Preset(ARROW, "Arrow", arrowPixels(), 0, 0));
        // v1.0.32: the swords / pickaxes are the REAL Minecraft item pictures (textures/item/<id>.png of the running game, so a resource pack
        // changes them too; nothing is copied into the mod). The hand-drawn art below is only the fallback if a texture cannot be read.
        String[][] mats = { {"wooden", "Wooden"}, {"stone", "Stone"}, {"copper", "Copper"}, {"iron", "Iron"}, {"golden", "Golden"}, {"diamond", "Diamond"}, {"netherite", "Netherite"} };
        int[][] fall = { WOOD, STONE, COPPER, IRON, GOLD, DIAMOND, NETHERITE };
        for (int k = 0; k < mats.length; k++) PRESETS.add(new Preset(mats[k][0] + "_sword", mats[k][1] + " Sword", build(SWORD, fall[k]), 1, 1));
        for (int k = 0; k < mats.length; k++) PRESETS.add(new Preset(mats[k][0] + "_pickaxe", mats[k][1] + " Pickaxe", build(PICK, fall[k]), 4, 4));
    }

    // ---- current state
    public static volatile String selected = ARROW;
    /** A cursor you drew and saved under a name. */
    public static final class Saved {
        public final int[] px; public final int hx, hy;
        Saved(int[] px, int hx, int hy) { this.px = px; this.hx = hx; this.hy = hy; }
    }
    private static final java.util.LinkedHashMap<String, Saved> saved = new java.util.LinkedHashMap<>();   // name -> art
    private static int[][] rects;                // cached horizontal runs {x, y, w, argb}; null = draw the old arrow
    private static int drawHx, drawHy;

    private static boolean itemsLoaded;
    private static int itemTries;

    /**
     * Reads the real item pictures from the game's resources (once). The hot spot is the opaque pixel nearest to the top-right corner
     * (the tip of the sword / pickaxe). Called before the pictures are needed; harmless if the resources are not ready yet (tries again later).
     */
    private static void ensureItems() {
        if (itemsLoaded || itemTries > 40) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.getResourceManager() == null) return;
            itemTries++;
            int ok = 0;
            for (Preset p : PRESETS) {
                if (ARROW.equals(p.id)) continue;
                try {
                    var opt = mc.getResourceManager().getResource(Identifier.parse("minecraft:textures/item/" + p.id + ".png"));
                    if (opt.isEmpty()) continue;
                    NativeImage img;
                    try (InputStream in = opt.get().open()) { img = NativeImage.read(in); }
                    try {
                        int w = img.getWidth(), h = img.getHeight();
                        if (w < 1 || h < 1) continue;
                        int[] px = new int[N * N];
                        int best = Integer.MAX_VALUE, bx = 0, by = 0;
                        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
                            int v = img.getPixel(c * w / N, r * h / N);          // ARGB
                            if ((v >>> 24) < 8) continue;
                            px[r * N + c] = v;
                            int d = (N - 1 - c) + r;
                            if (d < best) { best = d; bx = c; by = r; }
                        }
                        if (best == Integer.MAX_VALUE) continue;
                        p.px = px; p.hx = bx; p.hy = by;
                        ok++;
                    } finally { img.close(); }
                } catch (Throwable ignored) {}
            }
            if (ok > 0) { itemsLoaded = true; rebuild(); }
        } catch (Throwable ignored) {}
    }

    /** v1.0.33: reads a 16x16 picture (first frame if it is an animation strip) from a PNG stream; ARGB, 0 = transparent. */
    public static int[] readPixels(InputStream in) throws Exception {
        NativeImage img = NativeImage.read(in);
        try {
            int w = img.getWidth(), h = img.getHeight();
            int f = Math.max(1, Math.min(w, h));
            int[] px = new int[N * N];
            for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
                int v = img.getPixel(Math.min(w - 1, c * f / N), Math.min(h - 1, r * f / N));
                if ((v >>> 24) >= 8) px[r * N + c] = v;
            }
            return px;
        } finally { img.close(); }
    }

    /** The click point for a picture: the opaque pixel nearest to the top-right corner (the tip of a tool). */
    public static int[] tipOf(int[] px) {
        int best = Integer.MAX_VALUE, bx = 0, by = 0;
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if ((px[r * N + c] >>> 24) == 0) continue;
            int d = (N - 1 - c) + r;
            if (d < best) { best = d; bx = c; by = r; }
        }
        return new int[] { bx, by };
    }

    private static Preset preset(String id) {
        for (Preset p : PRESETS) if (p.id.equals(id)) return p;
        return null;
    }

    public static boolean isSaved(String id) { return id != null && id.startsWith(MY) && saved.containsKey(id.substring(MY.length())); }
    public static String nameOf(String id) { return id != null && id.startsWith(MY) ? id.substring(MY.length()) : ""; }
    public static List<String> savedNames() { return new ArrayList<>(saved.keySet()); }

    /** File-safe cursor name: letters, digits, space, _ - . only; max 24 chars; empty -> "My cursor". */
    public static String sanitize(String n) {
        String t = n == null ? "" : n.trim().replaceAll("[^\\p{L}\\p{N} _.-]", "_");
        if (t.length() > 24) t = t.substring(0, 24).trim();
        while (t.startsWith(".")) t = t.substring(1);
        return t.isEmpty() ? "My cursor" : t;
    }

    /** Names for the menu button. */
    public static String label(String id) {
        if (id != null && id.startsWith(MY)) return nameOf(id);
        Preset p = preset(id);
        return p == null ? "Arrow" : p.name;
    }

    /** Ids that can be loaded as a starting point in the editor: arrow + presets + all your saved cursors. */
    public static List<String> templateIds() {
        List<String> l = new ArrayList<>();
        for (Preset p : PRESETS) l.add(p.id);
        for (String n : saved.keySet()) l.add(MY + n);
        return l;
    }

    /** Ids the menu button cycles through (same list). */
    public static List<String> cycleIds() { return templateIds(); }

    public static int[] pixelsOf(String id) {
        ensureItems();
        if (isSaved(id)) return saved.get(nameOf(id)).px.clone();
        Preset p = preset(id);
        return (p == null ? PRESETS.get(0) : p).px.clone();
    }
    public static int hotXOf(String id) {
        ensureItems();
        if (isSaved(id)) return saved.get(nameOf(id)).hx;
        Preset p = preset(id); return p == null ? 0 : p.hx;
    }
    public static int hotYOf(String id) {
        ensureItems();
        if (isSaved(id)) return saved.get(nameOf(id)).hy;
        Preset p = preset(id); return p == null ? 0 : p.hy;
    }

    public static void select(String id) {
        if (!isSaved(id) && preset(id) == null) id = ARROW;
        selected = id;
        rebuild();
        save();
    }

    public static void cycle() {
        List<String> ids = cycleIds();
        int i = ids.indexOf(selected);
        select(ids.get((i + 1) % ids.size()));
    }

    /**
     * Called by the cursor editor: saves your pixel art for good under this name (overwrites a cursor with the same name),
     * selects it and returns the final name. The file stays in .minecraft/guirec/cursors/ until you delete it.
     */
    public static String saveNamed(String name, int[] px, int hx, int hy) {
        String n = sanitize(name);
        Saved sv = new Saved(px.clone(), Math.max(0, Math.min(N - 1, hx)), Math.max(0, Math.min(N - 1, hy)));
        saved.put(n, sv);
        writeSaved(n, sv);
        selected = MY + n;
        rebuild();
        save();
        return n;
    }

    /** Deletes a saved cursor (its file too). If it was the selected one the arrow is selected. */
    public static void deleteNamed(String name) {
        if (saved.remove(name) == null) return;
        try { Files.deleteIfExists(dir().resolve(name + ".properties")); } catch (Exception ignored) {}
        if ((MY + name).equals(selected)) selected = ARROW;
        rebuild();
        save();
    }

    // ---- drawing
    private static void rebuild() {
        int[] px; int hx, hy;
        if (ARROW.equals(selected)) { rects = null; return; }
        if (isSaved(selected)) { Saved sv = saved.get(nameOf(selected)); px = sv.px; hx = sv.hx; hy = sv.hy; }
        else {
            Preset p = preset(selected);
            if (p == null) { rects = null; return; }
            px = p.px; hx = p.hx; hy = p.hy;
        }
        List<int[]> out = new ArrayList<>();
        for (int r = 0; r < N; r++) {
            int c = 0;
            while (c < N) {
                int col = px[r * N + c];
                if ((col >>> 24) == 0) { c++; continue; }
                int e = c + 1;
                while (e < N && px[r * N + e] == col) e++;
                out.add(new int[] { c, r, e - c, col });
                c = e;
            }
        }
        rects = out.toArray(new int[0][]);
        drawHx = hx; drawHy = hy;
    }

    /**
     * Draws the picture with its hot spot at (0,0) of the current matrix; the caller has already translated to the mouse position and
     * scaled by size/8. Returns false when the old built-in arrow should be drawn instead.
     */
    public static boolean draw(GuiGraphicsExtractor g) {
        if (!itemsLoaded) ensureItems();
        int[][] rs = rects;
        if (rs == null) return false;
        for (int[] q : rs) g.fill(q[0] - drawHx, q[1] - drawHy, q[0] - drawHx + q[2], q[1] - drawHy + 1, q[3]);
        return true;
    }

    // ---- saving: .minecraft/guirec/cursor.properties (which cursor is selected) + .minecraft/guirec/cursors/<name>.properties (your art)
    private static Path cfg() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("cursor.properties"); }
    private static Path dir() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("cursors"); }

    private static String hex(int[] px) {
        StringBuilder sb = new StringBuilder();
        for (int v : px) sb.append(String.format("%08x", v));
        return sb.toString();
    }

    private static int[] unhex(String cs) {
        if (cs == null || cs.trim().length() != N * N * 8) return null;
        cs = cs.trim();
        int[] px = new int[N * N];
        for (int k = 0; k < px.length; k++) px[k] = (int) Long.parseLong(cs.substring(k * 8, k * 8 + 8), 16);
        return px;
    }

    private static void writeProps(Path p, Properties pr, String comment) throws Exception {
        Files.createDirectories(p.getParent());
        Path tmp = p.resolveSibling(p.getFileName() + ".tmp");
        try (OutputStream o = Files.newOutputStream(tmp)) { pr.store(o, comment); }
        try { Files.move(tmp, p, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
        catch (Exception e) { Files.move(tmp, p, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
    }

    private static void writeSaved(String name, Saved sv) {
        try {
            Properties pr = new Properties();
            pr.setProperty("custom", hex(sv.px));
            pr.setProperty("hot", sv.hx + "," + sv.hy);
            writeProps(dir().resolve(name + ".properties"), pr, "LMC Recorder cursor: " + name);
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Properties pr = new Properties();
            pr.setProperty("style", selected);
            writeProps(cfg(), pr, "LMC Recorder cursor");
        } catch (Exception ignored) {}
    }

    public static void load() {
        saved.clear();
        try {
            // 1) every saved cursor file
            Path d = dir();
            if (Files.isDirectory(d)) try (var st = Files.list(d)) {
                List<Path> files = new ArrayList<>();
                st.filter(f -> f.getFileName().toString().endsWith(".properties")).sorted().forEach(files::add);
                for (Path f : files) {
                    try {
                        Properties pr = new Properties();
                        try (InputStream i = Files.newInputStream(f)) { pr.load(i); }
                        int[] px = unhex(pr.getProperty("custom", ""));
                        if (px == null) continue;
                        String[] h = pr.getProperty("hot", "0,0").split(",");
                        String fn = f.getFileName().toString();
                        saved.put(fn.substring(0, fn.length() - ".properties".length()), new Saved(px,
                                Math.max(0, Math.min(N - 1, Integer.parseInt(h[0].trim()))), Math.max(0, Math.min(N - 1, Integer.parseInt(h[1].trim())))));
                    } catch (Exception ignored) {}
                }
            }
            // 2) the selected style (+ the single cursor of v1.0.27-29, kept as the saved cursor "Custom")
            Path p = cfg();
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (InputStream i = Files.newInputStream(p)) { pr.load(i); }
                int[] old = unhex(pr.getProperty("custom", ""));
                if (old != null && !saved.containsKey("Custom")) {
                    String[] h = pr.getProperty("hot", "0,0").split(",");
                    Saved sv = new Saved(old, Math.max(0, Math.min(N - 1, Integer.parseInt(h[0].trim()))), Math.max(0, Math.min(N - 1, Integer.parseInt(h[1].trim()))));
                    saved.put("Custom", sv);
                    writeSaved("Custom", sv);
                }
                selected = pr.getProperty("style", ARROW).trim();
                if ("custom".equals(selected)) selected = MY + "Custom";
                if (!isSaved(selected) && preset(selected) == null) selected = ARROW;
            }
        } catch (Exception ignored) { selected = ARROW; }
        rebuild();
    }

    private CursorStyle() {}
}
