package com.guirec.mixin;

import com.guirec.ReplayExport;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Iris shader time (frameTimeCounter = grass / water / cloud animation in shader packs) is read from the REAL clock. A video export renders
 * far slower than real time, so at 120 fps everything animated by a shader ran many times too fast. During an export Iris now sees a clock
 * that advances exactly 1/fps per rendered frame (same as the game clock, see DeltaTrackerMixin). @Pseudo: ignored when Iris is not installed.
 */
@Pseudo
@Mixin(targets = {"net.irisshaders.iris.uniforms.SystemTimeUniforms$Timer", "net.coderbot.iris.uniforms.SystemTimeUniforms$Timer"}, remap = false)
public class IrisTimeMixin {
    @ModifyVariable(method = "beginFrame(J)V", at = @At("HEAD"), argsOnly = true, require = 0, remap = false)
    private long guirec$fakeShaderTime(long t) { return ReplayExport.shaderTime(t); }
}
