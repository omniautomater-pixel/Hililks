package com.guirec.mixin;

import com.guirec.ReplayExport;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** While a replay is exported to video the game clock runs on a fixed step per rendered frame (1/fps), not on real time. */
@Mixin(DeltaTracker.Timer.class)
public class DeltaTrackerMixin {
    @ModifyVariable(method = "advanceGameTime(J)I", at = @At("HEAD"), argsOnly = true, require = 0)
    private long guirec$fakeGame(long ms) { return ReplayExport.fakeMs(ms); }

    @ModifyVariable(method = "advanceRealTime(J)V", at = @At("HEAD"), argsOnly = true, require = 0)
    private long guirec$fakeReal(long ms) { return ReplayExport.fakeMs(ms); }
}
