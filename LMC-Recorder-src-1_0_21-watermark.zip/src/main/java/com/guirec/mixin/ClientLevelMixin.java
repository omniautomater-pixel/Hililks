package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The crack texture while YOU break a block is set by the client itself (not by the server): save it, replay it. */
@Mixin(ClientLevel.class)
public class ClientLevelMixin {
    @Inject(method = "destroyBlockProgress(ILnet/minecraft/core/BlockPos;I)V", at = @At("HEAD"), cancellable = true)
    private void guirec$crack(int id, BlockPos pos, int stage, CallbackInfo ci) {
        var mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.getId() != id) return;   // other players' cracks come from packets
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injectingCrack) { ci.cancel(); return; }
        ReplayRecorder.crack(pos.asLong(), stage);
    }
}
