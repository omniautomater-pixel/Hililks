package com.guirec.mixin;

import com.guirec.ReplayRecorder;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.PacketDecoder;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.PacketFlow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/** Copies the raw bytes of every clientbound packet just before Minecraft decodes it. */
@Mixin(PacketDecoder.class)
public class PacketDecoderMixin {
    @Shadow @Final private ProtocolInfo<?> protocolInfo;

    @Inject(method = "decode", at = @At("HEAD"))
    private void guirec$capture(ChannelHandlerContext ctx, ByteBuf in, List<Object> out, CallbackInfo ci) {
        if (protocolInfo.flow() != PacketFlow.CLIENTBOUND) return;
        String phase = protocolInfo.id().name();
        if (!phase.equals("CONFIGURATION") && !phase.equals("PLAY")) return;
        boolean play = phase.equals("PLAY");
        if (!ReplayRecorder.wants(!play)) return;               // not recording: no copy at all
        int len = in.readableBytes();
        byte[] rec = new byte[10 + len];                         // header space + the packet: a single copy
        in.getBytes(in.readerIndex(), rec, 10, len);
        ReplayRecorder.onPacketRec(play, rec);
    }
}
