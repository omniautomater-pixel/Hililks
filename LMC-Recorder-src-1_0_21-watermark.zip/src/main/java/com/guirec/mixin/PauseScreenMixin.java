package com.guirec.mixin;

import com.guirec.SkinScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Pause menu: "Skins" button (skin / cape menu). */
@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin extends Screen {
    protected PauseScreenMixin(Component title) { super(title); }

    @Inject(method = "init()V", at = @At("TAIL"))
    private void guirec$buttons(CallbackInfo ci) {
        this.addRenderableWidget(Button.builder(Component.literal("Skins"),
                b -> this.minecraft.setScreen(new SkinScreen(this))).bounds(this.width - 90, 6, 84, 20).build());
    }
}
