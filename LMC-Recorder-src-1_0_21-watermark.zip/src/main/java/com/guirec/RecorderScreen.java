package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.IntConsumer;

/** Vanilla-style menu: recording status + list of replays to preview. Uses Minecraft's own widgets and font. */
public class RecorderScreen extends Screen {
    private final Screen parent;
    private int page;
    private static final int PER_PAGE = 5;

    public RecorderScreen(Screen parent) {
        super(Component.literal("LMC Recorder"));
        this.parent = parent;
    }

    private List<Path> replays() {
        List<Path> out = new ArrayList<>();
        try {
            Path dir = this.minecraft.gameDirectory.toPath().resolve("guirec").resolve("replays");
            if (Files.isDirectory(dir)) try (var s = Files.list(dir)) {
                s.filter(p -> p.toString().endsWith(".guirec"))
                 .sorted(Comparator.comparingLong((Path p) -> p.toFile().lastModified()).reversed())
                 .forEach(out::add);
            }
        } catch (Exception ignored) {}
        return out;
    }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = 34;
        addRenderableWidget(Button.builder(Component.literal("Skins & capes"), b -> this.minecraft.setScreen(new SkinScreen(this))).bounds(6, 28, 130, 20).build());
        addRenderableWidget(new ExportScreen.EntitySlider(6, 6, 130));   // far entities (1.0 off .. 5.0), used by Play / Edit / Export
        addRenderableWidget(Button.builder(autoLabel(), b -> {
            ReplayRecorder.autoRecord = !ReplayRecorder.autoRecord;
            b.setMessage(autoLabel());
        }).bounds(cx, y, 240, 20).build());
        y += 28;
        addRenderableWidget(Button.builder(farLabel(), b -> {
            FarChunks.setEnabled(!FarChunks.isEnabled());
            b.setMessage(farLabel());
        }).bounds(cx, y, 240, 20).build());
        y += 28;
        addRenderableWidget(new ChunkSlider(cx, y, 118, "Sent", FarChunks.view(), FarChunks::setView));
        addRenderableWidget(new ChunkSlider(cx + 122, y, 118, "Loaded", FarChunks.near(), FarChunks::setNear));
        y += 28;
        if (this.minecraft.level == null) {
            List<Path> all = replays();
            int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
            for (Path p : all.subList(page * PER_PAGE, Math.min(all.size(), (page + 1) * PER_PAGE))) {
                String label = String.format("Play %s", niceName(p));
                addRenderableWidget(Button.builder(Component.literal(label), b -> {
                    this.minecraft.setScreen(null);
                    ReplayPlayer.cleanupStale(this.minecraft);
                    ReplayPlayer.play(this.minecraft, p);
                }).bounds(cx, y, 130, 20).build());
                // Edit: opens this replay in the editor (timeline, jump, delete a part, split, save as a new replay)
                addRenderableWidget(Button.builder(Component.literal("Edit"), b -> {
                    this.minecraft.setScreen(null);
                    ReplayPlayer.cleanupStale(this.minecraft);
                    ReplayPlayer.play(this.minecraft, p, true);
                }).bounds(cx + 134, y, 48, 20).build());
                // Export: plays the replay frame by frame at a fixed fps and encodes it to .minecraft/guirec/exports/*.mp4 (built-in ffmpeg)
                addRenderableWidget(Button.builder(Component.literal("Export"), b -> {
                    this.minecraft.setScreen(new ExportScreen(this, p));
                }).bounds(cx + 186, y, 54, 20).build());
                y += 24;
            }
            if (pages > 1) {
                addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> { page--; this.rebuildWidgets(); })
                        .bounds(cx, y, 76, 20).build()).active = page > 0;
                addRenderableWidget(Button.builder(Component.literal("Next >"), b -> { page++; this.rebuildWidgets(); })
                        .bounds(cx + 164, y, 76, 20).build()).active = page < pages - 1;
            }
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx, this.height - 28, 240, 20).build());
    }

    /** replay_<epoch ms>[_edit|_partN].guirec -> "2026-11-20 07:35 edit" */
    private static String niceName(Path p) {
        String n = p.getFileName().toString().replace("replay_", "").replace(".guirec", "");
        try {
            int us = n.indexOf('_');
            long ms = Long.parseLong(us < 0 ? n : n.substring(0, us));
            String date = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date(ms));
            return us < 0 ? date : date + " " + n.substring(us + 1);
        } catch (Exception e) { return n; }
    }

    private Component autoLabel() {
        return Component.literal("Auto-record on world join: " + (ReplayRecorder.autoRecord ? "ON" : "OFF"));
    }

    /** 1..64 chunk slider (like the FOV slider). */
    private static final class ChunkSlider extends AbstractSliderButton {
        private final String label;
        private final IntConsumer set;
        ChunkSlider(int x, int y, int w, String label, int cur, IntConsumer set) {
            super(x, y, w, 20, Component.empty(), (Math.max(1, Math.min(64, cur)) - 1) / 63.0);
            this.label = label; this.set = set;
            updateMessage();
        }
        private int val() { return 1 + (int) Math.round(this.value * 63); }
        @Override protected void updateMessage() { if (label != null) setMessage(Component.literal(label + ": " + val() + " chunks")); }
        @Override protected void applyValue() { set.accept(val()); }
    }

    private Component farLabel() {
        return Component.literal("Far record (Sent = recorded, Loaded = live): " + (FarChunks.isEnabled() ? "ON" : "OFF"));
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), 14, 0xFFFFFFFF);
        int y = this.height - 62;
        if (ReplayRecorder.isActive())
            line(g, String.format("RECORDING  %d packets, %d frames, %d sounds, %.2f MB", ReplayRecorder.packets, ReplayRecorder.states, ReplayRecorder.soundsRec, ReplayRecorder.fileSize() / 1048576.0), y, 0xFFFF6666);
        else if (this.minecraft.level != null)
            line(g, "Go to the main menu to play a replay", y, 0xFFAAAAAA);
        if (!ReplayPlayer.status.isEmpty()) line(g, ReplayPlayer.status, y + 14, 0xFFFFDD66);
    }

    @Override
    public void onClose() { FarChunks.save(); this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
