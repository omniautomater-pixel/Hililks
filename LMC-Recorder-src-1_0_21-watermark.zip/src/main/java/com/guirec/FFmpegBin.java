package com.guirec;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Built-in ffmpeg. The Android (arm64) ffmpeg from the PojavLauncher FFmpeg plugin is packed INSIDE this mod
 * (resources/guirec_ffmpeg/arm64-v8a). On first use it is copied out and started, so no plugin APK has to be installed.
 * On PC (not Android) the ffmpeg from PATH is used.
 *
 * Android 10+ may refuse to execve() a file from an app data folder, so three ways are tried in order:
 * direct start, start through /system/bin/linker64, and two different folders. The first that answers "ffmpeg -version" is used.
 */
public final class FFmpegBin {
    private static final String RES = "guirec_ffmpeg/arm64-v8a/";
    private static final String[] FILES = {"libc++_shared.so", "libavutil.so", "libswresample.so", "libswscale.so",
            "libavcodec.so", "libavformat.so", "libavfilter.so", "libavdevice.so", "libffmpeg.so"};

    private static List<String> prefix;       // command that starts ffmpeg (without arguments)
    private static String libDir;             // folder for LD_LIBRARY_PATH (Android build) or null
    private static boolean x264;
    private static String error = "";
    private static final StringBuilder log = new StringBuilder();

    private FFmpegBin() {}

    public static String error() { return error; }
    public static String log() { return log.toString(); }
    public static boolean hasX264() { return x264; }
    public static String libDir() { return libDir; }

    public static boolean isAndroid() {
        return new File("/system/bin/linker64").exists() || new File("/system/bin/linker").exists();
    }

    /** Command prefix to start ffmpeg, or null (see error()). */
    public static synchronized List<String> command(Path gameDir) {
        if (prefix != null) return new ArrayList<>(prefix);
        log.setLength(0); error = "";
        try {
            // 1) ffmpeg that is already on the device / PC (PATH): used first, nothing else needed
            List<String> sys = List.of("ffmpeg");
            if (probe(sys, null)) { prefix = sys; libDir = null; return new ArrayList<>(prefix); }
            error = "";
            // 2) built-in ffmpeg (Android arm64), only if it is packed in this jar
            if (isAndroid()) {
                String arch = System.getProperty("os.arch", "");
                boolean arm64 = arch.contains("aarch64") || arch.contains("arm64");
                if (!arm64) { error = "this phone is not arm64 (" + arch + "); only arm64 ffmpeg is built in"; }
                else {
                    List<Path> dirs = new ArrayList<>();
                    String tmp = System.getProperty("java.io.tmpdir");
                    if (tmp != null) dirs.add(Paths.get(tmp, "guirec-ffmpeg"));
                    dirs.add(gameDir.resolve("guirec").resolve("ffmpeg"));
                    for (Path d : dirs) {
                        try {
                            extract(d);
                            String bin = d.resolve("libffmpeg.so").toString();
                            for (List<String> cand : List.of(List.of(bin), List.of(linker(), bin))) {
                                if (probe(cand, d.toString())) { prefix = cand; libDir = d.toString(); return new ArrayList<>(prefix); }
                            }
                        } catch (Throwable t) { log.append("dir ").append(d).append(": ").append(t).append('\n'); }
                    }
                    if (error.isEmpty()) error = "built-in ffmpeg did not start on this device (see guirec/export_debug.log)";
                }
            }
            if (error.isEmpty()) error = "ffmpeg not found (install ffmpeg and put it in PATH)";
        } catch (Throwable t) { error = String.valueOf(t); log.append(t).append('\n'); }
        return null;
    }

    private static String linker() { return new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker"; }

    private static void extract(Path dir) throws IOException {
        Files.createDirectories(dir);
        for (String f : FILES) {
            Path out = dir.resolve(f);
            try (InputStream in = FFmpegBin.class.getClassLoader().getResourceAsStream(RES + f)) {
                if (in == null) throw new FileNotFoundException("missing in mod jar: " + RES + f);
                byte[] data = in.readAllBytes();
                if (!Files.exists(out) || Files.size(out) != data.length) {
                    Path tmp = dir.resolve(f + ".part");
                    Files.write(tmp, data);
                    Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            File fo = out.toFile();
            fo.setReadable(true, false); fo.setExecutable(true, false);
        }
    }

    /** Starts "<cmd> -version" and (if it works) "-encoders". */
    private static boolean probe(List<String> cmd, String ld) {
        try {
            String v = run(cmd, ld, "-version");
            log.append(String.join(" ", cmd)).append(" -> ").append(v.lines().findFirst().orElse("(no output)")).append('\n');
            if (!v.toLowerCase(Locale.ROOT).contains("ffmpeg version")) {
                if (error.isEmpty()) error = v.lines().findFirst().orElse("ffmpeg gave no output");
                return false;
            }
            String enc = run(cmd, ld, "-hide_banner", "-encoders");
            x264 = enc.contains("libx264");
            log.append("libx264: ").append(x264).append(", mpeg4: ").append(enc.contains(" mpeg4 ")).append('\n');
            return true;
        } catch (Throwable t) {
            log.append(String.join(" ", cmd)).append(" failed: ").append(t).append('\n');
            if (error.isEmpty()) error = t.toString();
            return false;
        }
    }

    private static String run(List<String> cmd, String ld, String... args) throws Exception {
        List<String> c = new ArrayList<>(cmd); c.addAll(Arrays.asList(args));
        ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true);
        applyEnv(pb, ld);
        Process p = pb.start();
        p.getOutputStream().close();
        byte[] out = p.getInputStream().readAllBytes();
        if (!p.waitFor(20, TimeUnit.SECONDS)) { p.destroyForcibly(); throw new IOException("timeout"); }
        return new String(out);
    }

    /** Environment for the ffmpeg process (also used by ReplayExport). */
    public static void applyEnv(ProcessBuilder pb, String ld) {
        if (ld != null) {
            // only our folder: Pojav's own LD_LIBRARY_PATH / LD_PRELOAD would load its libraries into ffmpeg
            pb.environment().put("LD_LIBRARY_PATH", ld);
            pb.environment().remove("LD_PRELOAD");
        }
    }
}
