package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Skins + cape menu: pick the skin of your own player (account skin / any .png in .minecraft/guirec/skins), model, cape on / off. */
public class SkinScreen extends Screen {
    private final Screen parent;
    private int page;
    private String msg = "";

    public SkinScreen(Screen parent) {
        super(Component.literal("Skins & capes"));
        this.parent = parent;
    }

    private int perPage() { return Math.max(1, (this.height - 32 - 108) / 24); }

    private static String modelName() { return CustomSkins.model == 1 ? "Classic" : CustomSkins.model == 2 ? "Slim" : "Auto"; }

    @Override
    protected void init() {
        int cx = this.width / 2 - 120, y = 32;
        List<String> items = new ArrayList<>();
        items.add("");                                  // "" = account skin
        items.addAll(CustomSkins.list());
        int per = perPage();
        int pages = Math.max(1, (items.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (String f : items.subList(page * per, Math.min(items.size(), (page + 1) * per))) {
            boolean on = f.equals(CustomSkins.selected);
            String label = (on ? "> " : "   ") + (f.isEmpty() ? "Account skin (default / premium skin)" : f);
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                CustomSkins.select(f);
                msg = f.isEmpty() ? "Account skin" : "Skin: " + f;
                this.rebuildWidgets();
            }).bounds(cx, y, 240, 20).build());
            y += 24;
        }
        int rowA = this.height - 100, rowB = this.height - 76, rowC = this.height - 52, rowD = this.height - 28;
        addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> { page--; this.rebuildWidgets(); })
                .bounds(cx, rowA, 76, 20).build()).active = page > 0;
        addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> { CustomSkins.forgetCache(); msg = "Folder read again."; this.rebuildWidgets(); })
                .bounds(cx + 80, rowA, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Next >"), b -> { page++; this.rebuildWidgets(); })
                .bounds(cx + 164, rowA, 76, 20).build()).active = page < pages - 1;
        addRenderableWidget(Button.builder(Component.literal("Model: " + modelName()), b -> {
            CustomSkins.cycleModel(); b.setMessage(Component.literal("Model: " + modelName()));
        }).bounds(cx, rowB, 118, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cape: " + (CustomSkins.cape ? "ON" : "OFF")), b -> {
            CustomSkins.toggleCape(); b.setMessage(Component.literal("Cape: " + (CustomSkins.cape ? "ON" : "OFF")));
        }).bounds(cx + 122, rowB, 118, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Add custom skin (open skins folder)"), b -> {
            try {
                java.nio.file.Files.createDirectories(CustomSkins.dir());
                net.minecraft.util.Util.getPlatform().openPath(CustomSkins.dir());
                msg = "Folder opened (if nothing opens, use the path shown above).";
            } catch (Throwable t) { msg = "Could not open the folder: " + t.getClass().getSimpleName(); }
        }).bounds(cx, rowC, 240, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(cx, rowD, 240, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), 8, 0xFFFFFFFF);
        String top = !CustomSkins.error.isEmpty() ? CustomSkins.error : !msg.isEmpty() ? msg : "Folder: " + shortPath();
        line(g, top, 20, !CustomSkins.error.isEmpty() ? 0xFFFF7777 : 0xFFAAAAAA);
        line(g, "Only on your screen / replays. Premium skin = \"Account skin\".", this.height - 12, 0xFF888888);
    }

    private static String shortPath() {
        try { return "guirec/skins  (" + CustomSkins.dir().toAbsolutePath() + ")"; } catch (Throwable t) { return "guirec/skins"; }
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
